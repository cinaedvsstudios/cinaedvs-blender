# CINAEDVS File Rescue v0.20.6

Blender 5.0+ extension for finding, reviewing, staging, and safely applying replacements for missing external files.

## Code-organisation review build

- Split the former single-file add-on into focused package modules.
- Kept registration in `__init__.py`.
- Moved shared matching, scanning, and preview helpers to `core.py`.
- Moved Blender property groups to `properties.py`.
- Moved workflow actions to `operators.py`.
- Moved lists, menus, dialogs, and the launcher panel to `ui.py`.
- Preserved the existing File Rescue behaviour and Windows-only manifest restriction.

## Existing v0.20 features

- Automatically scans the open Blender file for missing references when launched.
- Automatically scans a chosen source folder and up to six child-folder levels.
- Stages exact matches without changing Blender until Save New Mappings is confirmed.
- Supports possible-match review, previews, bulk staging, linked-object inspection, and whole-drive search.

See `CHANGELOG.md` for the cumulative build history included in this package.
