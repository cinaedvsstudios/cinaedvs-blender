# SPDX-FileCopyrightText: 2026 Chris
# SPDX-License-Identifier: GPL-3.0-or-later

bl_info = {
    "name": "CINAEDVS File Rescue",
    "author": "Chris",
    "version": (0, 20, 6),
    "blender": (5, 0, 0),
    "location": "3D Viewport > Sidebar > CINAEDVS > Launch",
    "description": "A controlled visual relinker for missing external Blender files",
    "category": "System",
}

"""CINAEDVS File Rescue package registration for v0.20.6."""

from . import core, operators, properties, ui

_CLASSES = (
    properties.CFR_CandidateItem,
    properties.CFR_MissingFileItem,
    properties.CFR_BrowserFolderItem,
    properties.CFR_DriveResultItem,
    properties.CFR_StagedPreviewItem,
    properties.CFR_LinkedObjectItem,
    properties.CFR_Settings,
    ui.CFR_UL_missing_files,
    ui.CFR_UL_candidates,
    ui.CFR_UL_browser_folders,
    ui.CFR_UL_drive_results,
    ui.CFR_UL_staged_preview,
    ui.CFR_UL_linked_objects,
    operators.CFR_OT_scan_missing_files,
    operators.CFR_OT_set_all_filters,
    operators.CFR_OT_clear_all_filters,
    operators.CFR_OT_toggle_staged_visibility,
    operators.CFR_OT_stage_matches_above_threshold,
    operators.CFR_OT_choose_scan_folder,
    operators.CFR_OT_refresh_folders,
    operators.CFR_OT_up_folder,
    operators.CFR_OT_open_selected_folder,
    operators.CFR_OT_search_drive_for_file,
    operators.CFR_OT_review_drive_result,
    operators.CFR_OT_start_folder_scan,
    operators.CFR_OT_cancel_scan,
    operators.CFR_OT_preview_candidate,
    operators.CFR_OT_next_preview_candidate,
    operators.CFR_OT_copy_path,
    operators.CFR_OT_map_selected_candidate,
    operators.CFR_OT_choose_any_replacement,
    operators.CFR_OT_remove_pending_mapping,
    operators.CFR_OT_discard_pending_mappings,
    operators.CFR_OT_preview_staged_mappings,
    operators.CFR_OT_remove_previewed_staged_mapping,
    operators.CFR_OT_copy_staged_preview_path,
    operators.CFR_OT_discard_from_close_warning,
    operators.CFR_OT_pending_close_warning,
    operators.CFR_OT_ignore_selected,
    operators.CFR_OT_show_linked_objects,
    operators.CFR_OT_open_object_preview,
    operators.CFR_OT_set_object_preview_mode,
    operators.CFR_OT_adjust_object_preview,
    ui.CFR_MT_file_type_filters,
    ui.CFR_OT_show_intro,
    ui.CFR_OT_launch,
    ui.CFR_PT_launcher,
)


def register():
    for cls in _CLASSES:
        core.bpy.utils.register_class(cls)
    core.bpy.types.Scene.cfr_settings = core.PointerProperty(type=properties.CFR_Settings)


def unregister():
    cancel = core._RUNTIME.get("cancel")
    if cancel:
        cancel.set()
    try:
        for scene in core.bpy.data.scenes:
            core._clear_object_preview_image(scene.cfr_settings)
            core._clear_staged_preview_image(scene.cfr_settings)
    except Exception:
        pass
    if hasattr(core.bpy.types.Scene, "cfr_settings"):
        del core.bpy.types.Scene.cfr_settings
    for cls in reversed(_CLASSES):
        try:
            core.bpy.utils.unregister_class(cls)
        except RuntimeError:
            pass


if __name__ == "__main__":
    register()
