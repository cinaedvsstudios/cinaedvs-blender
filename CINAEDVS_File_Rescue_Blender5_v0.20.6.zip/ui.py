# SPDX-FileCopyrightText: 2026 Chris
# SPDX-License-Identifier: GPL-3.0-or-later

"""Blender lists, menus, dialogs, and launcher panel for CINAEDVS File Rescue."""

from .core import *
from .properties import *
from .operators import *

# -----------------------------------------------------------------------------
# Scene list widgets
# -----------------------------------------------------------------------------

class CFR_UL_missing_files(UIList):
    bl_idname = "CFR_UL_missing_files"

    def filter_items(self, context, data, propname):
        """Hide only staged rows when requested.

        In Blender UILists, bitflag_filter_item marks a row as visible.
        v0.9 inverted this flag, which hid every valid row. This explicit
        implementation keeps all normal rows visible and only removes staged
        rows when the user chooses Hide Staged.
        """
        items = getattr(data, propname)
        settings = context.scene.cfr_settings
        visible_flag = self.bitflag_filter_item
        flags = [
            visible_flag
            if settings.show_staged_matches or item.status != "PENDING"
            else 0
            for item in items
        ]
        return flags, []

    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        if self.layout_type in {"DEFAULT", "COMPACT"}:
            row = layout.row(align=True)
            row.label(text=_status_text(item), icon=_status_icon(item))
            row.label(text=item.match_name or "Blank / unnamed reference")
            kind = row.row(align=True)
            kind.alignment = "RIGHT"
            kind.label(text=KIND_LABELS.get(item.kind, item.kind))
        else:
            layout.label(text=item.match_name or "Blank / unnamed reference", icon=_status_icon(item))


class CFR_UL_candidates(UIList):
    bl_idname = "CFR_UL_candidates"

    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        if self.layout_type in {"DEFAULT", "COMPACT"}:
            row = layout.row(align=True)
            row.label(text=f"[{item.score}%]", icon="FILE")
            row.label(text=item.name or _display_path(item.path, 66))
            state = row.row(align=True)
            state.alignment = "RIGHT"
            state.label(text=item.match_type)
        else:
            layout.label(text=item.name or _display_path(item.path, 66), icon="FILE")


class CFR_UL_staged_preview(UIList):
    bl_idname = "CFR_UL_staged_preview"

    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        row = layout.row(align=True)
        row.label(text="[~] Match Found", icon=ICON_MATCH_FOUND)
        row.label(text=_display_path(item.name or _match_name(item.path), 34), icon="FILE")
        tail = row.row(align=True)
        tail.alignment = "RIGHT"
        tail.label(text=_display_path(item.kind, 24))


class CFR_UL_browser_folders(UIList):
    bl_idname = "CFR_UL_browser_folders"

    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        layout.label(text=item.name or item.path, icon="FILE_FOLDER")


class CFR_UL_drive_results(UIList):
    bl_idname = "CFR_UL_drive_results"

    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        row = layout.row(align=True)
        row.label(text=f"[{item.score}%]", icon="FILE")
        row.label(text=item.name or _display_path(item.path, 52))
        label = row.row(align=True)
        label.alignment = "RIGHT"
        label.label(text=item.match_type)


class CFR_UL_linked_objects(UIList):
    bl_idname = "CFR_UL_linked_objects"

    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        if self.layout_type in {"DEFAULT", "COMPACT"}:
            row = layout.row(align=True)
            row.label(text=item.object_name, icon="OBJECT_DATA")
            row.label(text=item.object_type)
            detail = item.material_name or item.usage or "Direct object use"
            row.label(text=_display_path(detail, 38))
            tail = row.row(align=True)
            tail.alignment = "RIGHT"
            tail.label(text=_display_path(item.collection_name, 28))
        else:
            layout.label(text=item.object_name, icon="OBJECT_DATA")

# -----------------------------------------------------------------------------
# File-type menu and launch popup
# -----------------------------------------------------------------------------

class CFR_MT_file_type_filters(Menu):
    bl_idname = "CFR_MT_file_type_filters"
    bl_label = "File Types"

    def draw(self, context):
        settings = context.scene.cfr_settings
        layout = self.layout
        row = layout.row(align=True)
        row.operator("cfr.set_all_filters", text="All", icon="CHECKMARK")
        row.operator("cfr.clear_all_filters", text="Clear All", icon="X")
        layout.separator()
        layout.prop(settings, "filter_materials")
        layout.prop(settings, "filter_models")
        layout.prop(settings, "filter_video")
        layout.prop(settings, "filter_audio")
        layout.prop(settings, "filter_fonts")
        layout.prop(settings, "filter_caches")
        layout.prop(settings, "filter_other")



def _filter_button_text(settings):
    """Return compact text for the File Types menu button."""
    filter_names = (
        ("Textures", settings.filter_materials),
        ("Models", settings.filter_models),
        ("Video", settings.filter_video),
        ("Audio", settings.filter_audio),
        ("Fonts", settings.filter_fonts),
        ("Caches", settings.filter_caches),
        ("Other", settings.filter_other),
    )
    selected = [name for name, enabled in filter_names if enabled]
    if len(selected) == len(filter_names):
        return "All File Types"
    if not selected:
        return "No File Types"
    if len(selected) == 1:
        return selected[0]
    return f"{len(selected)} Types Selected"


def _status_counts(settings):
    """Count the stored rows without changing the displayed list."""
    counts = {"FIXED": 0, "PENDING": 0, "REVIEW": 0, "MISSING": 0, "SKIPPED": 0}
    for item in settings.missing_files:
        counts[item.status] = counts.get(item.status, 0) + 1
    return counts


def _draw_rescue_ui(layout, context, in_popup=True):
    """A mirrored two-column workspace for missing and source files.

    Both top cards have the same sequence: header, two concise information rows,
    a toolbar, then a ten-row file list. The two lower cards are both Details
    cards and retain a consistent minimum visual height.
    """
    settings = context.scene.cfr_settings
    layout.use_property_split = False
    layout.use_property_decorate = False

    split = layout.split(factor=0.50)
    left = split.column(align=False)
    right = split.column(align=False)
    counts = _status_counts(settings)

    # ------------------------------------------------------------------
    # TOP LEFT — MISSING FILES
    # ------------------------------------------------------------------
    missing_card = left.box()
    missing_header = missing_card.row(align=True)
    missing_header.scale_y = 1.35
    missing_header.label(text="MISSING FILES", icon=ICON_MISSING)
    missing_total = missing_header.row(align=True)
    missing_total.alignment = "RIGHT"
    visible_count = _visible_missing_count(settings)
    if settings.show_staged_matches:
        missing_total.label(text=f"{visible_count} listed")
    else:
        hidden = _pending_mapping_count(settings)
        missing_total.label(text=f"{visible_count} visible · {hidden} staged hidden")

    # Exactly two metadata rows, mirrored by the source card on the right.
    missing_summary = missing_card.row(align=True)
    missing_summary.label(
        text=(
            f"{counts.get('FIXED', 0)} saved · "
            f"{counts.get('PENDING', 0)} matches found · "
            f"{counts.get('REVIEW', 0)} need review · "
            f"{counts.get('MISSING', 0)} unresolved"
        ),
        icon="INFO",
    )
    linked_button = missing_summary.row(align=True)
    linked_button.alignment = "RIGHT"
    linked_button.enabled = _active_item(settings) is not None
    linked_button.operator("cfr.show_linked_objects", text="Linked Objects", icon="OUTLINER_OB_GROUP_INSTANCE")
    missing_card.label(
        text="Exact names are staged · nothing changes until Save New Mappings",
        icon=ICON_MATCH_FOUND,
    )

    # The control strip belongs above the list, matching the right-side strip.
    missing_toolbar = missing_card.row(align=True)
    missing_toolbar.scale_y = 1.14
    missing_toolbar.menu(
        "CFR_MT_file_type_filters",
        text=_filter_button_text(settings),
        icon="DOWNARROW_HLT",
    )
    visibility = missing_toolbar.operator(
        "cfr.toggle_staged_visibility",
        text="Hide Staged" if settings.show_staged_matches else "Show Staged",
        icon="HIDE_ON" if settings.show_staged_matches else "HIDE_OFF",
    )
    missing_toolbar.operator(
        "cfr.scan_missing_files",
        text="Rescan Missing Files",
        icon="VIEWZOOM",
        depress=True,
    )

    missing_card.template_list(
        "CFR_UL_missing_files", "", settings, "missing_files", settings,
        "active_missing_index", rows=10,
    )

    # ------------------------------------------------------------------
    # TOP RIGHT — SOURCE FILES
    # ------------------------------------------------------------------
    source_card = right.box()
    source_header = source_card.row(align=True)
    source_header.scale_y = 1.35
    source_header.label(text="SOURCE FILES", icon="FILE_FOLDER")
    source_index = source_header.row(align=True)
    source_index.alignment = "RIGHT"
    source_index.label(
        text=(
            f"{settings.scanned_folders:,} folders · {settings.scanned_files:,} files"
            if settings.scanned_folders or settings.scanned_files
            else "Not indexed"
        ),
        icon="INFO",
    )

    # Current source path and its picker now share one compact row.
    source_path_row = source_card.row(align=True)
    source_path_row.label(
        text=_display_path(settings.scan_root or "No source folder selected", 38),
        icon="FILE_FOLDER",
    )
    source_path_row.operator(
        "cfr.choose_scan_folder",
        text="Choose Source Folder",
        icon="FILEBROWSER",
        depress=True,
    )
    source_card.label(
        text="Controlled recursive scan: selected folder plus 6 child levels.",
        icon="LOCKED",
    )

    # Matching control-strip position above the source list. The picker has
    # moved to the path row above, so only browsing controls remain here.
    source_toolbar = source_card.row(align=True)
    source_toolbar.scale_y = 1.14
    source_toolbar.operator("cfr.up_folder", text="Up", icon="TRIA_UP")
    source_toolbar.operator("cfr.refresh_folders", text="Refresh", icon="FILE_REFRESH")
    source_toolbar.operator("cfr.open_selected_folder", text="Open", icon="TRIA_RIGHT")

    source_card.template_list(
        "CFR_UL_browser_folders", "", settings, "browser_folders", settings,
        "active_browser_index", rows=10,
    )

    # ------------------------------------------------------------------
    # LOWER LEFT — DETAILS
    # ------------------------------------------------------------------
    missing_details = left.box()
    missing_details_header = missing_details.row(align=True)
    missing_details_header.scale_y = 1.18
    missing_details_header.label(text="DETAILS", icon="INFO")

    item = _active_item(settings)
    if item is None:
        missing_details.label(text="Select a missing file to inspect it.", icon="INFO")
        missing_details.label(text="Exact filename matches are mapped automatically.")
        missing_details.label(text="Possible fuzzy matches stay here for review.")
        missing_details.label(text="")
        missing_details.label(text="")
        missing_details.label(text="")
    else:
        # Keep the original filename/category information concise. For review
        # rows, the candidate heading below supplies the one definitive
        # "Possible Matches" label, avoiding duplicate messages.
        if item.status != "REVIEW":
            missing_details.label(
                text=f"{_status_text(item)}  {_display_path(item.match_name or 'Blank / unnamed reference', 54)}",
                icon=_status_icon(item),
            )
        else:
            missing_details.label(
                text=_display_path(item.match_name or "Blank / unnamed reference", 62),
                icon=ICON_POSSIBLE_MATCH,
            )
        missing_details.label(text=_display_path(KIND_LABELS.get(item.kind, item.kind), 54))

        # The shortened path is a button solely so Blender can expose the full
        # stored path in a hover tooltip. The dedicated Copy button beside it
        # copies that exact full path to the clipboard.
        original_row = missing_details.row(align=True)
        original_row.label(text="Original:")
        hover_path = original_row.operator(
            "cfr.copy_path",
            text=_display_path(item.original_path or "No stored path", 42),
            icon="FILE",
        )
        hover_path.full_path = item.original_path
        copy_path = original_row.operator("cfr.copy_path", text="Copy", icon="COPYDOWN")
        copy_path.full_path = item.original_path

        if item.status == "PENDING":
            staged = missing_details.box()
            staged.label(text="MATCH FOUND — NOT APPLIED YET", icon=ICON_MATCH_FOUND)
            staged.label(text=_display_path(item.resolved_path, 68), icon="FILE")
            staged.label(text="Save New Mappings applies this path to Blender and saves the .blend file.", icon="INFO")
            staged_actions = staged.row(align=True)
            staged_actions.operator("cfr.choose_any_replacement", text="Change File", icon="FILEBROWSER")
            staged_actions.operator("cfr.remove_pending_mapping", text="Remove Match", icon="X")
        elif item.status == "REVIEW" and item.candidates:
            candidate_header = missing_details.row(align=True)
            candidate_header.label(
                text=(
                    f"Possible Matches — {len(item.candidates)} for "
                    f"{_display_path(item.match_name, 44)}"
                ),
                icon=ICON_POSSIBLE_MATCH,
            )
            missing_details.template_list(
                "CFR_UL_candidates", "", item, "candidates", item,
                "active_candidate_index", rows=2,
            )
            candidate_actions = missing_details.row(align=True)
            candidate_actions.operator("cfr.preview_candidate", text="Preview / Stage Match", icon="HIDE_OFF")
            threshold = candidate_actions.row(align=True)
            threshold.scale_x = 0.42
            threshold.prop(settings, "stage_threshold", text="")
            candidate_actions.operator(
                "cfr.stage_matches_above_threshold",
                text=f"Stage ≥ {settings.stage_threshold}%",
                icon=ICON_MATCH_FOUND,
                depress=True,
            )
            candidate_actions.operator("cfr.choose_any_replacement", text="Choose File", icon="FILEBROWSER")
        else:
            missing_details.label(text=item.note or "No candidate needs review.")
            missing_details.label(text="")
            missing_details.label(text="")
            manual = missing_details.row(align=True)
            manual.operator("cfr.choose_any_replacement", text="Choose Replacement", icon="FILEBROWSER")
            manual.operator("cfr.search_drive_for_file", text="Search HDD for This File", icon="DISK_DRIVE")
            manual.operator("cfr.ignore_selected", text="Ignore", icon="REMOVE")

    # ------------------------------------------------------------------
    # LOWER RIGHT — SOURCE DETAILS / FULL-DRIVE RESULTS
    # ------------------------------------------------------------------
    drive_for_active = bool(item and settings.drive_search_ref_key == item.ref_key)
    source_details = right.box()
    source_details_header = source_details.row(align=True)
    source_details_header.scale_y = 1.18
    source_details_header.label(
        text="DRIVE SEARCH RESULTS" if drive_for_active else "DETAILS",
        icon="VIEWZOOM" if drive_for_active else "INFO",
    )

    if drive_for_active:
        source_details.label(text=f"Target: {settings.drive_search_target}", icon="FILE")
        source_details.label(
            text=_display_path(settings.drive_search_root or "No drive selected", 70),
            icon="DISK_DRIVE",
        )
        if _RUNTIME["running"] and _RUNTIME.get("mode") == "drive":
            source_details.label(
                text=f"Searching {settings.scanned_folders:,} folders · {settings.scanned_files:,} files",
                icon="TIME",
            )
        elif settings.drive_results:
            source_details.label(
                text=f"{len(settings.drive_results)} result(s) · {settings.drive_search_denied:,} inaccessible folder(s) skipped",
                icon="INFO",
            )
            source_details.template_list(
                "CFR_UL_drive_results", "", settings, "drive_results", settings,
                "active_drive_result_index", rows=4,
            )
            drive_actions = source_details.row(align=True)
            drive_actions.operator(
                "cfr.review_drive_result",
                text="Preview / Stage Match Result",
                icon="HIDE_OFF",
            )
        else:
            source_details.label(text="No usable filename match found on this drive.", icon="ERROR")
            source_details.label(text=f"{settings.drive_search_denied:,} inaccessible folder(s) were skipped.")
            source_details.label(text="Choose Replacement still lets you select a file manually.")

        drive_scan = source_details.row(align=True)
        drive_scan.scale_y = 1.14
        if _RUNTIME["running"] and _RUNTIME.get("mode") == "drive":
            drive_scan.enabled = True
            drive_scan.operator("cfr.cancel_scan", text="Cancel Drive Search", icon="CANCEL")
        else:
            drive_scan.operator("cfr.search_drive_for_file", text="Search Another Drive", icon="DISK_DRIVE")
    else:
        source_details.label(text="Selected source folder", icon="FILE_FOLDER")
        source_details.label(text=_display_path(settings.scan_root or "No source folder selected", 70))
        source_details.label(text="Scope: selected folder plus up to six child levels.", icon="LOCKED")
        source_details.label(text="Exact filenames map automatically; fuzzy names remain for review.")
        source_details.label(text="")
        source_details.label(text="")

        source_scan = source_details.row(align=True)
        source_scan.scale_y = 1.14
        source_scan.operator(
            "cfr.start_folder_scan",
            text="Rescan Folder + Children",
            icon="VIEWZOOM",
            depress=True,
        )
        cancel = source_scan.row(align=True)
        cancel.enabled = _RUNTIME["running"]
        cancel.operator("cfr.cancel_scan", text="Cancel", icon="CANCEL")

    # One compact full-width status strip at the very bottom.
    footer = layout.box()
    status_text = _display_path(settings.scan_status, 82)
    action_text = _display_path(settings.last_action, 120)
    footer_row = footer.row(align=True)
    footer_row.label(text=status_text, icon="TIME" if _RUNTIME["running"] else "INFO")
    if action_text:
        footer_row.separator(factor=0.75)
        footer_row.label(text=action_text)

    # Pending mappings are deliberately explicit: they can be discarded only
    # from a guarded action and are otherwise applied only by the native Save
    # New Mappings footer.
    pending = _pending_mapping_count(settings)
    if pending:
        pending_row = layout.row(align=True)
        pending_row.alignment = "CENTER"
        pending_row.label(text=f"{pending} match(es) found — not applied to Blender yet", icon=ICON_MATCH_FOUND)
        pending_row.operator("cfr.discard_pending_mappings", text="Discard Staged Matches", icon="TRASH")
        pending_row.operator("cfr.preview_staged_mappings", text="Preview Changes", icon="HIDE_OFF")

    # Native Blender dialogs own their Save/Cancel footer and cannot host a
    # third control inside that exact row. Keep the guide available as a compact
    # control in the action strip immediately above the native footer.
    footer_actions = layout.row(align=True)
    footer_actions.alignment = "CENTER"
    show_info = footer_actions.operator("cfr.show_intro", text="Info", icon="INFO")
    show_info.open_main_after = False


class CFR_OT_close_launch_popup(Operator):
    bl_idname = "cfr.close_launch_popup"
    bl_label = "Close CINAEDVS File Rescue"
    bl_description = "Close the CINAEDVS popup"

    def execute(self, context):
        # Blender closes an invoke_popup when its invoking UI action resolves on
        # supported builds. Escape and click-outside remain native fallbacks.
        return {"FINISHED"}


def _update_intro_visibility(self, context):
    """Persist the guide choice immediately, including when the guide is cancelled."""
    try:
        context.scene.cfr_settings.hide_intro = bool(self.dont_show_again)
    except Exception:
        pass


class CFR_OT_show_intro(Operator):
    bl_idname = "cfr.show_intro"
    bl_label = "How CINAEDVS File Rescue Works"
    bl_description = "Show the CINAEDVS File Rescue workflow guide"
    bl_options = {"REGISTER"}

    open_main_after: BoolProperty(options={"HIDDEN"}, default=True)
    dont_show_again: BoolProperty(
        name="Don't show this again",
        default=False,
        update=_update_intro_visibility,
        description="Skip this guide next time CINAEDVS File Rescue is launched",
    )

    def invoke(self, context, event):
        self.dont_show_again = context.scene.cfr_settings.hide_intro
        return context.window_manager.invoke_props_dialog(
            self,
            width=820,
            title="CINAEDVS File Rescue — Quick Guide",
            confirm_text="Continue",
            cancel_default=True,
        )

    def execute(self, context):
        settings = context.scene.cfr_settings
        settings.hide_intro = self.dont_show_again
        if self.open_main_after:
            bpy.ops.cfr.launch("INVOKE_DEFAULT", skip_intro=True)
        return {"FINISHED"}

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = False
        layout.use_property_decorate = False

        intro = layout.box()
        intro.label(text="HOW FILE RESCUE WORKS", icon="INFO")

        intro.separator()
        intro.label(text="1. Scan the missing-file list", icon=ICON_MISSING)
        intro.label(text="Launching File Rescue automatically scans the active Blender file. Change File Types, then use Rescan Missing Files when needed.")
        intro.label(text="[X] Missing means no useful match has been found. [!] Review means there are candidates to inspect.")

        intro.separator()
        intro.label(text="2. Choose the source folder", icon="FILE_FOLDER")
        intro.label(text="On the right, click Choose Source Folder and select the asset library or folder you want to search.")

        intro.separator()
        intro.label(text="3. Search the source folder", icon="VIEWZOOM")
        intro.label(text="Choosing a source folder automatically starts the scan. Use Rescan Folder + Children only when you want to repeat it. It searches up to 6 child-folder levels.")
        intro.label(text="Folders deeper than level 6 are ignored, but matches within the first 6 levels are still used.")

        intro.separator()
        intro.label(text="4. Understand the results", icon=ICON_POSSIBLE_MATCH)
        intro.label(text="[~] Match Found means an exact filename match was found and staged. It is NOT applied to Blender yet.")
        intro.label(text="[!] Review means CINAEDVS found duplicate exact names or fuzzy filename matches; choose the correct candidate below.")
        intro.label(text="Use Choose File for a manual path, or Search HDD for This File when the normal folder scan finds nothing useful.")

        intro.separator()
        intro.label(text="5. Stage and bulk-stage matches", icon=ICON_MATCH_FOUND)
        intro.label(text="Preview / Stage Match stages the selected candidate only. Staging never changes the open Blender scene.")
        intro.label(text="Stage ≥ 90% stages the first listed candidate for every review row at or above the percentage you enter.")
        intro.label(text="Use Preview Changes to inspect all staged mappings and remove any you do not want. Hide Staged only hides rows; it does not discard them.")

        intro.separator()
        intro.label(text="6. Apply and save", icon="FILE_TICK")
        intro.label(text="Save New Mappings is the ONLY action that applies staged paths to Blender and saves this entire .blend file.")
        intro.label(text="Closing with staged matches shows a warning. Save to apply them, discard them, or return to editing.")

        layout.separator()
        layout.label(text="This guide opens only when you press Info in File Rescue.", icon="INFO")


class CFR_OT_launch(Operator):
    bl_idname = "cfr.launch"
    bl_label = "CINAEDVS File Rescue"
    bl_description = "Open CINAEDVS File Rescue"
    bl_options = {"REGISTER"}

    skip_intro: BoolProperty(options={"HIDDEN"}, default=False)

    def invoke(self, context, event):
        settings = context.scene.cfr_settings
        # The guide is deliberately manual only. It is available via Info in
        # the main File Rescue dialog and never interrupts opening a new file.
        #
        # Launch should immediately audit the active .blend so the left pane is
        # useful without an extra click. Existing staged matches are preserved
        # rather than silently discarded by a rebuild.
        pending = _pending_mapping_count(settings)
        if pending:
            settings.last_action = (
                f"{pending} staged match(es) are still waiting to be saved or discarded. "
                "The missing-file list was not rebuilt."
            )
        else:
            scan_missing_references(context.scene)

        if settings.scan_root and os.path.isdir(bpy.path.abspath(settings.scan_root)):
            _refresh_browser_folder_list(settings)

        # This native dialog path was tested on Chris's Blender build: it
        # displays UIList rows correctly and supplies reliable save/cancel actions.
        return context.window_manager.invoke_props_dialog(
            self,
            width=1180,
            title="CINAEDVS File Rescue",
            confirm_text="Save New Mappings",
            cancel_default=True,
        )

    def execute(self, context):
        settings = context.scene.cfr_settings
        ok, message = _commit_pending_mappings(context.scene)
        settings.last_action = message
        if not ok:
            self.report({"WARNING"}, message)
            return {"CANCELLED"}
        self.report({"INFO"}, message)
        _tag_all_redraws()
        return {"FINISHED"}

    def cancel(self, context):
        pending = _pending_mapping_count(context.scene.cfr_settings)
        if pending:
            # The main dialog is now closing, so open a clear native warning.
            # Cancel in that warning reopens this editor; confirmation applies
            # and saves the staged paths.
            bpy.ops.cfr.pending_close_warning("INVOKE_DEFAULT")
        return None

    def draw(self, context):
        _draw_rescue_ui(self.layout, context, in_popup=False)


class CFR_PT_launcher(Panel):
    bl_label = "CINAEDVS File Rescue"
    bl_idname = "CFR_PT_launcher"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "CINAEDVS"

    def draw(self, context):
        layout = self.layout
        layout.scale_y = 1.65
        layout.operator("cfr.launch", text="Launch", icon="PLAY")

__all__ = ['CFR_UL_missing_files', 'CFR_UL_candidates', 'CFR_UL_staged_preview', 'CFR_UL_browser_folders', 'CFR_UL_drive_results', 'CFR_UL_linked_objects', 'CFR_MT_file_type_filters', '_filter_button_text', '_status_counts', '_draw_rescue_ui', 'CFR_OT_close_launch_popup', '_update_intro_visibility', 'CFR_OT_show_intro', 'CFR_OT_launch', 'CFR_PT_launcher']
