# SPDX-FileCopyrightText: 2026 Chris
# SPDX-License-Identifier: GPL-3.0-or-later

"""Blender scene properties and data rows used by CINAEDVS File Rescue."""

from .core import *

class CFR_CandidateItem(PropertyGroup):
    path: StringProperty()
    name: StringProperty()
    score: IntProperty(default=0)
    match_type: StringProperty()


class CFR_MissingFileItem(PropertyGroup):
    kind: StringProperty()
    datablock_name: StringProperty()
    original_path: StringProperty()
    match_name: StringProperty()
    ref_key: StringProperty()
    source_label: StringProperty()
    status: StringProperty(default="MISSING")
    resolved_path: StringProperty()
    candidate_count: IntProperty(default=0)
    note: StringProperty()
    pre_pending_status: StringProperty()
    pre_pending_note: StringProperty()
    candidates: CollectionProperty(type=CFR_CandidateItem)
    active_candidate_index: IntProperty(default=-1)


class CFR_BrowserFolderItem(PropertyGroup):
    name: StringProperty()
    path: StringProperty()


class CFR_DriveResultItem(PropertyGroup):
    path: StringProperty()
    name: StringProperty()
    score: IntProperty(default=0)
    match_type: StringProperty()


class CFR_StagedPreviewItem(PropertyGroup):
    ref_key: StringProperty()
    name: StringProperty()
    kind: StringProperty()
    path: StringProperty()


class CFR_LinkedObjectItem(PropertyGroup):
    object_name: StringProperty()
    object_type: StringProperty()
    collection_name: StringProperty()
    material_name: StringProperty()
    node_name: StringProperty()
    usage: StringProperty()


class CFR_Settings(PropertyGroup):
    scan_root: StringProperty(name="Source folder", subtype="DIR_PATH")
    missing_files: CollectionProperty(type=CFR_MissingFileItem)
    active_missing_index: IntProperty(default=-1)
    browser_folders: CollectionProperty(type=CFR_BrowserFolderItem)
    active_browser_index: IntProperty(default=-1)
    drive_results: CollectionProperty(type=CFR_DriveResultItem)
    active_drive_result_index: IntProperty(default=-1)
    linked_objects: CollectionProperty(type=CFR_LinkedObjectItem)
    active_linked_object_index: IntProperty(default=-1, update=_update_linked_object_active)
    linked_preview_object: PointerProperty(type=bpy.types.Object)
    linked_ref_key: StringProperty()
    linked_file_label: StringProperty()
    linked_preview_image: PointerProperty(type=bpy.types.Image)
    linked_preview_texture: PointerProperty(type=bpy.types.Texture)
    linked_preview_mode: EnumProperty(
        items=(("SOLID", "Solid", "Low-quality solid viewport-style render"),
               ("MATERIAL", "Material Preview", "Low-quality rendered material preview")),
        default="SOLID",
    )
    linked_preview_azimuth: FloatProperty(default=38.0)
    linked_preview_elevation: FloatProperty(default=21.0)
    linked_preview_zoom: FloatProperty(default=1.0, min=0.55, max=3.2)
    linked_preview_status: StringProperty(default="Choose Preview Object to open an isolated preview window.")
    drive_search_ref_key: StringProperty()
    drive_search_target: StringProperty()
    drive_search_root: StringProperty()
    drive_search_denied: IntProperty(default=0)
    preview_image: PointerProperty(type=bpy.types.Image)
    preview_status: StringProperty(default="Select a possible match, then use Preview / Stage Match.")
    staged_preview_items: CollectionProperty(type=CFR_StagedPreviewItem)
    active_staged_preview_index: IntProperty(default=-1, update=_update_staged_preview_active)
    staged_preview_image: PointerProperty(type=bpy.types.Image)
    staged_preview_status: StringProperty(default="Select a staged match to preview it.")
    scan_status: StringProperty(default="Ready")
    last_action: StringProperty(default="Press Scan Missing Files to build the list.")
    scanned_folders: IntProperty(default=0)
    scanned_files: IntProperty(default=0)
    stage_threshold: IntProperty(
        name="Minimum match %",
        default=90,
        min=1,
        max=100,
        description="Stage every review row whose top candidate meets or exceeds this filename similarity score",
    )
    show_staged_matches: BoolProperty(
        name="Show Staged Matches",
        default=True,
        description="Show or hide Match Found rows in the main missing-file list without discarding them",
    )
    filter_materials: BoolProperty(name="Textures / Materials", default=True)
    filter_models: BoolProperty(name="Models / Libraries", default=True)
    filter_video: BoolProperty(name="Video", default=True)
    filter_audio: BoolProperty(name="Audio", default=True)
    filter_fonts: BoolProperty(name="Fonts", default=True)
    filter_caches: BoolProperty(name="Volumes / Caches", default=True)
    filter_other: BoolProperty(name="Text / Sequencer / IES", default=True)
    hide_intro: BoolProperty(
        name="Don't show this again",
        default=False,
        description="Skip the CINAEDVS File Rescue introduction when launching this tool",
    )
    mappings_changed: BoolProperty(
        default=False,
        description="True when CINAEDVS has staged mappings that have not yet been applied to Blender",
    )

__all__ = [
    "CFR_CandidateItem",
    "CFR_MissingFileItem",
    "CFR_BrowserFolderItem",
    "CFR_DriveResultItem",
    "CFR_StagedPreviewItem",
    "CFR_LinkedObjectItem",
    "CFR_Settings",
]
