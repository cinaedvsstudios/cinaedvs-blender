# CINAEDVS File Rescue v0.20.4

Blender 5.0+ extension for finding, reviewing, staging, and safely applying replacements for missing external files.

## Current review-compliance build

- Removed the CINAEDVS Studios website operator and all clickable promotional links from the Blender UI.
- Removed the promotional “Made by CINAEDVS Studios” line from the in-Blender Quick Guide.
- Kept the functional Info guide and all File Rescue controls unchanged.

## Existing v0.20 features

- Automatically scans the open Blender file for missing references when launched.
- Automatically scans a chosen source folder and up to six child-folder levels.
- Stages exact matches without changing Blender until Save New Mappings is confirmed.
- Supports possible-match review, previews, bulk staging, linked-object inspection, and whole-drive search.

See CHANGELOG.md for the cumulative build history included in this package.
