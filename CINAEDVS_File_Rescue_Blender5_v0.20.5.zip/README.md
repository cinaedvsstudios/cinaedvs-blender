# CINAEDVS File Rescue v0.20.5

Blender 5.0+ extension for finding, reviewing, staging, and safely applying replacements for missing external files.

## Current review-compliance build

- Limited the extension manifest to the Windows x64 platform.
- Kept the existing Windows drive-letter scanning behaviour unchanged.

## Existing v0.20 features

- Automatically scans the open Blender file for missing references when launched.
- Automatically scans a chosen source folder and up to six child-folder levels.
- Stages exact matches without changing Blender until Save New Mappings is confirmed.
- Supports possible-match review, previews, bulk staging, linked-object inspection, and whole-drive search.

See CHANGELOG.md for the cumulative build history included in this package.
