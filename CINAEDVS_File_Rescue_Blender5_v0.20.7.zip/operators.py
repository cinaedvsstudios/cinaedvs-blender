# SPDX-FileCopyrightText: 2026 Chris
# SPDX-License-Identifier: GPL-3.0-or-later

"""File Rescue operators for scanning, staging, previewing, and applying mappings."""

from .core import *
from .properties import *

# -----------------------------------------------------------------------------
# Operators
# -----------------------------------------------------------------------------

class CFR_OT_scan_missing_files(Operator):
    bl_idname = "cfr.scan_missing_files"
    bl_label = "Rescan Missing Files"
    bl_description = "Rebuild the missing-file list using the current File Types selection"

    def execute(self, context):
        settings = context.scene.cfr_settings
        pending = _pending_mapping_count(settings)
        if pending:
            settings.last_action = (
                f"You have {pending} staged match(es). Save or discard them before rebuilding the missing-file list."
            )
            self.report({"WARNING"}, "Save or discard staged matches first")
            return {"CANCELLED"}
        scan_missing_references(context.scene)
        _tag_all_redraws()
        return {"FINISHED"}


class CFR_OT_set_all_filters(Operator):
    bl_idname = "cfr.set_all_filters"
    bl_label = "All"
    bl_description = "Tick every file type"

    def execute(self, context):
        _set_all_filters(context.scene.cfr_settings, True)
        return {"FINISHED"}


class CFR_OT_clear_all_filters(Operator):
    bl_idname = "cfr.clear_all_filters"
    bl_label = "Clear All"
    bl_description = "Untick every file type"

    def execute(self, context):
        _set_all_filters(context.scene.cfr_settings, False)
        return {"FINISHED"}


class CFR_OT_toggle_staged_visibility(Operator):
    bl_idname = "cfr.toggle_staged_visibility"
    bl_label = "Hide Staged Matches"
    bl_description = "Hide or show staged Match Found rows without discarding them"

    def execute(self, context):
        settings = context.scene.cfr_settings
        settings.show_staged_matches = not settings.show_staged_matches

        # Do not leave the Details card pointed at a row that has just been
        # hidden. Move selection to the first visible row where possible.
        if not settings.show_staged_matches:
            active = _active_item(settings)
            if active is not None and active.status == "PENDING":
                for index, item in enumerate(settings.missing_files):
                    if item.status != "PENDING":
                        settings.active_missing_index = index
                        break

        settings.last_action = (
            "Staged matches are visible in the main list."
            if settings.show_staged_matches
            else "Staged matches are hidden from the main list. They remain in Preview Changes and will still save."
        )
        _tag_all_redraws()
        return {"FINISHED"}


class CFR_OT_stage_matches_above_threshold(Operator):
    bl_idname = "cfr.stage_matches_above_threshold"
    bl_label = "Stage Matches Above Threshold"
    bl_description = "Stage the highest-ranked candidate for every review row meeting the selected minimum percentage"

    def execute(self, context):
        scene = context.scene
        settings = scene.cfr_settings
        threshold = int(settings.stage_threshold)
        staged = 0
        below_threshold = 0
        skipped_patterns = 0
        unavailable = 0

        for item in settings.missing_files:
            if item.status != "REVIEW" or not item.candidates:
                continue

            # Pattern paths deliberately require individual review; one tile or
            # frame must not silently replace a sequence/UDIM pattern.
            if "<UDIM>" in item.original_path or "#" in item.original_path:
                skipped_patterns += 1
                continue

            # Candidate rows are ordered best-first by the scanner. On equal
            # scores (for example duplicate exact filenames), this stages the
            # first result shown in Details; Preview Changes remains available
            # to remove or replace any staged result before final save.
            candidate = item.candidates[0]
            if candidate.score < threshold:
                below_threshold += 1
                continue
            if not candidate.path or not os.path.isfile(candidate.path):
                unavailable += 1
                continue

            try:
                _stage_reference_path(
                    scene,
                    item,
                    candidate.path,
                    (
                        f"Top candidate staged automatically at {candidate.score}% "
                        f"(threshold {threshold}%). Not applied to Blender yet."
                    ),
                )
                staged += 1
            except Exception:
                unavailable += 1

        parts = [f"Staged {staged} match(es) at or above {threshold}%."]
        if below_threshold:
            parts.append(f"{below_threshold} below threshold.")
        if skipped_patterns:
            parts.append(f"{skipped_patterns} pattern path(s) left for manual review.")
        if unavailable:
            parts.append(f"{unavailable} unavailable candidate(s) skipped.")
        parts.append("No Blender file paths were changed; use Save New Mappings to apply staged results.")
        settings.last_action = " ".join(parts)
        settings.mappings_changed = _pending_mapping_count(settings) > 0
        _tag_all_redraws()
        return {"FINISHED"}


class CFR_OT_choose_scan_folder(Operator):
    bl_idname = "cfr.choose_scan_folder"
    bl_label = "Choose Source Folder"
    bl_description = "Choose the top folder for the controlled recursive scan"

    directory: StringProperty(subtype="DIR_PATH")
    filter_folder: BoolProperty(default=True, options={"HIDDEN"})

    def invoke(self, context, event):
        settings = context.scene.cfr_settings
        if settings.scan_root:
            self.directory = bpy.path.abspath(settings.scan_root)
        context.window_manager.fileselect_add(self)
        return {"RUNNING_MODAL"}

    def execute(self, context):
        if not self.directory or not os.path.isdir(self.directory):
            self.report({"WARNING"}, "Choose a valid folder")
            return {"CANCELLED"}
        settings = context.scene.cfr_settings
        settings.scan_root = _normalise_path(self.directory)
        _refresh_browser_folder_list(settings)
        # Choosing a folder is the user’s clear instruction to search it.
        # The worker runs in the background, so the native dialog remains responsive.
        _start_folder_scan(context.scene)
        _tag_all_redraws()
        return {"FINISHED"}


class CFR_OT_refresh_folders(Operator):
    bl_idname = "cfr.refresh_folders"
    bl_label = "Refresh Folder List"

    def execute(self, context):
        settings = context.scene.cfr_settings
        _refresh_browser_folder_list(settings)
        return {"FINISHED"}


class CFR_OT_up_folder(Operator):
    bl_idname = "cfr.up_folder"
    bl_label = "Up Folder"

    def execute(self, context):
        settings = context.scene.cfr_settings
        if not settings.scan_root:
            return {"CANCELLED"}
        parent = os.path.dirname(os.path.normpath(settings.scan_root))
        if parent and os.path.isdir(parent):
            settings.scan_root = parent
            _refresh_browser_folder_list(settings)
        return {"FINISHED"}


class CFR_OT_open_selected_folder(Operator):
    bl_idname = "cfr.open_selected_folder"
    bl_label = "Open Selected Folder"

    def execute(self, context):
        settings = context.scene.cfr_settings
        index = settings.active_browser_index
        if 0 <= index < len(settings.browser_folders):
            path = settings.browser_folders[index].path
            if os.path.isdir(path):
                settings.scan_root = path
                _refresh_browser_folder_list(settings)
        return {"FINISHED"}


class CFR_OT_search_drive_for_file(Operator):
    bl_idname = "cfr.search_drive_for_file"
    bl_label = "Search HDD for This File"
    bl_description = "Search one selected drive, without the six-level limit, for this missing filename"

    drive: EnumProperty(name="Drive to search", items=_available_drive_items)

    def invoke(self, context, event):
        item = _active_item(context.scene.cfr_settings)
        if item is None or not item.match_name:
            self.report({"WARNING"}, "Select a missing file with a filename first")
            return {"CANCELLED"}
        choices = _available_drive_items()
        if choices:
            self.drive = choices[0][0]
        return context.window_manager.invoke_props_dialog(
            self,
            width=620,
            title="CINAEDVS — Search Full Drive",
            confirm_text="Search This Drive",
            cancel_default=True,
        )

    def draw(self, context):
        item = _active_item(context.scene.cfr_settings)
        layout = self.layout
        layout.label(text="Search Full Drive for Missing File", icon="VIEWZOOM")
        layout.label(text=item.match_name if item else "No selected file", icon="FILE")
        layout.separator()
        layout.prop(self, "drive")
        warning = layout.box()
        warning.label(text="This searches every readable folder on the selected drive.", icon="ERROR")
        warning.label(text="It has no six-level limit, may take a while, and can be cancelled.")
        warning.label(text="Windows/system folders that deny access are skipped and counted.")

    def execute(self, context):
        item = _active_item(context.scene.cfr_settings)
        if item is None:
            return {"CANCELLED"}
        _start_drive_search(context.scene, self.drive, item.ref_key)
        _tag_all_redraws()
        return {"FINISHED"}


class CFR_OT_review_drive_result(Operator):
    bl_idname = "cfr.review_drive_result"
    bl_label = "Preview / Map Selected Result"
    bl_description = "Send the selected drive-search result to the normal preview and mapping workflow"

    def execute(self, context):
        settings = context.scene.cfr_settings
        item = _active_item(settings)
        result = _active_drive_result(settings)
        if item is None or result is None:
            self.report({"WARNING"}, "Select a drive-search result first")
            return {"CANCELLED"}
        _clear_candidates(item)
        for row in settings.drive_results:
            candidate = item.candidates.add()
            candidate.path = row.path
            candidate.name = row.name
            candidate.score = row.score
            candidate.match_type = row.match_type
        item.active_candidate_index = settings.active_drive_result_index
        _set_item_status(item, "REVIEW", candidates=len(item.candidates), note="Possible matches found by full-drive search.")
        settings.last_action = "Drive-search candidates are now ready for preview and mapping in Details."
        _tag_all_redraws()
        return {"FINISHED"}


class CFR_OT_start_folder_scan(Operator):
    bl_idname = "cfr.start_folder_scan"
    bl_label = "Rescan Source Folder"
    bl_description = "Search the current source folder and its children again for the visible unresolved files"

    def execute(self, context):
        _start_folder_scan(context.scene)
        _tag_all_redraws()
        return {"FINISHED"}


class CFR_OT_cancel_scan(Operator):
    bl_idname = "cfr.cancel_scan"
    bl_label = "Cancel"

    def execute(self, context):
        if not _request_scan_cancel():
            context.scene.cfr_settings.last_action = "There is no scan running."
            return {"CANCELLED"}
        context.scene.cfr_settings.scan_status = "Cancelling…"
        _tag_all_redraws()
        return {"FINISHED"}


class CFR_OT_preview_candidate(Operator):
    bl_idname = "cfr.preview_candidate"
    bl_label = "Preview / Stage Match"
    bl_description = "Preview the selected possible match and stage it for the final save"

    def _load_preview(self, context):
        settings = context.scene.cfr_settings
        item = _active_item(settings)
        candidate = _active_candidate(item)
        settings.preview_image = None
        if candidate is None:
            settings.preview_status = "Select a possible match first."
            return False
        path = candidate.path
        if not os.path.isfile(path):
            settings.preview_status = "This candidate file no longer exists."
            return False
        extension = os.path.splitext(path)[1].lower()
        if extension not in IMAGE_EXTENSIONS:
            settings.preview_status = "No visual preview for this file type. You can still map it."
            return True
        try:
            image = bpy.data.images.load(path, check_existing=True)
            settings.preview_image = image
            settings.preview_status = "Image preview loaded. Stage this match only if it is the correct file."
            return True
        except Exception as exc:
            settings.preview_status = f"Blender could not preview this image: {exc}"
            return True

    def invoke(self, context, event):
        settings = context.scene.cfr_settings
        item = _active_item(settings)
        candidate = _active_candidate(item)
        if item is None or candidate is None:
            self.report({"WARNING"}, "Select a review row and one possible match first")
            return {"CANCELLED"}
        self._load_preview(context)
        return context.window_manager.invoke_props_dialog(
            self,
            width=680,
            title="CINAEDVS — Possible Match",
            confirm_text="Close Preview",
            cancel_default=True,
        )

    def execute(self, context):
        return {"FINISHED"}

    def draw(self, context):
        settings = context.scene.cfr_settings
        item = _active_item(settings)
        candidate = _active_candidate(item)
        layout = self.layout
        layout.use_property_split = False
        layout.use_property_decorate = False

        title = layout.box()
        title.label(text="Possible Match Preview", icon="HIDE_OFF")
        if candidate is not None:
            position = (item.active_candidate_index + 1) if item is not None else 1
            total = len(item.candidates) if item is not None else 1
            title.label(text=f"Candidate {position} of {total}: {candidate.name or _display_path(candidate.path, 82)}", icon="FILE")
            title.label(text=f"{candidate.match_type} · {candidate.score}% filename similarity")
            title.label(text=_display_path(candidate.path, 102))
        if settings.preview_image:
            preview = layout.box()
            try:
                preview.template_ID_preview(settings, "preview_image", rows=7, cols=7, hide_buttons=True)
            except Exception:
                preview.label(text="Preview loaded. Open it from Blender's Image Editor if needed.", icon="IMAGE")
        else:
            no_preview = layout.box()
            no_preview.label(text=settings.preview_status, icon="INFO")

        if item is not None and candidate is not None:
            actions = layout.row(align=True)
            actions.scale_y = 1.35
            actions.operator("cfr.map_selected_candidate", text="Stage Match", icon=ICON_MATCH_FOUND)
            actions.operator("cfr.next_preview_candidate", text="Next Candidate", icon="TRIA_RIGHT")


class CFR_OT_close_preview(Operator):
    bl_idname = "cfr.close_preview"
    bl_label = "Back"

    def execute(self, context):
        return {"FINISHED"}


class CFR_OT_next_preview_candidate(Operator):
    bl_idname = "cfr.next_preview_candidate"
    bl_label = "Next Candidate"
    bl_description = "Show the next possible match for this missing file"

    def execute(self, context):
        settings = context.scene.cfr_settings
        item = _active_item(settings)
        if item is None or not item.candidates:
            settings.preview_status = "There are no more possible matches for this file."
            return {"CANCELLED"}

        current = item.active_candidate_index
        if current < 0:
            current = 0
        else:
            current = (current + 1) % len(item.candidates)
        item.active_candidate_index = current

        candidate = _active_candidate(item)
        settings.preview_image = None
        if candidate is None:
            settings.preview_status = "There are no more possible matches for this file."
        elif not os.path.isfile(candidate.path):
            settings.preview_status = "This candidate file no longer exists."
        elif os.path.splitext(candidate.path)[1].lower() not in IMAGE_EXTENSIONS:
            settings.preview_status = "No visual preview for this file type. You can still map it."
        else:
            try:
                settings.preview_image = bpy.data.images.load(candidate.path, check_existing=True)
                settings.preview_status = "Image preview loaded. Stage this match only if it is the correct file."
            except Exception as exc:
                settings.preview_status = f"Blender could not preview this image: {exc}"

        _tag_all_redraws()
        return {"FINISHED"}


class CFR_OT_copy_path(Operator):
    bl_idname = "cfr.copy_path"
    bl_label = "Copy Path"
    bl_description = "Copy the full path to the clipboard"

    full_path: StringProperty(options={"HIDDEN"})

    @classmethod
    def description(cls, context, properties):
        path = str(properties.full_path or "")
        return path if path else "No stored path is available."

    def execute(self, context):
        if not self.full_path:
            self.report({"WARNING"}, "No stored path is available")
            return {"CANCELLED"}
        context.window_manager.clipboard = self.full_path
        context.scene.cfr_settings.last_action = "Copied the full original path to the clipboard."
        _tag_all_redraws()
        return {"FINISHED"}


class CFR_OT_map_selected_candidate(Operator):
    bl_idname = "cfr.map_selected_candidate"
    bl_label = "Stage Match"
    bl_description = "Stage the selected possible match; nothing changes until Save New Mappings"

    def execute(self, context):
        settings = context.scene.cfr_settings
        item = _active_item(settings)
        candidate = _active_candidate(item)
        if item is None or candidate is None:
            settings.last_action = "Select a missing file and one possible match first."
            return {"CANCELLED"}
        if not os.path.isfile(candidate.path):
            settings.last_action = "That candidate file no longer exists."
            return {"CANCELLED"}
        try:
            _stage_reference_path(
                context.scene,
                item,
                candidate.path,
                "Match found after candidate review. Not applied to Blender yet.",
            )
            settings.preview_status = "✓ Match found — not applied yet. Use Save New Mappings in the main window to apply it."
            settings.last_action = (
                f"Staged match: {item.match_name} → {candidate.name}. "
                "No Blender filepath has changed yet."
            )
            _tag_all_redraws()
            return {"FINISHED"}
        except Exception as exc:
            settings.last_action = f"Could not stage this mapping: {exc}"
            return {"CANCELLED"}


class CFR_OT_choose_any_replacement(Operator):
    bl_idname = "cfr.choose_any_replacement"
    bl_label = "Choose Another File"
    bl_description = "Browse to a file manually when no suggested match is correct"

    filepath: StringProperty(subtype="FILE_PATH")
    filter_glob: StringProperty(default="*", options={"HIDDEN"})

    def invoke(self, context, event):
        if _active_item(context.scene.cfr_settings) is None:
            self.report({"WARNING"}, "Select a missing file first")
            return {"CANCELLED"}
        context.window_manager.fileselect_add(self)
        return {"RUNNING_MODAL"}

    def execute(self, context):
        settings = context.scene.cfr_settings
        item = _active_item(settings)
        if item is None or not self.filepath or not os.path.isfile(self.filepath):
            settings.last_action = "Choose an existing file."
            return {"CANCELLED"}
        try:
            path = _normalise_path(self.filepath)
            _stage_reference_path(
                context.scene,
                item,
                path,
                "Chosen manually. Match found — not applied to Blender yet.",
            )
            settings.last_action = (
                f"Staged match for {item.match_name}. "
                "No Blender filepath has changed yet."
            )
            _tag_all_redraws()
            return {"FINISHED"}
        except Exception as exc:
            settings.last_action = f"Could not stage this mapping: {exc}"
            return {"CANCELLED"}


class CFR_OT_remove_pending_mapping(Operator):
    bl_idname = "cfr.remove_pending_mapping"
    bl_label = "Remove Staged Match"
    bl_description = "Remove the staged match for the selected file without changing Blender"

    def execute(self, context):
        settings = context.scene.cfr_settings
        item = _active_item(settings)
        if item is None or item.status != "PENDING":
            settings.last_action = "Select a staged match first."
            return {"CANCELLED"}
        _discard_pending_mappings_for_item(context.scene, item)
        _tag_all_redraws()
        return {"FINISHED"}


class CFR_OT_discard_pending_mappings(Operator):
    bl_idname = "cfr.discard_pending_mappings"
    bl_label = "Discard Staged Matches"
    bl_description = "Discard all staged mappings; no Blender file paths will be changed"
    bl_options = {"REGISTER"}

    def invoke(self, context, event):
        if _pending_mapping_count(context.scene.cfr_settings) == 0:
            self.report({"INFO"}, "There are no staged matches")
            return {"CANCELLED"}
        return context.window_manager.invoke_confirm(
            self,
            event,
            title="Discard Staged Matches?",
            confirm_text="Discard Staged Matches",
        )

    def execute(self, context):
        _discard_pending_mappings(context.scene)
        _tag_all_redraws()
        return {"FINISHED"}


class CFR_OT_preview_staged_mappings(Operator):
    bl_idname = "cfr.preview_staged_mappings"
    bl_label = "Preview Changes"
    bl_description = "Review every staged match before applying it to Blender"
    bl_options = {"REGISTER"}

    def invoke(self, context, event):
        settings = context.scene.cfr_settings
        if _pending_mapping_count(settings) == 0:
            self.report({"INFO"}, "There are no staged matches to preview")
            return {"CANCELLED"}
        _populate_staged_preview_items(settings)
        return context.window_manager.invoke_props_dialog(
            self,
            width=1120,
            title="CINAEDVS — Preview Changes",
            confirm_text="Close Preview",
            cancel_default=True,
        )

    def execute(self, context):
        _clear_staged_preview_image(context.scene.cfr_settings)
        return {"FINISHED"}

    def cancel(self, context):
        _clear_staged_preview_image(context.scene.cfr_settings)

    def draw(self, context):
        settings = context.scene.cfr_settings
        layout = self.layout
        layout.use_property_split = False
        layout.use_property_decorate = False

        summary = layout.box()
        total = len(settings.staged_preview_items)
        summary.label(text=f"{total} Match Found — review before Save New Mappings", icon=ICON_MATCH_FOUND)
        summary.label(text="These changes are staged only. Nothing in Blender has been changed yet.", icon="INFO")

        columns = layout.row(align=True)
        left = columns.column()
        right = columns.column()

        left_box = left.box()
        left_box.label(text="STAGED MAPPINGS", icon="FILE")
        if settings.staged_preview_items:
            left_box.template_list(
                "CFR_UL_staged_preview", "", settings, "staged_preview_items", settings,
                "active_staged_preview_index", rows=12,
            )
        else:
            left_box.label(text="No staged mappings remain.", icon="INFO")

        right_box = right.box()
        right_box.label(text="PREVIEW", icon="HIDE_OFF")
        idx = settings.active_staged_preview_index
        selected = None
        if 0 <= idx < len(settings.staged_preview_items):
            selected = settings.staged_preview_items[idx]
            right_box.label(text=_display_path(selected.name, 64), icon="FILE")
            right_box.label(text=_display_path(selected.path, 88), icon="FILE_FOLDER")
        else:
            right_box.label(text="Select a staged mapping from the list.", icon="INFO")

        if settings.staged_preview_image is not None:
            try:
                right_box.template_ID_preview(
                    settings, "staged_preview_image", rows=10, cols=10, hide_buttons=True
                )
            except Exception:
                right_box.label(text="Preview image loaded, but this Blender UI could not draw it here.", icon="IMAGE")
        else:
            placeholder = right_box.box()
            placeholder.label(text=settings.staged_preview_status, icon="INFO")
            placeholder.label(text="Non-image files can still be removed from the staged changes.")

        action_row = layout.row(align=True)
        action_row.scale_y = 1.25
        remove_row = action_row.row(align=True)
        remove_row.enabled = selected is not None
        remove_row.operator(
            "cfr.remove_previewed_staged_mapping", text="Remove Mapping", icon="X"
        )
        copy_row = action_row.row(align=True)
        copy_row.enabled = selected is not None
        copy_row.operator("cfr.copy_staged_preview_path", text="Copy File Path", icon="COPYDOWN")


class CFR_OT_remove_previewed_staged_mapping(Operator):
    bl_idname = "cfr.remove_previewed_staged_mapping"
    bl_label = "Remove Mapping"
    bl_description = "Discard this staged match without changing Blender"

    def execute(self, context):
        settings = context.scene.cfr_settings
        idx = settings.active_staged_preview_index
        if not (0 <= idx < len(settings.staged_preview_items)):
            self.report({"WARNING"}, "Select a staged mapping first")
            return {"CANCELLED"}
        ref_key = settings.staged_preview_items[idx].ref_key
        item = _find_item_by_ref_key(settings, ref_key)
        if item is None or item.status != "PENDING":
            _populate_staged_preview_items(settings)
            self.report({"WARNING"}, "That staged mapping is no longer available")
            return {"CANCELLED"}
        filename = item.match_name
        _discard_pending_mappings_for_item(context.scene, item)
        _populate_staged_preview_items(settings)
        settings.last_action = f"Removed staged mapping for {filename}. No Blender filepath was changed."
        _tag_all_redraws()
        return {"FINISHED"}


class CFR_OT_copy_staged_preview_path(Operator):
    bl_idname = "cfr.copy_staged_preview_path"
    bl_label = "Copy File Path"
    bl_description = "Copy the full staged replacement path to the clipboard"

    def execute(self, context):
        settings = context.scene.cfr_settings
        idx = settings.active_staged_preview_index
        if not (0 <= idx < len(settings.staged_preview_items)):
            return {"CANCELLED"}
        path = settings.staged_preview_items[idx].path
        if not path:
            return {"CANCELLED"}
        context.window_manager.clipboard = path
        self.report({"INFO"}, "Copied staged file path")
        return {"FINISHED"}


class CFR_OT_discard_from_close_warning(Operator):
    bl_idname = "cfr.discard_from_close_warning"
    bl_label = "Discard Matches Found"
    bl_description = "Discard all found matches and return to File Rescue without changing Blender"
    bl_options = {"REGISTER"}

    def execute(self, context):
        settings = context.scene.cfr_settings
        discarded = _discard_pending_mappings(context.scene)
        if discarded:
            settings.last_action = (
                f"Discarded {discarded} match(es). No Blender filepath was changed. "
                "Click Cancel to return to File Rescue."
            )
            self.report({"INFO"}, f"Discarded {discarded} match(es)")
        else:
            settings.last_action = "There were no found matches left to discard."
        _tag_all_redraws()
        return {"FINISHED"}


class CFR_OT_pending_close_warning(Operator):
    bl_idname = "cfr.pending_close_warning"
    bl_label = "Matches Found Have Not Been Applied"
    bl_options = {"REGISTER"}

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(
            self,
            width=700,
            title="CINAEDVS — Matches Found Have Not Been Applied",
            confirm_text="Save New Mappings",
            cancel_default=True,
        )

    def execute(self, context):
        ok, message = _commit_pending_mappings(context.scene)
        context.scene.cfr_settings.last_action = message
        if not ok:
            self.report({"WARNING"}, message)
            return {"CANCELLED"}
        self.report({"INFO"}, message)
        _tag_all_redraws()
        return {"FINISHED"}

    def cancel(self, context):
        # Native props dialogs have no third button. Cancel means keep every
        # pending mapping and return to the main editor; explicit discard stays
        # available there as its own guarded button.
        bpy.ops.cfr.launch("INVOKE_DEFAULT", skip_intro=True)

    def draw(self, context):
        settings = context.scene.cfr_settings
        pending = _pending_mapping_count(settings)
        layout = self.layout
        warning = layout.box()

        if pending:
            warning.label(text="Your matched file paths have not been applied yet.", icon="ERROR")
            warning.label(
                text=f"You have {pending} match(es) found. They only exist inside CINAEDVS right now.",
                icon="TIME",
            )
            warning.separator()
            warning.label(text="Save New Mappings applies them to Blender and saves this .blend file.", icon="CHECKMARK")
            warning.label(text="Discard Matches Found removes every staged match without changing Blender.", icon="TRASH")

            discard_row = warning.row(align=True)
            discard_row.scale_y = 1.15
            discard_row.operator(
                "cfr.discard_from_close_warning",
                text="Discard Matches Found",
                icon="TRASH",
            )
        else:
            warning.label(text="All found matches have been discarded.", icon="CHECKMARK")
            warning.label(text="No Blender file paths were changed.", icon="INFO")
            warning.label(text="Click Cancel to return to File Rescue.", icon="BACK")


class CFR_OT_ignore_selected(Operator):
    bl_idname = "cfr.ignore_selected"
    bl_label = "Ignore"
    bl_description = "Ignore the selected missing reference for this session"

    def execute(self, context):
        settings = context.scene.cfr_settings
        item = _active_item(settings)
        if item is None:
            settings.last_action = "Select a missing file first."
            return {"CANCELLED"}
        _clear_candidates(item)
        _set_item_status(item, "SKIPPED", note="Ignored by user for this session.")
        settings.last_action = f"Ignored {item.match_name}."
        _tag_all_redraws()
        return {"FINISHED"}


class CFR_OT_show_linked_objects(Operator):
    bl_idname = "cfr.show_linked_objects"
    bl_label = "Linked Objects"
    bl_description = "Show the scene objects that use the selected missing file"
    bl_options = {"REGISTER"}

    def invoke(self, context, event):
        settings = context.scene.cfr_settings
        item = _active_item(settings)
        if item is None:
            self.report({"WARNING"}, "Select a missing file first")
            return {"CANCELLED"}
        _rebuild_linked_objects(context.scene)
        return context.window_manager.invoke_props_dialog(
            self,
            width=900,
            title="CINAEDVS — Linked Objects",
            confirm_text="Close",
            cancel_default=True,
        )

    def execute(self, context):
        return {"FINISHED"}

    def draw(self, context):
        settings = context.scene.cfr_settings
        layout = self.layout
        layout.use_property_split = False
        layout.use_property_decorate = False

        header = layout.box()
        header.label(text="LINKED OBJECTS", icon="OUTLINER_OB_GROUP_INSTANCE")
        header.label(
            text=f"Selected missing file: {_display_path(settings.linked_file_label or 'No file selected', 84)}",
            icon="FILE",
        )
        if settings.linked_objects:
            header.label(text=f"{len(settings.linked_objects)} object use(s) in this scene", icon="INFO")
        else:
            header.label(text="No scene objects currently use this file.", icon="INFO")

        if not settings.linked_objects:
            return

        layout.template_list(
            "CFR_UL_linked_objects", "", settings, "linked_objects", settings,
            "active_linked_object_index", rows=10,
        )
        selected = None
        if 0 <= settings.active_linked_object_index < len(settings.linked_objects):
            selected = settings.linked_objects[settings.active_linked_object_index]

        details = layout.box()
        details.label(text="SELECTED OBJECT", icon="OBJECT_DATA")
        if selected is not None:
            details.label(text=f"{selected.object_name} · {selected.object_type} · {selected.usage}")
            if selected.material_name:
                details.label(text=f"Material: {selected.material_name}")
            if selected.node_name:
                details.label(text=f"Node: {selected.node_name}")
            details.label(text=f"Collection: {_display_path(selected.collection_name, 82)}")
            details.separator()
            actions = details.row(align=True)
            actions.scale_y = 1.2
            actions.operator("cfr.open_object_preview", text="Preview Object", icon="HIDE_OFF")
            details.label(
                text="Preview opens in its own window and does not change the Blender scene, selection or viewport behind it.",
                icon="LOCKED",
            )


class CFR_OT_open_object_preview(Operator):
    bl_idname = "cfr.open_object_preview"
    bl_label = "Object Preview"
    bl_description = "Open an isolated low-quality preview that does not touch the main Blender window"
    bl_options = {"REGISTER"}

    def invoke(self, context, event):
        settings = context.scene.cfr_settings
        if settings.linked_preview_object is None:
            self.report({"WARNING"}, "Select a linked object first")
            return {"CANCELLED"}
        settings.linked_preview_mode = "SOLID"
        settings.linked_preview_azimuth = 38.0
        settings.linked_preview_elevation = 21.0
        settings.linked_preview_zoom = 1.0
        ok, message = _render_isolated_object_preview(context, settings)
        settings.linked_preview_status = message
        if not ok:
            self.report({"WARNING"}, message)
        _tag_all_redraws()
        return context.window_manager.invoke_props_dialog(
            self,
            width=680,
            title="CINAEDVS — Object Preview",
            confirm_text="Close Preview",
            cancel_default=True,
        )

    def execute(self, context):
        return {"FINISHED"}

    def draw(self, context):
        settings = context.scene.cfr_settings
        layout = self.layout
        layout.use_property_split = False
        layout.use_property_decorate = False

        header = layout.box()
        header.label(text="OBJECT PREVIEW", icon="HIDE_OFF")
        obj = settings.linked_preview_object
        header.label(text=f"{obj.name_full if obj else 'No selected object'}", icon="OBJECT_DATA")
        header.label(text="This preview is rendered in a temporary scene. The Blender window behind it is never modified.", icon="LOCKED")

        controls = layout.row(align=True)
        solid = controls.operator("cfr.set_object_preview_mode", text="Solid", icon="SHADING_SOLID")
        solid.mode = "SOLID"
        material = controls.operator("cfr.set_object_preview_mode", text="Material Preview", icon="SHADING_TEXTURE")
        material.mode = "MATERIAL"

        view = layout.row(align=True)
        left = view.operator("cfr.adjust_object_preview", text="Rotate Left", icon="TRIA_LEFT")
        left.action = "LEFT"
        right = view.operator("cfr.adjust_object_preview", text="Rotate Right", icon="TRIA_RIGHT")
        right.action = "RIGHT"
        zoom_in = view.operator("cfr.adjust_object_preview", text="Zoom In", icon="ZOOM_IN")
        zoom_in.action = "ZOOM_IN"
        zoom_out = view.operator("cfr.adjust_object_preview", text="Zoom Out", icon="ZOOM_OUT")
        zoom_out.action = "ZOOM_OUT"
        reset = view.operator("cfr.adjust_object_preview", text="Reset View", icon="FILE_REFRESH")
        reset.action = "RESET"

        preview = layout.box()
        if settings.linked_preview_texture is not None:
            try:
                preview.template_preview(settings.linked_preview_texture)
            except Exception:
                try:
                    preview.template_ID_preview(settings, "linked_preview_texture", rows=10, cols=10, hide_buttons=True)
                except Exception:
                    preview.label(text="The preview image was created, but this Blender UI could not draw it here.", icon="ERROR")
        elif settings.linked_preview_image is not None:
            try:
                preview.template_ID_preview(settings, "linked_preview_image", rows=10, cols=10, hide_buttons=True)
            except Exception:
                preview.label(text="The preview image was created, but this Blender UI could not draw it here.", icon="ERROR")
        else:
            preview.label(text="No preview image was created.", icon="ERROR")
        preview.label(text=settings.linked_preview_status, icon="INFO")
        layout.label(text="Rotation and zoom controls affect only this temporary preview render.", icon="INFO")


class CFR_OT_set_object_preview_mode(Operator):
    bl_idname = "cfr.set_object_preview_mode"
    bl_label = "Set Preview Mode"
    mode: EnumProperty(
        items=(("SOLID", "Solid", "Solid low-quality preview"),
               ("MATERIAL", "Material Preview", "Rendered material preview")),
        options={"HIDDEN"},
        default="SOLID",
    )

    def execute(self, context):
        settings = context.scene.cfr_settings
        settings.linked_preview_mode = self.mode
        ok, message = _render_isolated_object_preview(context, settings)
        settings.linked_preview_status = message
        if not ok:
            self.report({"WARNING"}, message)
            return {"CANCELLED"}
        _tag_all_redraws()
        return {"FINISHED"}


class CFR_OT_adjust_object_preview(Operator):
    bl_idname = "cfr.adjust_object_preview"
    bl_label = "Adjust Preview"
    action: EnumProperty(
        items=(("LEFT", "Rotate Left", "Rotate left"),
               ("RIGHT", "Rotate Right", "Rotate right"),
               ("ZOOM_IN", "Zoom In", "Zoom in"),
               ("ZOOM_OUT", "Zoom Out", "Zoom out"),
               ("RESET", "Reset View", "Reset preview view")),
        options={"HIDDEN"},
    )

    def execute(self, context):
        settings = context.scene.cfr_settings
        if self.action == "LEFT":
            settings.linked_preview_azimuth -= 20.0
        elif self.action == "RIGHT":
            settings.linked_preview_azimuth += 20.0
        elif self.action == "ZOOM_IN":
            settings.linked_preview_zoom = max(0.55, settings.linked_preview_zoom * 0.82)
        elif self.action == "ZOOM_OUT":
            settings.linked_preview_zoom = min(3.2, settings.linked_preview_zoom * 1.22)
        elif self.action == "RESET":
            settings.linked_preview_azimuth = 38.0
            settings.linked_preview_elevation = 21.0
            settings.linked_preview_zoom = 1.0
        ok, message = _render_isolated_object_preview(context, settings)
        settings.linked_preview_status = message
        if not ok:
            self.report({"WARNING"}, message)
            return {"CANCELLED"}
        _tag_all_redraws()
        return {"FINISHED"}

__all__ = ['CFR_OT_scan_missing_files', 'CFR_OT_set_all_filters', 'CFR_OT_clear_all_filters', 'CFR_OT_toggle_staged_visibility', 'CFR_OT_stage_matches_above_threshold', 'CFR_OT_choose_scan_folder', 'CFR_OT_refresh_folders', 'CFR_OT_up_folder', 'CFR_OT_open_selected_folder', 'CFR_OT_search_drive_for_file', 'CFR_OT_review_drive_result', 'CFR_OT_start_folder_scan', 'CFR_OT_cancel_scan', 'CFR_OT_preview_candidate', 'CFR_OT_close_preview', 'CFR_OT_next_preview_candidate', 'CFR_OT_copy_path', 'CFR_OT_map_selected_candidate', 'CFR_OT_choose_any_replacement', 'CFR_OT_remove_pending_mapping', 'CFR_OT_discard_pending_mappings', 'CFR_OT_preview_staged_mappings', 'CFR_OT_remove_previewed_staged_mapping', 'CFR_OT_copy_staged_preview_path', 'CFR_OT_discard_from_close_warning', 'CFR_OT_pending_close_warning', 'CFR_OT_ignore_selected', 'CFR_OT_show_linked_objects', 'CFR_OT_open_object_preview', 'CFR_OT_set_object_preview_mode', 'CFR_OT_adjust_object_preview']
