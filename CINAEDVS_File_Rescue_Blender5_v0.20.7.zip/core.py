# SPDX-FileCopyrightText: 2026 Chris
# SPDX-License-Identifier: GPL-3.0-or-later

"""Shared constants, runtime state, reference scanning, matching, and preview helpers."""

import math
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import time
import bpy
from mathutils import Matrix, Vector
from bpy.props import (
    BoolProperty,
    CollectionProperty,
    IntProperty,
    EnumProperty,
    FloatProperty,
    PointerProperty,
    StringProperty,
)
from bpy.types import Menu, Operator, Panel, PropertyGroup, UIList

APP_NAME = "CINAEDVS File Rescue"

# Native Blender icons used consistently throughout the extension. These are
# deliberately named icons, so they respect the user's Blender theme.
ICON_MATCH_FOUND = "LINKED"       # The linked-node mark Chris selected
ICON_POSSIBLE_MATCH = "NODETREE"  # The dotted node/candidate mark Chris selected
ICON_MISSING = "X"                # The bracketed X mark Chris selected
ICON_SAVED = "FILE_TICK"
ICON_IGNORED = "HIDE_ON"
HARD_MAX_DEPTH = 6
HARD_MAX_FILES = 100000
MAX_FUZZY_CANDIDATES = 8
FUZZY_MIN_SCORE = 0.56

KIND_LABELS = {
    "IMAGE": "Textures / Materials",
    "LIBRARY": "Models / Libraries",
    "MOVIECLIP": "Video",
    "SOUND": "Audio",
    "FONT": "Fonts",
    "VOLUME": "Volumes / Caches",
    "CACHEFILE": "Volumes / Caches",
    "TEXT": "Text Documents",
    "SEQUENCE": "Video Sequencer",
    "LIGHT": "IES Lighting",
}

IMAGE_EXTENSIONS = {
    ".bmp", ".dds", ".exr", ".gif", ".hdr", ".jpeg", ".jpg", ".png",
    ".psd", ".tga", ".tif", ".tiff", ".webp",
}

_RUNTIME = {
    "process": None,
    "cancel_requested": False,
    "cancel_requested_at": 0.0,
    "request_file": "",
    "status_file": "",
    "result_file": "",
    "cancel_file": "",
    "temp_dir": "",
    "last_status_sequence": -1,
    "running": False,
    "timer_registered": False,
    "scene_name": "",
    "mode": "folder",
    # Built fresh by every Scan Missing Files pass. It keeps the direct
    # setter for each reference so linked properties and non-image sources
    # can be repaired without relying on a small hard-coded data-block list.
    "reference_map": {},
}


# -----------------------------------------------------------------------------
# General helpers
# -----------------------------------------------------------------------------

def _normalise_path(path):
    return os.path.normcase(os.path.normpath(os.path.abspath(path)))


def _safe_abspath(filepath, library=None):
    try:
        return _normalise_path(bpy.path.abspath(filepath, library=library))
    except Exception:
        return _normalise_path(filepath)


def _display_path(path, max_len=96):
    path = str(path or "")
    if len(path) <= max_len:
        return path
    return "…" + path[-(max_len - 1):]


def _match_name(filepath):
    return os.path.basename((filepath or "").replace("\\", "/"))


def _base_stem(filename):
    stem = os.path.splitext(os.path.basename(filename or ""))[0].lower()
    return re.sub(r"[^a-z0-9]+", "", stem)


def _name_tokens(filename):
    stem = os.path.splitext(os.path.basename(filename or ""))[0].lower()
    return {token for token in re.split(r"[^a-z0-9]+", stem) if len(token) >= 3}


def _tag_all_redraws():
    try:
        for window in bpy.context.window_manager.windows:
            if window.screen is None:
                continue
            for area in window.screen.areas:
                area.tag_redraw()
    except Exception:
        pass


def _active_item(settings):
    index = settings.active_missing_index
    if 0 <= index < len(settings.missing_files):
        return settings.missing_files[index]
    return None


def _active_candidate(item):
    if item is None:
        return None
    index = item.active_candidate_index
    if 0 <= index < len(item.candidates):
        return item.candidates[index]
    return None


def _active_drive_result(settings):
    index = settings.active_drive_result_index
    if 0 <= index < len(settings.drive_results):
        return settings.drive_results[index]
    return None


def _find_item_by_ref_key(settings, ref_key):
    for item in settings.missing_files:
        if item.ref_key == ref_key:
            return item
    return None


def _clear_staged_preview_image(settings):
    """Remove only the temporary image datablock created for Preview Changes."""
    image = settings.staged_preview_image
    settings.staged_preview_image = None
    settings.staged_preview_status = "Select a staged match to preview it."
    if image is None:
        return
    try:
        if image.name.startswith("__CFR_STAGED_PREVIEW__") and image.users == 0:
            bpy.data.images.remove(image)
    except Exception:
        pass


def _load_staged_preview_image(settings):
    """Load a temporary thumbnail image for the active staged match, if visual."""
    _clear_staged_preview_image(settings)
    index = settings.active_staged_preview_index
    if not (0 <= index < len(settings.staged_preview_items)):
        settings.staged_preview_status = "There are no staged matches to preview."
        return

    row = settings.staged_preview_items[index]
    path = row.path
    if not path or not os.path.isfile(path):
        settings.staged_preview_status = "This staged file no longer exists at the stored path."
        return

    extension = os.path.splitext(path)[1].lower()
    if extension not in IMAGE_EXTENSIONS:
        settings.staged_preview_status = (
            f"No visual preview is available for {extension or 'this'} file type. "
            "You can still remove the staged mapping."
        )
        return

    try:
        image = bpy.data.images.load(path, check_existing=False)
        image.name = "__CFR_STAGED_PREVIEW__" + os.path.basename(path)
        settings.staged_preview_image = image
        settings.staged_preview_status = "Preview only. This mapping is not applied until Save New Mappings."
    except Exception as exc:
        settings.staged_preview_status = f"Blender could not load this preview: {exc}"


def _update_staged_preview_active(settings, _context):
    _load_staged_preview_image(settings)


def _populate_staged_preview_items(settings):
    _clear_staged_preview_image(settings)
    settings.staged_preview_items.clear()
    for item in settings.missing_files:
        if item.status != "PENDING":
            continue
        row = settings.staged_preview_items.add()
        row.ref_key = item.ref_key
        row.name = item.match_name or _match_name(item.resolved_path) or "Unnamed external file"
        row.kind = KIND_LABELS.get(item.kind, item.kind)
        row.path = item.resolved_path

    if settings.staged_preview_items:
        settings.active_staged_preview_index = 0
        _load_staged_preview_image(settings)
    else:
        settings.active_staged_preview_index = -1
        settings.staged_preview_status = "There are no staged matches to preview."


def _available_drive_items(_self=None, _context=None):
    """Return currently mounted roots for the selected-drive search dialog."""
    if os.name == "nt":
        rows = []
        for letter in "ABCDEFGHIJKLMNOPQRSTUVWXYZ":
            root = f"{letter}:\\"
            if os.path.isdir(root):
                rows.append((root, root, f"Search the full {root} drive"))
        return rows or [("C:\\", "C:\\", "Search the full C: drive")]
    return [(os.path.sep, os.path.sep, "Search the full mounted root")]


def _status_text(item):
    if item.status == "FIXED":
        return "[✓] Saved"
    if item.status == "PENDING":
        return "[~] Match Found"
    if item.status == "REVIEW":
        count = item.candidate_count or len(item.candidates)
        return f"[!] {count} possible match{'es' if count != 1 else ''}"
    if item.status == "SKIPPED":
        return "[-] Ignored"
    return "[X] Missing"


def _status_icon(item):
    """Return the compact, user-selected status icon for one file row."""
    if item.status == "FIXED":
        return ICON_SAVED
    if item.status == "PENDING":
        return ICON_MATCH_FOUND
    if item.status == "REVIEW":
        return ICON_POSSIBLE_MATCH
    if item.status == "SKIPPED":
        return ICON_IGNORED
    return ICON_MISSING


def _set_item_status(item, status, resolved_path="", candidates=0, note=""):
    item.status = status
    item.resolved_path = resolved_path
    item.candidate_count = candidates
    item.note = note


def _clear_candidates(item):
    item.candidates.clear()
    item.active_candidate_index = -1
    item.candidate_count = 0


def _add_candidates(item, candidate_rows):
    _clear_candidates(item)
    for candidate in candidate_rows:
        row = item.candidates.add()
        row.path = candidate["path"]
        row.name = os.path.basename(candidate["path"])
        row.score = int(candidate.get("score", 0))
        row.match_type = candidate.get("match_type", "Possible")
    item.candidate_count = len(item.candidates)
    item.active_candidate_index = 0 if item.candidates else -1


# -----------------------------------------------------------------------------
# Filters and missing reference discovery
# -----------------------------------------------------------------------------

def _kind_enabled(settings, kind):
    if kind == "IMAGE":
        return settings.filter_materials
    if kind == "LIBRARY":
        return settings.filter_models
    if kind == "MOVIECLIP":
        return settings.filter_video
    if kind == "SOUND":
        return settings.filter_audio
    if kind == "FONT":
        return settings.filter_fonts
    if kind in {"VOLUME", "CACHEFILE"}:
        return settings.filter_caches
    if kind in {"TEXT", "SEQUENCE", "LIGHT"}:
        return settings.filter_other
    return False


def _selected_filter_count(settings):
    return sum((
        settings.filter_materials,
        settings.filter_models,
        settings.filter_video,
        settings.filter_audio,
        settings.filter_fonts,
        settings.filter_caches,
        settings.filter_other,
    ))


def _set_all_filters(settings, value):
    settings.filter_materials = value
    settings.filter_models = value
    settings.filter_video = value
    settings.filter_audio = value
    settings.filter_fonts = value
    settings.filter_caches = value
    settings.filter_other = value


def _looks_like_filename(value):
    value = str(value or "").strip()
    return bool(os.path.splitext(os.path.basename(value))[1])


def _reference_key(kind, owner, slot, ordinal):
    try:
        owner_pointer = owner.as_pointer()
    except Exception:
        owner_pointer = id(owner)
    return f"{kind}|{owner_pointer}|{slot}|{ordinal}"


def _make_reference(kind, owner, raw_path, set_path, slot, ordinal, label=None, name_hint=""):
    """Create a session-only external-reference descriptor.

    `set_path` is intentionally kept outside Blender properties: v0.5 tried to
    recover every item via a named data-block lookup, which misses blank path
    records and can only repair the few hard-coded data types. The runtime map
    lets the UI repair the exact property it discovered.
    """
    raw_path = str(raw_path or "")
    label = label or getattr(owner, "name", kind)
    name_hint = str(name_hint or getattr(owner, "name", "") or "")
    library = getattr(owner, "library", None)
    return {
        "key": _reference_key(kind, owner, slot, ordinal),
        "kind": kind,
        "owner": owner,
        "raw_path": raw_path,
        "set_path": set_path,
        "label": label,
        "name_hint": name_hint,
        "library": library,
    }


def _set_direct_filepath(owner, path):
    owner.filepath = path
    try:
        if hasattr(owner, "reload"):
            owner.reload()
    except Exception:
        # Updating the stored path is still useful; Blender may reload it when
        # the dependency graph next evaluates.
        pass


def _iter_external_references():
    """Yield the common external resources Blender tracks in an open file.

    The previous build skipped every empty filepath. Blender's own report can
    still flag those records, particularly imported image datablocks whose
    display name retains the original texture filename. They are now included
    and use that name for exact/fuzzy matching whenever possible.
    """
    ordinal = 0

    def emit(kind, owner, raw_path, setter, slot, label=None, name_hint="", include_blank=False):
        nonlocal ordinal
        raw_path = str(raw_path or "")
        if not raw_path and not include_blank:
            return
        ordinal += 1
        yield _make_reference(
            kind, owner, raw_path, setter, slot, ordinal,
            label=label, name_hint=name_hint,
        )

    # Images: this deliberately includes imported/generated image data blocks
    # whose names are still texture filenames. Blender's own relinker can emit
    # missing-file warnings for those even when their stored filepath is blank.
    # Pure viewer/render-result placeholders still have neither a path nor a
    # file-looking name, so they remain excluded.
    for image in bpy.data.images:
        if getattr(image, "packed_file", None):
            continue
        source = getattr(image, "source", "FILE")
        raw = getattr(image, "filepath", "")
        include_blank = (
            source in {"FILE", "MOVIE", "SEQUENCE", "TILED"}
            or _looks_like_filename(image.name)
        )
        if not raw and not include_blank:
            continue
        yield from emit(
            "IMAGE", image, raw,
            lambda path, item=image: _set_direct_filepath(item, path),
            "filepath", label=f"Image: {image.name}", name_hint=image.name,
            include_blank=include_blank,
        )

    for sound in bpy.data.sounds:
        if getattr(sound, "packed_file", None):
            continue
        raw = getattr(sound, "filepath", "")
        yield from emit(
            "SOUND", sound, raw,
            lambda path, item=sound: _set_direct_filepath(item, path),
            "filepath", label=f"Sound: {sound.name}", name_hint=sound.name,
        )

    for clip in bpy.data.movieclips:
        raw = getattr(clip, "filepath", "")
        yield from emit(
            "MOVIECLIP", clip, raw,
            lambda path, item=clip: _set_direct_filepath(item, path),
            "filepath", label=f"Movie Clip: {clip.name}", name_hint=clip.name,
        )

    for font in bpy.data.fonts:
        if getattr(font, "packed_file", None):
            continue
        raw = getattr(font, "filepath", "")
        if raw == "<builtin>":
            continue
        yield from emit(
            "FONT", font, raw,
            lambda path, item=font: _set_direct_filepath(item, path),
            "filepath", label=f"Font: {font.name}", name_hint=font.name,
        )

    for volume in bpy.data.volumes:
        raw = getattr(volume, "filepath", "")
        yield from emit(
            "VOLUME", volume, raw,
            lambda path, item=volume: _set_direct_filepath(item, path),
            "filepath", label=f"Volume: {volume.name}", name_hint=volume.name,
        )

    for cache_file in getattr(bpy.data, "cache_files", []):
        raw = getattr(cache_file, "filepath", "")
        yield from emit(
            "CACHEFILE", cache_file, raw,
            lambda path, item=cache_file: _set_direct_filepath(item, path),
            "filepath", label=f"Cache: {cache_file.name}", name_hint=cache_file.name,
        )

    for library in bpy.data.libraries:
        raw = getattr(library, "filepath", "")
        yield from emit(
            "LIBRARY", library, raw,
            lambda path, item=library: _set_direct_filepath(item, path),
            "filepath", label=f"Linked Library: {library.name}", name_hint=library.name,
        )

    # Text blocks can be linked to a file independently of fonts and images.
    for text in bpy.data.texts:
        raw = getattr(text, "filepath", "")
        yield from emit(
            "TEXT", text, raw,
            lambda path, item=text: _set_direct_filepath(item, path),
            "filepath", label=f"Text: {text.name}", name_hint=text.name,
        )

    # IES profiles are an external dependency of lights in Blender versions
    # that expose a file-path property. Guard every access for API changes.
    for light in bpy.data.lights:
        for attr in ("ies_file", "ies_filepath"):
            raw = getattr(light, attr, None)
            if not isinstance(raw, str) or not raw:
                continue
            yield from emit(
                "LIGHT", light, raw,
                lambda path, item=light, prop=attr: setattr(item, prop, path),
                attr, label=f"IES Light: {light.name}", name_hint=os.path.basename(raw),
            )
            break

    # VSE images and movies are sometimes only owned by strips rather than an
    # image/movie datablock. The code is deliberately defensive because the
    # Sequencer RNA changed around Blender 5.
    for scene in bpy.data.scenes:
        editor = getattr(scene, "sequence_editor", None)
        if editor is None:
            continue
        strips = (
            getattr(editor, "sequences_all", None)
            or getattr(editor, "strips_all", None)
            or getattr(editor, "sequences", None)
            or getattr(editor, "strips", None)
            or []
        )
        seen = set()
        for strip in strips:
            try:
                ptr = strip.as_pointer()
            except Exception:
                ptr = id(strip)
            if ptr in seen:
                continue
            seen.add(ptr)

            strip_name = getattr(strip, "name", "Sequencer Strip")
            direct_path = getattr(strip, "filepath", "")
            if isinstance(direct_path, str) and direct_path:
                yield from emit(
                    "SEQUENCE", strip, direct_path,
                    lambda path, item=strip: setattr(item, "filepath", path),
                    "filepath", label=f"Sequencer: {scene.name} / {strip_name}",
                    name_hint=os.path.basename(direct_path),
                )

            directory = getattr(strip, "directory", "")
            elements = getattr(strip, "elements", None) or []
            for element_index, element in enumerate(elements):
                filename = getattr(element, "filename", "")
                if not filename:
                    continue
                raw = os.path.join(directory, filename) if directory else filename

                def _sequence_setter(path, item=strip, seq_element=element):
                    # Keep both strip and element bound to this iteration.
                    item.directory = os.path.dirname(path)
                    seq_element.filename = os.path.basename(path)

                yield from emit(
                    "SEQUENCE", strip, raw, _sequence_setter,
                    f"element:{element_index}",
                    label=f"Sequencer: {scene.name} / {strip_name}",
                    name_hint=filename,
                )


def _reference_is_missing(reference):
    raw = str(reference.get("raw_path", "") or "")
    # Empty references are exactly the class v0.5 hid. They cannot be proven
    # present, so expose them for manual mapping or filename-based recovery.
    if not raw:
        return True
    # UDIM/frame patterns require dedicated pattern handling. Listing them is
    # safer than pretending a single matched tile fully repairs the sequence.
    if "<UDIM>" in raw or "#" in raw:
        return True
    try:
        resolved = _safe_abspath(raw, reference.get("library"))
        return not os.path.exists(resolved)
    except Exception:
        return True


def _reference_match_name(reference):
    raw = str(reference.get("raw_path", "") or "")
    if raw:
        return _match_name(raw)
    hint = str(reference.get("name_hint", "") or "")
    return _match_name(hint)


def _pending_mapping_count(settings):
    return sum(1 for item in settings.missing_files if item.status == "PENDING")


def _visible_missing_count(settings):
    """Count rows currently displayed in the main missing-file list.

    Staged matches may be hidden for a cleaner review pass, but they remain
    available in Preview Changes and are never discarded by this toggle.
    """
    if settings.show_staged_matches:
        return len(settings.missing_files)
    return sum(1 for item in settings.missing_files if item.status != "PENDING")


def _stage_reference_path(scene, item, new_path, note):
    """Stage a path without touching the active Blender data-block.

    This is the important safety boundary in v0.18: matching and previewing can
    happen freely, but no filepath is written to Blender until the user presses
    Save New Mappings in the main window.
    """
    reference = _RUNTIME.get("reference_map", {}).get(item.ref_key)
    if reference is None:
        raise RuntimeError("This reference is no longer available. Run Scan Missing Files again.")
    new_path = _normalise_path(new_path)
    if not os.path.isfile(new_path):
        raise RuntimeError("The selected replacement file no longer exists.")

    if item.status != "PENDING":
        item.pre_pending_status = item.status or "MISSING"
        item.pre_pending_note = item.note

    _set_item_status(item, "PENDING", new_path, 1, note)
    scene.cfr_settings.mappings_changed = True


def _discard_pending_mappings(scene):
    settings = scene.cfr_settings
    discarded = 0
    for item in settings.missing_files:
        if item.status != "PENDING":
            continue
        restore_status = item.pre_pending_status or ("REVIEW" if item.candidates else "MISSING")
        restore_note = item.pre_pending_note or "Staged match discarded."
        _set_item_status(
            item,
            restore_status,
            "",
            len(item.candidates),
            restore_note,
        )
        item.pre_pending_status = ""
        item.pre_pending_note = ""
        discarded += 1
    settings.mappings_changed = False
    if discarded:
        settings.last_action = f"Discarded {discarded} staged match(es). No Blender file paths were changed."
    return discarded


def _discard_pending_mappings_for_item(scene, item):
    if item.status != "PENDING":
        return False
    restore_status = item.pre_pending_status or ("REVIEW" if item.candidates else "MISSING")
    restore_note = item.pre_pending_note or "Staged match removed."
    _set_item_status(item, restore_status, "", len(item.candidates), restore_note)
    item.pre_pending_status = ""
    item.pre_pending_note = ""
    scene.cfr_settings.mappings_changed = _pending_mapping_count(scene.cfr_settings) > 0
    scene.cfr_settings.last_action = f"Removed the staged match for {item.match_name}. No Blender filepath was changed."
    return True


def _commit_pending_mappings(scene):
    """Apply all staged mappings, then save the current blend as one transaction."""
    settings = scene.cfr_settings
    pending = [item for item in settings.missing_files if item.status == "PENDING"]
    if not pending:
        return False, "There are no staged matches to apply."
    if not bpy.data.filepath:
        return False, "This .blend has not been saved yet. Use File > Save As before applying mappings."

    applied = []
    try:
        for item in pending:
            reference = _RUNTIME.get("reference_map", {}).get(item.ref_key)
            if reference is None:
                raise RuntimeError(f"{item.match_name}: reference is no longer available. Run Scan Missing Files again.")
            original_path = str(reference.get("raw_path", "") or "")
            replacement_path = item.resolved_path
            if not replacement_path or not os.path.isfile(replacement_path):
                raise RuntimeError(f"{item.match_name}: staged replacement file no longer exists.")
            reference["set_path"](replacement_path)
            reference["raw_path"] = replacement_path
            applied.append((item, reference, original_path))

        bpy.ops.wm.save_mainfile()
    except Exception as exc:
        # A failed commit must not leave the active Blender scene half-relinked.
        for item, reference, original_path in reversed(applied):
            try:
                reference["set_path"](original_path)
                reference["raw_path"] = original_path
            except Exception:
                pass
        return False, f"Could not apply and save the staged matches: {exc}"

    for item, _reference, _original_path in applied:
        _set_item_status(item, "FIXED", item.resolved_path, 1, "Applied and saved to this .blend file.")
        item.pre_pending_status = ""
        item.pre_pending_note = ""
    settings.mappings_changed = False
    return True, f"Applied and saved {len(applied)} mapping(s) to {os.path.basename(bpy.data.filepath)}."


def scan_missing_references(scene):
    settings = scene.cfr_settings
    settings.missing_files.clear()
    settings.preview_image = None
    settings.preview_status = "Select a possible match, then use Preview / Stage Match."
    _RUNTIME["reference_map"] = {}

    if _selected_filter_count(settings) == 0:
        settings.active_missing_index = -1
        settings.last_action = "No file types are selected. Open File Types and choose at least one."
        return

    all_count = 0
    blank_count = 0
    for reference in _iter_external_references():
        kind = reference["kind"]
        if not _kind_enabled(settings, kind):
            continue
        if not _reference_is_missing(reference):
            continue
        all_count += 1
        raw = reference["raw_path"]
        if not raw:
            blank_count += 1

        item = settings.missing_files.add()
        item.kind = kind
        item.datablock_name = reference["label"]
        item.original_path = raw or "(Blank file path — using the data-block name for matching.)"
        item.match_name = _reference_match_name(reference)
        item.ref_key = reference["key"]
        item.status = "MISSING"
        if not raw:
            item.note = "Blank stored path. CINAEDVS will search using this data-block's filename/name where possible."
        elif "<UDIM>" in raw or "#" in raw:
            item.note = "Pattern path detected. Review manually; do not accept a single-tile automatic mapping."
        else:
            item.note = "Choose a source folder, then scan it for matches."
        _RUNTIME["reference_map"][item.ref_key] = reference

    settings.active_missing_index = 0 if settings.missing_files else -1
    suffix = f" ({blank_count} blank-path record{'s' if blank_count != 1 else ''})" if blank_count else ""
    settings.last_action = f"Found {all_count} missing external reference(s) in the selected file types.{suffix}"


# -----------------------------------------------------------------------------
# Folder browser helpers
# -----------------------------------------------------------------------------

def _refresh_browser_folder_list(settings):
    settings.browser_folders.clear()
    settings.active_browser_index = -1
    root = settings.scan_root.strip()
    if not root or not os.path.isdir(root):
        return

    try:
        folders = sorted(
            (entry.path for entry in os.scandir(root) if entry.is_dir(follow_symlinks=False)),
            key=lambda path: os.path.basename(path).lower(),
        )
        for path in folders:
            row = settings.browser_folders.add()
            row.name = os.path.basename(path)
            row.path = path
        if settings.browser_folders:
            settings.active_browser_index = 0
    except OSError:
        pass


# -----------------------------------------------------------------------------
# Controlled scanner process
# -----------------------------------------------------------------------------

def _write_json_file(path, payload):
    """Write a small JSON control file atomically for the scanner process."""
    temporary_path = f"{path}.tmp"
    with open(temporary_path, "w", encoding="utf-8") as handle:
        json.dump(payload, handle, ensure_ascii=False)
    os.replace(temporary_path, path)


def _read_json_file(path):
    if not path or not os.path.isfile(path):
        return None
    try:
        with open(path, "r", encoding="utf-8") as handle:
            return json.load(handle)
    except (OSError, ValueError, TypeError):
        # The worker replaces files atomically, but antivirus/indexing software
        # can still briefly hold a file. The next timer pass will try again.
        return None


def _find_bundled_python():
    """Locate Blender's bundled Windows Python executable when available."""
    candidates = []
    for prefix in {getattr(sys, "prefix", ""), getattr(sys, "exec_prefix", "")}:
        if prefix:
            candidates.extend([
                os.path.join(prefix, "bin", "python.exe"),
                os.path.join(prefix, "python.exe"),
            ])

    executable = getattr(sys, "executable", "")
    if executable and os.path.basename(executable).lower().startswith("python"):
        candidates.append(executable)

    blender_binary = getattr(bpy.app, "binary_path", "")
    if blender_binary:
        blender_root = os.path.dirname(blender_binary)
        version_folder = f"{bpy.app.version[0]}.{bpy.app.version[1]}"
        candidates.extend([
            os.path.join(blender_root, version_folder, "python", "bin", "python.exe"),
            os.path.join(blender_root, "python", "bin", "python.exe"),
        ])

    for candidate in candidates:
        if candidate and os.path.isfile(candidate):
            return candidate
    return ""


def _worker_command(request_file, status_file, result_file, cancel_file):
    worker_path = os.path.join(os.path.dirname(__file__), "scan_worker.py")
    worker_args = [
        "--request", request_file,
        "--status", status_file,
        "--result", result_file,
        "--cancel", cancel_file,
    ]
    python_executable = _find_bundled_python()
    if python_executable:
        return [python_executable, worker_path, *worker_args]

    # Blender always knows where its own executable is. This fallback starts a
    # background Blender process only when the bundled python.exe could not be
    # resolved from the installation layout.
    blender_binary = getattr(bpy.app, "binary_path", "")
    if blender_binary and os.path.isfile(blender_binary):
        return [
            blender_binary,
            "--background",
            "--factory-startup",
            "--python", worker_path,
            "--",
            *worker_args,
        ]
    raise RuntimeError("Blender's bundled Python executable could not be located.")


def _reset_scan_runtime(remove_temp=True):
    temp_dir = _RUNTIME.get("temp_dir", "")
    _RUNTIME.update({
        "process": None,
        "cancel_requested": False,
        "cancel_requested_at": 0.0,
        "request_file": "",
        "status_file": "",
        "result_file": "",
        "cancel_file": "",
        "temp_dir": "",
        "last_status_sequence": -1,
        "running": False,
        "timer_registered": False,
        "scene_name": "",
        "mode": "folder",
    })
    if remove_temp and temp_dir:
        try:
            shutil.rmtree(temp_dir)
        except OSError:
            pass


def _request_scan_cancel(force=False):
    """Ask the worker process to stop, optionally terminating it immediately."""
    if not _RUNTIME.get("running"):
        return False

    _RUNTIME["cancel_requested"] = True
    if not _RUNTIME.get("cancel_requested_at"):
        _RUNTIME["cancel_requested_at"] = time.monotonic()
    cancel_file = _RUNTIME.get("cancel_file", "")
    if cancel_file:
        try:
            with open(cancel_file, "w", encoding="utf-8") as handle:
                handle.write("cancel\n")
        except OSError:
            pass

    process = _RUNTIME.get("process")
    if force and process is not None and process.poll() is None:
        try:
            process.terminate()
        except OSError:
            pass
    return True


def _launch_scan_process(scene, request_payload, mode):
    settings = scene.cfr_settings
    temp_dir = tempfile.mkdtemp(prefix="cinaedvs_file_rescue_")
    request_file = os.path.join(temp_dir, "request.json")
    status_file = os.path.join(temp_dir, "status.json")
    result_file = os.path.join(temp_dir, "result.json")
    cancel_file = os.path.join(temp_dir, "cancel.requested")

    try:
        _write_json_file(request_file, request_payload)
        command = _worker_command(request_file, status_file, result_file, cancel_file)
        popen_options = {
            "stdin": subprocess.DEVNULL,
            "stdout": subprocess.DEVNULL,
            "stderr": subprocess.DEVNULL,
            "close_fds": True,
        }
        if os.name == "nt":
            popen_options["creationflags"] = getattr(subprocess, "CREATE_NO_WINDOW", 0)
        process = subprocess.Popen(command, **popen_options)
    except Exception:
        shutil.rmtree(temp_dir, ignore_errors=True)
        raise

    _RUNTIME.update({
        "process": process,
        "cancel_requested": False,
        "cancel_requested_at": 0.0,
        "request_file": request_file,
        "status_file": status_file,
        "result_file": result_file,
        "cancel_file": cancel_file,
        "temp_dir": temp_dir,
        "last_status_sequence": -1,
        "running": True,
        "scene_name": scene.name,
        "mode": mode,
    })

    if not _RUNTIME["timer_registered"]:
        _RUNTIME["timer_registered"] = True
        bpy.app.timers.register(_poll_scan_timer, first_interval=0.10)


def _apply_scan_results(scene, results):
    settings = scene.cfr_settings
    fixed = review = not_found = 0

    for item in settings.missing_files:
        result = results.get(item.ref_key)
        if result is None or item.status == "SKIPPED":
            continue

        candidates = result.get("candidates", [])
        match_type = result.get("match_type")

        if match_type == "EXACT" and len(candidates) == 1:
            # Do not auto-map a UDIM/frame pattern to one random individual tile.
            if "<UDIM>" in item.original_path or "#" in item.original_path:
                _add_candidates(item, candidates)
                _set_item_status(item, "REVIEW", candidates=len(candidates), note="Pattern path: review manually before mapping.")
                review += 1
                continue
            try:
                path = candidates[0]["path"]
                _stage_reference_path(
                    scene,
                    item,
                    path,
                    "Unique exact filename match staged. It will only be applied when you click Save New Mappings.",
                )
                fixed += 1
            except Exception as exc:
                _set_item_status(item, "MISSING", note=f"Could not stage this file mapping: {exc}")
                not_found += 1
        elif candidates:
            _add_candidates(item, candidates)
            reason = "Multiple exact filename matches." if match_type == "EXACT" else "Possible fuzzy filename matches."
            _set_item_status(item, "REVIEW", candidates=len(candidates), note=reason)
            review += 1
        else:
            _clear_candidates(item)
            _set_item_status(item, "NOT_FOUND", note="No exact or useful fuzzy filename match in this scan.")
            not_found += 1

    settings.last_action = (
        f"Folder scan complete: {fixed} exact match(es) staged, {review} need review, {not_found} still missing. "
        "Staged mappings are not applied until you click Save New Mappings."
    )



def _start_drive_search(scene, root, ref_key):
    if _RUNTIME["running"]:
        scene.cfr_settings.last_action = "A scan is already running. Cancel or wait for it to finish first."
        return
    settings = scene.cfr_settings
    item = next((row for row in settings.missing_files if row.ref_key == ref_key), None)
    if item is None or not item.match_name:
        settings.last_action = "Select a missing file with a usable filename first."
        return
    if not root or not os.path.isdir(root):
        settings.last_action = "Choose a valid drive first."
        return

    settings.drive_results.clear()
    settings.active_drive_result_index = -1
    settings.drive_search_ref_key = ref_key
    settings.drive_search_target = item.match_name
    settings.drive_search_root = _normalise_path(root)
    settings.drive_search_denied = 0
    settings.scanned_folders = 0
    settings.scanned_files = 0
    settings.scan_status = "Starting full-drive rescue search…"
    settings.last_action = f"Searching the full selected drive {settings.drive_search_root} for {item.match_name}."

    request_payload = {
        "mode": "drive",
        "root": settings.drive_search_root,
        "target_name": item.match_name,
        "fuzzy_min_score": FUZZY_MIN_SCORE,
    }
    try:
        _launch_scan_process(scene, request_payload, "drive")
    except Exception as exc:
        settings.scan_status = "Drive search failed to start"
        settings.last_action = f"Could not start the safe scanner process: {exc}"


def _apply_worker_progress(settings, message_kind, payload):
    if message_kind == "DRIVE_PROGRESS":
        settings.scanned_folders = payload.get("folders", 0)
        settings.scanned_files = payload.get("files", 0)
        settings.drive_search_denied = payload.get("denied", 0)
        settings.scan_status = (
            f"Searching drive · {settings.scanned_folders:,} folders · {settings.scanned_files:,} files"
        )
    elif message_kind == "PROGRESS":
        settings.scanned_folders = payload.get("folders", 0)
        settings.scanned_files = payload.get("files", 0)
        ignored = payload.get("ignored_deep", 0)
        suffix = f" · {ignored:,} deeper folder(s) ignored" if ignored else ""
        settings.scan_status = (
            f"Scanning folder · {settings.scanned_folders:,} folders · {settings.scanned_files:,} files{suffix}"
        )
    elif message_kind == "MATCHING":
        settings.scan_status = f"Checking possible matches for {payload.get('total', 0)} missing file(s)…"
    elif message_kind == "MATCH_PROGRESS":
        settings.scan_status = (
            f"Checking matches · {payload.get('current', 0)}/{payload.get('total', 0)}"
        )


def _finish_worker_result(scene, message_kind, payload):
    settings = scene.cfr_settings
    if message_kind == "DRIVE_CANCELLED":
        settings.scan_status = "Drive search cancelled"
        settings.last_action = "No file paths were changed by the cancelled drive search."
    elif message_kind == "DRIVE_ERROR":
        settings.scan_status = "Drive search failed"
        settings.last_action = f"Drive search error: {payload}"
    elif message_kind == "DRIVE_DONE":
        settings.scanned_folders = payload.get("folders", 0)
        settings.scanned_files = payload.get("files", 0)
        settings.drive_search_denied = payload.get("denied", 0)
        settings.drive_results.clear()
        for row_data in payload.get("results", []):
            row = settings.drive_results.add()
            row.path = row_data.get("path", "")
            row.name = row_data.get("name", "")
            row.score = row_data.get("score", 0)
            row.match_type = row_data.get("match_type", "")
        settings.active_drive_result_index = 0 if settings.drive_results else -1
        settings.scan_status = (
            f"Drive search complete · {settings.scanned_folders:,} folders · {settings.scanned_files:,} files"
        )
        if settings.drive_results:
            settings.last_action = (
                f"Found {len(settings.drive_results)} possible match(es) for {settings.drive_search_target}. "
                "Review them in the Drive Search Results card."
            )
        else:
            settings.last_action = (
                f"No usable filename match for {settings.drive_search_target} on {settings.drive_search_root}."
            )
    elif message_kind == "FILE_LIMIT":
        settings.scanned_folders = payload.get("folders", 0)
        settings.scanned_files = payload.get("files", 0)
        settings.scan_status = "File cap reached — scan stopped"
        settings.last_action = f"Stopped after {settings.scanned_files:,} files. Choose a narrower folder."
    elif message_kind == "CANCELLED":
        settings.scan_status = "Folder scan cancelled"
        settings.last_action = "No new file paths were changed by this cancelled scan."
    elif message_kind == "ERROR":
        settings.scan_status = "Folder scan failed"
        settings.last_action = f"Scanner error: {payload}"
    elif message_kind == "DONE":
        settings.scanned_folders = payload.get("folders", 0)
        settings.scanned_files = payload.get("files", 0)
        ignored = payload.get("ignored_deep", 0)
        _apply_scan_results(scene, payload.get("results", {}))
        if ignored:
            settings.scan_status = (
                f"Complete · {settings.scanned_folders:,} folders · {settings.scanned_files:,} files "
                f"· {ignored:,} deeper folder(s) ignored"
            )
            settings.last_action = (
                f"I have ONLY scanned {HARD_MAX_DEPTH} levels of child folders; "
                f"{ignored:,} deeper folder(s) were ignored. "
                f"{settings.last_action}"
            )
        else:
            settings.scan_status = (
                f"Complete · {settings.scanned_folders:,} folders · {settings.scanned_files:,} files"
            )
    else:
        settings.scan_status = "Scanner process failed"
        settings.last_action = f"Unexpected scanner result: {message_kind or 'no result'}"


def _poll_scan_timer():
    scene = bpy.data.scenes.get(_RUNTIME.get("scene_name", ""))
    process = _RUNTIME.get("process")
    if scene is None or not hasattr(scene, "cfr_settings") or process is None:
        _request_scan_cancel(force=True)
        _reset_scan_runtime()
        return None

    settings = scene.cfr_settings
    status = _read_json_file(_RUNTIME.get("status_file", ""))
    if isinstance(status, dict):
        sequence = int(status.get("sequence", -1))
        if sequence > _RUNTIME.get("last_status_sequence", -1):
            _RUNTIME["last_status_sequence"] = sequence
            _apply_worker_progress(settings, status.get("kind", ""), status.get("payload") or {})

    if _RUNTIME.get("cancel_requested") and process.poll() is None:
        requested_at = _RUNTIME.get("cancel_requested_at", 0.0)
        if requested_at and time.monotonic() - requested_at > 3.0:
            try:
                process.terminate()
            except OSError:
                pass

    return_code = process.poll()
    result = _read_json_file(_RUNTIME.get("result_file", ""))
    if return_code is None:
        _tag_all_redraws()
        return 0.10

    if isinstance(result, dict):
        message_kind = result.get("kind", "")
        payload = result.get("payload")
        _finish_worker_result(scene, message_kind, payload)
    elif _RUNTIME.get("cancel_requested"):
        cancelled_kind = "DRIVE_CANCELLED" if _RUNTIME.get("mode") == "drive" else "CANCELLED"
        _finish_worker_result(scene, cancelled_kind, None)
    else:
        error_kind = "DRIVE_ERROR" if _RUNTIME.get("mode") == "drive" else "ERROR"
        _finish_worker_result(
            scene,
            error_kind,
            f"The scanner process exited with code {return_code} without returning a result.",
        )

    _tag_all_redraws()
    _reset_scan_runtime()
    return None


def _start_folder_scan(scene):
    if _RUNTIME["running"]:
        scene.cfr_settings.last_action = "A folder scan is already running."
        return

    settings = scene.cfr_settings
    root = bpy.path.abspath(settings.scan_root.strip())
    if not root or not os.path.isdir(root):
        settings.last_action = "Choose a valid source folder first."
        return

    visible_items = [
        item for item in settings.missing_files
        if item.status not in {"FIXED", "PENDING", "SKIPPED"}
    ]
    if not visible_items:
        settings.last_action = "There are no unresolved files in the current list. Press Scan Missing Files after choosing File Types."
        return

    settings.scan_root = _normalise_path(root)
    settings.scanned_folders = 0
    settings.scanned_files = 0
    settings.scan_status = "Starting controlled folder scan…"
    settings.last_action = (
        f"Scanning {settings.scan_root} for {len(visible_items)} unresolved file(s). "
        f"I will scan only {HARD_MAX_DEPTH} child-folder levels and ignore anything deeper."
    )

    request_payload = {
        "mode": "folder",
        "root": settings.scan_root,
        "targets": [
            {"ref_key": item.ref_key, "filename": item.match_name}
            for item in visible_items
        ],
        "max_depth": HARD_MAX_DEPTH,
        "max_files": HARD_MAX_FILES,
        "max_fuzzy_candidates": MAX_FUZZY_CANDIDATES,
        "fuzzy_min_score": FUZZY_MIN_SCORE,
    }
    try:
        _launch_scan_process(scene, request_payload, "folder")
    except Exception as exc:
        settings.scan_status = "Folder scan failed to start"
        settings.last_action = f"Could not start the safe scanner process: {exc}"


# -----------------------------------------------------------------------------
# Linked-object inspection helpers
# -----------------------------------------------------------------------------

def _collection_label(obj):
    names = [collection.name for collection in getattr(obj, "users_collection", [])]
    return ", ".join(names) if names else "No collection"


def _append_linked_object(settings, seen, obj, usage, material_name="", node_name=""):
    """Add one object/use relationship to the linked-object result list."""
    if obj is None:
        return
    key = (obj.name_full, usage, material_name, node_name)
    if key in seen:
        return
    seen.add(key)
    row = settings.linked_objects.add()
    row.object_name = obj.name_full
    row.object_type = obj.type
    row.collection_name = _collection_label(obj)
    row.material_name = material_name
    row.node_name = node_name
    row.usage = usage


def _iter_material_image_uses(obj, image):
    """Yield material/node labels for image texture nodes used by an object."""
    for slot in getattr(obj, "material_slots", []):
        material = getattr(slot, "material", None)
        node_tree = getattr(material, "node_tree", None) if material else None
        if node_tree is None:
            continue
        for node in node_tree.nodes:
            if getattr(node, "type", "") == "TEX_IMAGE" and getattr(node, "image", None) == image:
                yield material.name, node.name

    # Geometry-node modifier groups can contain Image Texture nodes too.
    for modifier in getattr(obj, "modifiers", []):
        node_tree = getattr(modifier, "node_group", None)
        if node_tree is None:
            continue
        for node in node_tree.nodes:
            if getattr(node, "type", "") == "TEX_IMAGE" and getattr(node, "image", None) == image:
                yield f"Geometry Nodes: {modifier.name}", node.name


def _rebuild_linked_objects(scene):
    """Find scene objects using the currently selected missing reference.

    The central missing-file data model stores a direct session-only pointer to
    each external reference. This helper follows that pointer into Blender's
    objects/materials rather than guessing from filenames.
    """
    settings = scene.cfr_settings
    settings.linked_objects.clear()
    settings.active_linked_object_index = -1
    settings.linked_preview_object = None
    settings.linked_ref_key = ""
    settings.linked_file_label = ""

    item = _active_item(settings)
    if item is None:
        settings.last_action = "Select a missing file first."
        return 0

    reference = _RUNTIME.get("reference_map", {}).get(item.ref_key)
    if reference is None:
        settings.last_action = "Run Scan Missing Files again before inspecting linked objects."
        return 0

    owner = reference.get("owner")
    kind = reference.get("kind", "")
    seen = set()
    settings.linked_ref_key = item.ref_key
    settings.linked_file_label = item.match_name or item.datablock_name or "Selected missing file"

    # The current scene is deliberately used, because every row can then be
    # selected and framed in the active Blender viewport immediately.
    for obj in scene.objects:
        if kind == "IMAGE":
            for material_name, node_name in _iter_material_image_uses(obj, owner):
                _append_linked_object(
                    settings, seen, obj,
                    "Image Texture node",
                    material_name=material_name,
                    node_name=node_name,
                )
        elif kind == "SOUND":
            if obj.type == "SPEAKER" and getattr(getattr(obj, "data", None), "sound", None) == owner:
                _append_linked_object(settings, seen, obj, "Speaker sound")
        elif kind == "FONT":
            if obj.type == "FONT" and getattr(getattr(obj, "data", None), "font", None) == owner:
                _append_linked_object(settings, seen, obj, "Text object font")
        elif kind in {"VOLUME", "CACHEFILE"}:
            if getattr(obj, "data", None) == owner:
                _append_linked_object(settings, seen, obj, "Object data")
        elif kind == "LIBRARY":
            if getattr(obj, "library", None) == owner:
                _append_linked_object(settings, seen, obj, "Linked object")
            elif getattr(getattr(obj, "data", None), "library", None) == owner:
                _append_linked_object(settings, seen, obj, "Linked object data")

    if settings.linked_objects:
        settings.active_linked_object_index = 0
        settings.linked_preview_object = bpy.data.objects.get(settings.linked_objects[0].object_name)
        settings.last_action = (
            f"Found {len(settings.linked_objects)} linked object use(s) for {settings.linked_file_label}."
        )
    else:
        settings.last_action = f"No scene objects currently use {settings.linked_file_label}."
    return len(settings.linked_objects)



_PREVIEW_IMAGE_PREFIX = "__CFR_OBJECT_PREVIEW__"


def _clear_object_preview_image(settings):
    """Remove a previous CINAEDVS render without touching user images."""
    image = getattr(settings, "linked_preview_image", None)
    texture = getattr(settings, "linked_preview_texture", None)
    settings.linked_preview_image = None
    settings.linked_preview_texture = None
    try:
        if texture is not None and texture.name.startswith(_PREVIEW_IMAGE_PREFIX) and texture.users == 0:
            bpy.data.textures.remove(texture)
    except Exception:
        pass
    try:
        if image is not None and image.name.startswith(_PREVIEW_IMAGE_PREFIX) and image.users == 0:
            bpy.data.images.remove(image)
    except Exception:
        pass


def _preview_bounds(obj):
    """Return a conservative centre/radius for the object in local preview space."""
    try:
        points = [Vector(corner) for corner in obj.bound_box]
    except Exception:
        points = []
    if not points:
        return Vector((0.0, 0.0, 0.0)), 1.0
    min_v = Vector((min(p.x for p in points), min(p.y for p in points), min(p.z for p in points)))
    max_v = Vector((max(p.x for p in points), max(p.y for p in points), max(p.z for p in points)))
    centre = (min_v + max_v) * 0.5
    radius = max((p - centre).length for p in points)
    return centre, max(radius, 0.35)


def _aim_camera(camera, target, azimuth_degrees, elevation_degrees, distance):
    azimuth = math.radians(azimuth_degrees)
    elevation = math.radians(elevation_degrees)
    direction = Vector((
        math.cos(azimuth) * math.cos(elevation),
        math.sin(azimuth) * math.cos(elevation),
        math.sin(elevation),
    ))
    camera.location = target + direction * distance
    camera.rotation_euler = (target - camera.location).to_track_quat("-Z", "Y").to_euler()


def _add_preview_light(scene, collection, name, location, energy, size, target):
    data = bpy.data.lights.new(name, type="AREA")
    data.energy = energy
    data.shape = "DISK"
    data.size = size
    obj = bpy.data.objects.new(name, data)
    collection.objects.link(obj)
    obj.location = location
    obj.rotation_euler = (target - obj.location).to_track_quat("-Z", "Y").to_euler()
    return obj, data


def _copy_render_result_to_preview(settings, width, height):
    render_result = bpy.data.images.get("Render Result")
    if render_result is None:
        return None, "Blender did not return a render result."
    _clear_object_preview_image(settings)
    image = bpy.data.images.new(
        f"{_PREVIEW_IMAGE_PREFIX}{int(time.time() * 1000)}",
        width=width,
        height=height,
        alpha=False,
        float_buffer=False,
    )
    try:
        image.pixels.foreach_set(render_result.pixels[:])
        image.colorspace_settings.name = "sRGB"
        image.update()
        try:
            image.preview_ensure()
        except Exception:
            pass
        settings.linked_preview_image = image
        try:
            texture = bpy.data.textures.new(f"{_PREVIEW_IMAGE_PREFIX}TEXTURE_{int(time.time() * 1000)}", type="IMAGE")
            texture.image = image
            settings.linked_preview_texture = texture
        except Exception:
            settings.linked_preview_texture = None
        return image, ""
    except Exception as exc:
        try:
            bpy.data.images.remove(image)
        except Exception:
            pass
        return None, f"Could not prepare the preview image: {exc}"


def _render_isolated_object_preview(context, settings):
    """Render an isolated low-res object thumbnail in a temporary scene.

    The active Blender scene, current selection, camera, viewport shading and
    workspace are never touched. The temporary scene and all helper data are
    destroyed immediately after the image is copied into CINAEDVS.
    """
    obj = settings.linked_preview_object
    if obj is None:
        return False, "Select a linked object first."

    temporary_scene = None
    temporary_world = None
    created_objects = []
    created_data = []
    try:
        temporary_scene = bpy.data.scenes.new("__CFR_PREVIEW_SCENE__")
        temporary_scene.render.resolution_x = 440
        temporary_scene.render.resolution_y = 440
        temporary_scene.render.resolution_percentage = 100
        temporary_scene.render.image_settings.file_format = "PNG"
        temporary_scene.render.film_transparent = False

        temporary_world = bpy.data.worlds.new("__CFR_PREVIEW_WORLD__")
        temporary_world.use_nodes = True
        background = temporary_world.node_tree.nodes.get("Background")
        if background:
            background.inputs["Color"].default_value = (0.055, 0.055, 0.065, 1.0)
            background.inputs["Strength"].default_value = 0.22
        temporary_scene.world = temporary_world

        collection = temporary_scene.collection
        preview_object = obj.copy()
        created_objects.append(preview_object)
        if getattr(obj, "data", None) is not None and hasattr(obj.data, "copy"):
            try:
                preview_object.data = obj.data.copy()
                created_data.append(preview_object.data)
            except Exception:
                # Some Blender object data cannot be safely copied. Sharing the
                # read-only source data still makes a non-destructive preview.
                preview_object.data = obj.data
        preview_object.animation_data_clear()
        preview_object.matrix_world = Matrix.Identity(4)
        collection.objects.link(preview_object)

        centre, radius = _preview_bounds(preview_object)
        camera_data = bpy.data.cameras.new("__CFR_PREVIEW_CAMERA__")
        camera = bpy.data.objects.new("__CFR_PREVIEW_CAMERA__", camera_data)
        created_objects.append(camera)
        created_data.append(camera_data)
        collection.objects.link(camera)
        temporary_scene.camera = camera
        camera.data.lens = 52
        distance = radius * max(settings.linked_preview_zoom, 1.1) * 2.8
        _aim_camera(
            camera,
            centre,
            settings.linked_preview_azimuth,
            settings.linked_preview_elevation,
            distance,
        )

        if settings.linked_preview_mode == "MATERIAL":
            # EEVEE allows the preview to use actual nodes/textures when the
            # currently installed Blender build exposes EEVEE Next.
            try:
                temporary_scene.render.engine = "BLENDER_EEVEE_NEXT"
            except Exception:
                temporary_scene.render.engine = "BLENDER_WORKBENCH"
            light_specs = (
                (centre + Vector((radius * 3.4, -radius * 3.2, radius * 4.0)), 1100.0, radius * 3.0),
                (centre + Vector((-radius * 3.0, -radius * 1.8, radius * 1.6)), 700.0, radius * 2.4),
                (centre + Vector((radius * 0.6, radius * 3.3, radius * 2.4)), 850.0, radius * 2.1),
            )
            for index, (location, energy, size) in enumerate(light_specs, 1):
                light, light_data = _add_preview_light(
                    temporary_scene, collection, f"__CFR_PREVIEW_LIGHT_{index}__",
                    location, energy, size, centre,
                )
                created_objects.append(light)
                created_data.append(light_data)
        else:
            temporary_scene.render.engine = "BLENDER_WORKBENCH"
            shading = temporary_scene.display.shading
            shading.light = "STUDIO"
            shading.color_type = "MATERIAL"
            shading.show_shadows = True
            shading.show_cavity = True
            shading.cavity_type = "WORLD"
            shading.background_type = "WORLD"
            shading.background_color = (0.055, 0.055, 0.065)

        view_layer = temporary_scene.view_layers[0]
        # Context override keeps the user's active scene/workspace intact.
        with context.temp_override(scene=temporary_scene, view_layer=view_layer):
            bpy.ops.render.render(write_still=False)

        image, problem = _copy_render_result_to_preview(settings, 440, 440)
        if image is None:
            return False, problem
        mode_label = "Material Preview" if settings.linked_preview_mode == "MATERIAL" else "Solid"
        return True, f"{mode_label} preview ready. It is isolated from the main Blender window."

    except Exception as exc:
        return False, f"Could not render an isolated object preview: {exc}"
    finally:
        for temp_obj in reversed(created_objects):
            try:
                bpy.data.objects.remove(temp_obj, do_unlink=True)
            except Exception:
                pass
        for data in reversed(created_data):
            try:
                if data.users == 0:
                    if isinstance(data, bpy.types.Mesh):
                        bpy.data.meshes.remove(data)
                    elif isinstance(data, bpy.types.Camera):
                        bpy.data.cameras.remove(data)
                    elif isinstance(data, bpy.types.Light):
                        bpy.data.lights.remove(data)
            except Exception:
                pass
        if temporary_scene is not None:
            try:
                bpy.data.scenes.remove(temporary_scene, do_unlink=True)
            except Exception:
                pass
        if temporary_world is not None:
            try:
                if temporary_world.users == 0:
                    bpy.data.worlds.remove(temporary_world)
            except Exception:
                pass


def _update_linked_object_active(settings, context):
    index = settings.active_linked_object_index
    if 0 <= index < len(settings.linked_objects):
        settings.linked_preview_object = bpy.data.objects.get(settings.linked_objects[index].object_name)
    else:
        settings.linked_preview_object = None

# Export private helper names intentionally for the package modules.
__all__ = [name for name in globals() if not name.startswith("__")]
