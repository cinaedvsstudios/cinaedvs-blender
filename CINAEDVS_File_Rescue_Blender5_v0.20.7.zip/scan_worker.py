# SPDX-FileCopyrightText: 2026 Chris
# SPDX-License-Identifier: GPL-3.0-or-later

"""Pure-Python filesystem scanner launched as a separate process.

This module intentionally does not import Blender. It receives a JSON request,
scans filenames, reports progress through small atomic JSON files, and returns a
final JSON result for the Blender process to apply safely on its main thread.
"""

from __future__ import annotations

import argparse
import difflib
import json
import os
import re
import sys
from collections import defaultdict
from typing import Any


def _write_json(path: str, payload: dict[str, Any]) -> None:
    temporary_path = f"{path}.tmp"
    with open(temporary_path, "w", encoding="utf-8") as handle:
        json.dump(payload, handle, ensure_ascii=False)
    os.replace(temporary_path, path)


class Reporter:
    def __init__(self, status_path: str, result_path: str) -> None:
        self.status_path = status_path
        self.result_path = result_path
        self.sequence = 0

    def status(self, kind: str, payload: Any = None) -> None:
        self.sequence += 1
        _write_json(
            self.status_path,
            {"sequence": self.sequence, "kind": kind, "payload": payload},
        )

    def result(self, kind: str, payload: Any = None) -> None:
        _write_json(self.result_path, {"kind": kind, "payload": payload})


def _cancelled(cancel_path: str) -> bool:
    return bool(cancel_path and os.path.exists(cancel_path))


def _base_stem(filename: str) -> str:
    stem = os.path.splitext(os.path.basename(filename or ""))[0].lower()
    return re.sub(r"[^a-z0-9]+", "", stem)


def _name_tokens(filename: str) -> set[str]:
    stem = os.path.splitext(os.path.basename(filename or ""))[0].lower()
    return {token for token in re.split(r"[^a-z0-9]+", stem) if len(token) >= 3}


def _score_candidate(target_name: str, candidate_name: str, fuzzy_min_score: float) -> int:
    target_stem = _base_stem(target_name)
    candidate_stem = _base_stem(candidate_name)
    if not target_stem or not candidate_stem:
        return 0

    target_tokens = _name_tokens(target_name)
    candidate_tokens = _name_tokens(candidate_name)
    if target_tokens and candidate_tokens and not (target_tokens & candidate_tokens):
        if target_stem[:3] != candidate_stem[:3]:
            return 0

    score = difflib.SequenceMatcher(None, target_stem, candidate_stem).ratio()
    if score < fuzzy_min_score:
        return 0
    return round(score * 100)


def _candidate_rows_for_target(
    filename: str,
    by_name: dict[str, list[str]],
    by_extension: dict[str, set[str]],
    token_index: dict[tuple[str, str], set[str]],
    fuzzy_min_score: float,
    max_fuzzy_candidates: int,
) -> tuple[str, list[dict[str, Any]]]:
    """Mirror the established folder-match behaviour from the Blender add-on."""
    target_lower = filename.lower()
    exact_paths = by_name.get(target_lower, [])
    if exact_paths:
        rows = [
            {
                "path": path,
                "score": 100,
                "match_type": "Exact filename",
            }
            for path in exact_paths[:max_fuzzy_candidates]
        ]
        return "EXACT", rows

    target_ext = os.path.splitext(target_lower)[1]
    target_tokens = _name_tokens(filename)
    pool: set[str] = set()
    for token in target_tokens:
        pool.update(token_index.get((target_ext, token), set()))

    if not pool:
        pool.update(by_extension.get(target_ext, set()))

    # Keep the fuzzy pass bounded even when a selected folder contains a very
    # large number of files with the same extension.
    if len(pool) > 15000:
        prefix = _base_stem(filename)[:2]
        narrowed = {
            name for name in pool
            if _base_stem(name).startswith(prefix)
        }
        if narrowed:
            pool = narrowed
        else:
            pool = set(sorted(pool)[:15000])

    target_stem = _base_stem(filename)
    candidates: list[tuple[float, str]] = []
    for candidate_name in pool:
        candidate_stem = _base_stem(candidate_name)
        if not candidate_stem:
            continue
        score = difflib.SequenceMatcher(None, target_stem, candidate_stem).ratio()
        if score >= fuzzy_min_score:
            candidates.append((score, candidate_name))

    candidates.sort(key=lambda entry: (-entry[0], entry[1].lower()))
    rows: list[dict[str, Any]] = []
    for score, candidate_name in candidates[:max_fuzzy_candidates]:
        for path in by_name[candidate_name.lower()]:
            rows.append({
                "path": path,
                "score": round(score * 100),
                "match_type": "Fuzzy filename",
            })
            if len(rows) >= max_fuzzy_candidates:
                break
        if len(rows) >= max_fuzzy_candidates:
            break
    return "FUZZY", rows


def _scan_folder(request: dict[str, Any], reporter: Reporter, cancel_path: str) -> None:
    root = str(request.get("root") or "")
    targets = request.get("targets") or []
    max_depth = int(request.get("max_depth", 6))
    max_files = int(request.get("max_files", 100000))
    max_fuzzy_candidates = int(request.get("max_fuzzy_candidates", 8))
    fuzzy_min_score = float(request.get("fuzzy_min_score", 0.56))

    by_name: dict[str, list[str]] = defaultdict(list)
    by_extension: dict[str, set[str]] = defaultdict(set)
    token_index: dict[tuple[str, str], set[str]] = defaultdict(set)
    stack: list[tuple[str, int]] = [(root, 0)]
    folder_count = 0
    file_count = 0
    ignored_deep_folders = 0
    last_report = 0

    while stack:
        if _cancelled(cancel_path):
            reporter.result("CANCELLED")
            return

        current_folder, depth = stack.pop()
        folder_count += 1
        try:
            entries = list(os.scandir(current_folder))
        except (PermissionError, FileNotFoundError, OSError):
            continue

        for entry in entries:
            if _cancelled(cancel_path):
                reporter.result("CANCELLED")
                return
            try:
                if entry.is_dir(follow_symlinks=False):
                    child_depth = depth + 1
                    if child_depth > max_depth:
                        ignored_deep_folders += 1
                        continue
                    stack.append((entry.path, child_depth))
                elif entry.is_file(follow_symlinks=False):
                    file_count += 1
                    if file_count > max_files:
                        reporter.result("FILE_LIMIT", {
                            "folders": folder_count,
                            "files": file_count,
                        })
                        return
                    lowered = entry.name.lower()
                    extension = os.path.splitext(lowered)[1]
                    by_name[lowered].append(entry.path)
                    by_extension[extension].add(entry.name)
                    for token in _name_tokens(entry.name):
                        token_index[(extension, token)].add(entry.name)
            except OSError:
                continue

            if file_count - last_report >= 250:
                last_report = file_count
                reporter.status("PROGRESS", {
                    "folders": folder_count,
                    "files": file_count,
                    "ignored_deep": ignored_deep_folders,
                    "current": current_folder,
                })

    reporter.status("MATCHING", {"total": len(targets)})
    results: dict[str, dict[str, Any]] = {}
    for index, target in enumerate(targets, start=1):
        if _cancelled(cancel_path):
            reporter.result("CANCELLED")
            return
        ref_key = str(target.get("ref_key") or "")
        filename = str(target.get("filename") or "")
        match_type, rows = _candidate_rows_for_target(
            filename,
            by_name,
            by_extension,
            token_index,
            fuzzy_min_score,
            max_fuzzy_candidates,
        )
        results[ref_key] = {"match_type": match_type, "candidates": rows}
        if index == len(targets) or index % 10 == 0:
            reporter.status("MATCH_PROGRESS", {
                "current": index,
                "total": len(targets),
            })

    reporter.result("DONE", {
        "folders": folder_count,
        "files": file_count,
        "ignored_deep": ignored_deep_folders,
        "results": results,
    })


def _drive_match_score(
    target_name: str,
    candidate_name: str,
    fuzzy_min_score: float,
) -> tuple[int, str]:
    target_lower = target_name.lower()
    candidate_lower = candidate_name.lower()
    if target_lower == candidate_lower:
        return 100, "Exact filename"

    target_ext = os.path.splitext(target_lower)[1]
    if target_ext and os.path.splitext(candidate_lower)[1] != target_ext:
        return 0, ""

    score = _score_candidate(target_name, candidate_name, fuzzy_min_score)
    if not score:
        return 0, ""
    return score, "Fuzzy filename"


def _scan_drive(request: dict[str, Any], reporter: Reporter, cancel_path: str) -> None:
    root = str(request.get("root") or "")
    target_name = str(request.get("target_name") or "")
    fuzzy_min_score = float(request.get("fuzzy_min_score", 0.56))

    stack = [root]
    folder_count = 0
    file_count = 0
    denied_count = 0
    last_report = 0
    candidates: list[dict[str, Any]] = []
    target_ext = os.path.splitext(target_name.lower())[1]

    while stack:
        if _cancelled(cancel_path):
            reporter.result("DRIVE_CANCELLED")
            return

        current = stack.pop()
        folder_count += 1
        try:
            entries = list(os.scandir(current))
        except (PermissionError, FileNotFoundError, OSError):
            denied_count += 1
            continue

        for entry in entries:
            if _cancelled(cancel_path):
                reporter.result("DRIVE_CANCELLED")
                return
            try:
                if entry.is_dir(follow_symlinks=False):
                    stack.append(entry.path)
                elif entry.is_file(follow_symlinks=False):
                    file_count += 1
                    if target_ext and os.path.splitext(entry.name.lower())[1] != target_ext:
                        continue
                    score, match_type = _drive_match_score(
                        target_name,
                        entry.name,
                        fuzzy_min_score,
                    )
                    if score:
                        candidates.append({
                            "path": entry.path,
                            "name": entry.name,
                            "score": score,
                            "match_type": match_type,
                        })
            except OSError:
                continue

            if file_count - last_report >= 1000:
                last_report = file_count
                reporter.status("DRIVE_PROGRESS", {
                    "folders": folder_count,
                    "files": file_count,
                    "denied": denied_count,
                    "current": current,
                })

    candidates.sort(key=lambda row: (-row["score"], row["path"].lower()))
    unique: list[dict[str, Any]] = []
    seen: set[str] = set()
    for row in candidates:
        key = row["path"].lower()
        if key not in seen:
            seen.add(key)
            unique.append(row)
        if len(unique) >= 32:
            break

    reporter.result("DRIVE_DONE", {
        "folders": folder_count,
        "files": file_count,
        "denied": denied_count,
        "results": unique,
    })


def _arguments() -> argparse.Namespace:
    argv = sys.argv[1:]
    if "--" in argv:
        argv = argv[argv.index("--") + 1:]

    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument("--request", required=True)
    parser.add_argument("--status", required=True)
    parser.add_argument("--result", required=True)
    parser.add_argument("--cancel", required=True)
    return parser.parse_args(argv)


def main() -> int:
    args = _arguments()
    reporter = Reporter(args.status, args.result)
    try:
        with open(args.request, "r", encoding="utf-8") as handle:
            request = json.load(handle)
        mode = request.get("mode")
        if mode == "folder":
            _scan_folder(request, reporter, args.cancel)
        elif mode == "drive":
            _scan_drive(request, reporter, args.cancel)
        else:
            reporter.result("ERROR", f"Unknown scanner mode: {mode}")
    except Exception as exc:
        kind = "DRIVE_ERROR" if 'request' in locals() and request.get("mode") == "drive" else "ERROR"
        reporter.result(kind, str(exc))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
