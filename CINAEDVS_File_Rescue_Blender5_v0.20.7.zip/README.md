# CINAEDVS File Rescue v0.20.7

Blender 5.0+ extension for finding, reviewing, staging, and safely applying replacements for missing external files.

## Safe scanner-process review build

- Uses a separate scanner process instead of prohibited in-process background-thread libraries.
- Keeps Blender data access and interface updates inside Blender's main process.
- Preserves cancellable source-folder and whole-drive searches with live progress updates.
- Preserves the existing matching, staging, preview, and save workflow.
- Retains the modular package structure introduced in v0.20.6 and the Windows-only manifest restriction.

## Existing v0.20 features

- Automatically scans the open Blender file for missing references when launched.
- Automatically scans a chosen source folder and up to six child-folder levels.
- Stages exact matches without changing Blender until Save New Mappings is confirmed.
- Supports possible-match review, previews, bulk staging, linked-object inspection, and whole-drive search.

See `CHANGELOG.md` for the cumulative build history included in this package.
