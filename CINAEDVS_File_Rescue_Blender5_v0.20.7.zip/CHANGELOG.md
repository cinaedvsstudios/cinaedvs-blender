# CINAEDVS File Rescue — Change Log

## v0.20.7

- Removed the prohibited in-process background-thread and message-queue implementation.
- Added a separate `scan_worker.py` process for controlled source-folder and whole-drive searches.
- Preserved progress updates, cancellation, the six-level source-folder limit, the 100,000-file cap, exact matching, fuzzy matching, staging, and drive-search results.
- Added a three-second cancellation fallback that terminates an unresponsive scanner process without changing any Blender file paths.
- Kept all Blender data access and UI updates in Blender's main process; the worker handles filesystem names only.
- Corrected the full-drive warning to refer to the source scan's six-level limit.

## v0.20.6

- Reorganized the add-on from one large Python file into focused package modules.
- Kept add-on registration and class ordering in `__init__.py`.
- Moved shared reference, scan, matching, staging, and preview logic to `core.py`.
- Moved Blender property groups to `properties.py`.
- Moved workflow operators to `operators.py`.
- Moved UI lists, menus, dialogs, and the launcher panel to `ui.py`.
- Preserved the existing user-facing behaviour; this version is an internal organization change for easier review and maintenance.

## v0.20.5

- Limited the extension manifest to the Windows x64 platform.
- Kept the existing Windows drive-letter scanning behaviour unchanged.

## v0.20.4

- Removed the CINAEDVS Studios website operator and all clickable promotional links from the Blender UI.
- Removed the promotional “Made by CINAEDVS Studios” line from the in-Blender Quick Guide.
- Kept the functional Info guide and all File Rescue controls unchanged.

## v0.20.3

- Removed the Import-Export tag from blender_manifest.toml.
- Removed the Pipeline tag from blender_manifest.toml.
- Kept the System tag as the accurate extension category.

## v0.20.2

- Replaced the extension support/report URL with the public CINAEDVS Blender bug-report form.
- Added a packaged CHANGELOG.md so the contents of this build are recorded inside the ZIP.

## v0.20.1

- Launch automatically scans the active Blender file for missing external references.
- Choosing a source folder automatically begins the controlled six-level source scan.
- Manual scan actions are labelled as rescans.

## v0.20.0

- Added consistent native Blender status and action icons.
