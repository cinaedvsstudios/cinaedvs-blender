# SPDX-FileCopyrightText: 2026 Chris
# SPDX-License-Identifier: GPL-3.0-or-later

bl_info = {
    "name": "CINAEDVS File Rescue",
    "author": "Chris",
    "version": (0, 20, 3),
    "blender": (5, 0, 0),
    "location": "3D Viewport > Sidebar > CINAEDVS > Launch",
    "description": "A controlled visual relinker for missing external Blender files",
    "category": "System",
}

"""
CINAEDVS File Rescue — v0.20.3

Native Blender-only interface. Blender supplies the widget colours and named native icons for native
panels, lists and popups; this extension deliberately does not change the
user's global Blender theme. The functional workflow is:

1. Launch automatically scans the active Blender file for missing references.
2. Choose a source folder on the right; it starts the controlled folder scan automatically.
3. The audit includes blank-path texture records and common external data
   sources, not just the small standard set of loaded file paths.
4. Unique exact filename matches are staged as Match Found entries; Blender is not changed yet.
5. Possible fuzzy matches become [!] Review rows.
6. Select a review row, inspect candidates in the details box, then use
   Preview / Stage Match.
7. Preview Changes lets you inspect staged matches before committing them.
8. Stage ≥ threshold can stage the top candidate for every review row at or above the chosen confidence.
9. Save New Mappings is the only action that updates the open blend and saves it.
"""

import difflib
import math
import os
import queue
import re
import threading
import time
from collections import defaultdict

import bpy
from mathutils import Matrix, Vector
from bpy.props import (
    BoolProperty,
    CollectionProperty,
    IntProperty,
    EnumProperty,
    FloatProperty,
    PointerProperty,
    StringProperty,
)
from bpy.types import Menu, Operator, Panel, PropertyGroup, UIList

APP_NAME = "CINAEDVS File Rescue"

# Native Blender icons used consistently throughout the extension. These are
# deliberately named icons, so they respect the user's Blender theme.
ICON_MATCH_FOUND = "LINKED"       # The linked-node mark Chris selected
ICON_POSSIBLE_MATCH = "NODETREE"  # The dotted node/candidate mark Chris selected
ICON_MISSING = "X"                # The bracketed X mark Chris selected
ICON_SAVED = "FILE_TICK"
ICON_IGNORED = "HIDE_ON"
HARD_MAX_DEPTH = 6
HARD_MAX_FILES = 100000
MAX_FUZZY_CANDIDATES = 8
FUZZY_MIN_SCORE = 0.56

KIND_LABELS = {
    "IMAGE": "Textures / Materials",
    "LIBRARY": "Models / Libraries",
    "MOVIECLIP": "Video",
    "SOUND": "Audio",
    "FONT": "Fonts",
    "VOLUME": "Volumes / Caches",
    "CACHEFILE": "Volumes / Caches",
    "TEXT": "Text Documents",
    "SEQUENCE": "Video Sequencer",
    "LIGHT": "IES Lighting",
}

IMAGE_EXTENSIONS = {
    ".bmp", ".dds", ".exr", ".gif", ".hdr", ".jpeg", ".jpg", ".png",
    ".psd", ".tga", ".tif", ".tiff", ".webp",
}

_RUNTIME = {
    "thread": None,
    "cancel": None,
    "queue": None,
    "running": False,
    "timer_registered": False,
    "scene_name": "",
    "mode": "folder",
    # Built fresh by every Scan Missing Files pass. It keeps the direct
    # setter for each reference so linked properties and non-image sources
    # can be repaired without relying on a small hard-coded data-block list.
    "reference_map": {},
}


# -----------------------------------------------------------------------------
# General helpers
# -----------------------------------------------------------------------------

def _normalise_path(path):
    return os.path.normcase(os.path.normpath(os.path.abspath(path)))


def _safe_abspath(filepath, library=None):
    try:
        return _normalise_path(bpy.path.abspath(filepath, library=library))
    except Exception:
        return _normalise_path(filepath)


def _display_path(path, max_len=96):
    path = str(path or "")
    if len(path) <= max_len:
        return path
    return "…" + path[-(max_len - 1):]


def _match_name(filepath):
    return os.path.basename((filepath or "").replace("\\", "/"))


def _base_stem(filename):
    stem = os.path.splitext(os.path.basename(filename or ""))[0].lower()
    return re.sub(r"[^a-z0-9]+", "", stem)


def _name_tokens(filename):
    stem = os.path.splitext(os.path.basename(filename or ""))[0].lower()
    return {token for token in re.split(r"[^a-z0-9]+", stem) if len(token) >= 3}


def _tag_all_redraws():
    try:
        for window in bpy.context.window_manager.windows:
            if window.screen is None:
                continue
            for area in window.screen.areas:
                area.tag_redraw()
    except Exception:
        pass


def _active_item(settings):
    index = settings.active_missing_index
    if 0 <= index < len(settings.missing_files):
        return settings.missing_files[index]
    return None


def _active_candidate(item):
    if item is None:
        return None
    index = item.active_candidate_index
    if 0 <= index < len(item.candidates):
        return item.candidates[index]
    return None


def _active_drive_result(settings):
    index = settings.active_drive_result_index
    if 0 <= index < len(settings.drive_results):
        return settings.drive_results[index]
    return None


def _find_item_by_ref_key(settings, ref_key):
    for item in settings.missing_files:
        if item.ref_key == ref_key:
            return item
    return None


def _clear_staged_preview_image(settings):
    """Remove only the temporary image datablock created for Preview Changes."""
    image = settings.staged_preview_image
    settings.staged_preview_image = None
    settings.staged_preview_status = "Select a staged match to preview it."
    if image is None:
        return
    try:
        if image.name.startswith("__CFR_STAGED_PREVIEW__") and image.users == 0:
            bpy.data.images.remove(image)
    except Exception:
        pass


def _load_staged_preview_image(settings):
    """Load a temporary thumbnail image for the active staged match, if visual."""
    _clear_staged_preview_image(settings)
    index = settings.active_staged_preview_index
    if not (0 <= index < len(settings.staged_preview_items)):
        settings.staged_preview_status = "There are no staged matches to preview."
        return

    row = settings.staged_preview_items[index]
    path = row.path
    if not path or not os.path.isfile(path):
        settings.staged_preview_status = "This staged file no longer exists at the stored path."
        return

    extension = os.path.splitext(path)[1].lower()
    if extension not in IMAGE_EXTENSIONS:
        settings.staged_preview_status = (
            f"No visual preview is available for {extension or 'this'} file type. "
            "You can still remove the staged mapping."
        )
        return

    try:
        image = bpy.data.images.load(path, check_existing=False)
        image.name = "__CFR_STAGED_PREVIEW__" + os.path.basename(path)
        settings.staged_preview_image = image
        settings.staged_preview_status = "Preview only. This mapping is not applied until Save New Mappings."
    except Exception as exc:
        settings.staged_preview_status = f"Blender could not load this preview: {exc}"


def _update_staged_preview_active(settings, _context):
    _load_staged_preview_image(settings)


def _populate_staged_preview_items(settings):
    _clear_staged_preview_image(settings)
    settings.staged_preview_items.clear()
    for item in settings.missing_files:
        if item.status != "PENDING":
            continue
        row = settings.staged_preview_items.add()
        row.ref_key = item.ref_key
        row.name = item.match_name or _match_name(item.resolved_path) or "Unnamed external file"
        row.kind = KIND_LABELS.get(item.kind, item.kind)
        row.path = item.resolved_path

    if settings.staged_preview_items:
        settings.active_staged_preview_index = 0
        _load_staged_preview_image(settings)
    else:
        settings.active_staged_preview_index = -1
        settings.staged_preview_status = "There are no staged matches to preview."


def _available_drive_items(_self=None, _context=None):
    """Return currently mounted roots for the selected-drive search dialog."""
    if os.name == "nt":
        rows = []
        for letter in "ABCDEFGHIJKLMNOPQRSTUVWXYZ":
            root = f"{letter}:\\"
            if os.path.isdir(root):
                rows.append((root, root, f"Search the full {root} drive"))
        return rows or [("C:\\", "C:\\", "Search the full C: drive")]
    return [(os.path.sep, os.path.sep, "Search the full mounted root")]


def _status_text(item):
    if item.status == "FIXED":
        return "[✓] Saved"
    if item.status == "PENDING":
        return "[~] Match Found"
    if item.status == "REVIEW":
        count = item.candidate_count or len(item.candidates)
        return f"[!] {count} possible match{'es' if count != 1 else ''}"
    if item.status == "SKIPPED":
        return "[-] Ignored"
    return "[X] Missing"


def _status_icon(item):
    """Return the compact, user-selected status icon for one file row."""
    if item.status == "FIXED":
        return ICON_SAVED
    if item.status == "PENDING":
        return ICON_MATCH_FOUND
    if item.status == "REVIEW":
        return ICON_POSSIBLE_MATCH
    if item.status == "SKIPPED":
        return ICON_IGNORED
    return ICON_MISSING


def _set_item_status(item, status, resolved_path="", candidates=0, note=""):
    item.status = status
    item.resolved_path = resolved_path
    item.candidate_count = candidates
    item.note = note


def _clear_candidates(item):
    item.candidates.clear()
    item.active_candidate_index = -1
    item.candidate_count = 0


def _add_candidates(item, candidate_rows):
    _clear_candidates(item)
    for candidate in candidate_rows:
        row = item.candidates.add()
        row.path = candidate["path"]
        row.name = os.path.basename(candidate["path"])
        row.score = int(candidate.get("score", 0))
        row.match_type = candidate.get("match_type", "Possible")
    item.candidate_count = len(item.candidates)
    item.active_candidate_index = 0 if item.candidates else -1


# -----------------------------------------------------------------------------
# Filters and missing reference discovery
# -----------------------------------------------------------------------------

def _kind_enabled(settings, kind):
    if kind == "IMAGE":
        return settings.filter_materials
    if kind == "LIBRARY":
        return settings.filter_models
    if kind == "MOVIECLIP":
        return settings.filter_video
    if kind == "SOUND":
        return settings.filter_audio
    if kind == "FONT":
        return settings.filter_fonts
    if kind in {"VOLUME", "CACHEFILE"}:
        return settings.filter_caches
    if kind in {"TEXT", "SEQUENCE", "LIGHT"}:
        return settings.filter_other
    return False


def _selected_filter_count(settings):
    return sum((
        settings.filter_materials,
        settings.filter_models,
        settings.filter_video,
        settings.filter_audio,
        settings.filter_fonts,
        settings.filter_caches,
        settings.filter_other,
    ))


def _set_all_filters(settings, value):
    settings.filter_materials = value
    settings.filter_models = value
    settings.filter_video = value
    settings.filter_audio = value
    settings.filter_fonts = value
    settings.filter_caches = value
    settings.filter_other = value


def _looks_like_filename(value):
    value = str(value or "").strip()
    return bool(os.path.splitext(os.path.basename(value))[1])


def _reference_key(kind, owner, slot, ordinal):
    try:
        owner_pointer = owner.as_pointer()
    except Exception:
        owner_pointer = id(owner)
    return f"{kind}|{owner_pointer}|{slot}|{ordinal}"


def _make_reference(kind, owner, raw_path, set_path, slot, ordinal, label=None, name_hint=""):
    """Create a session-only external-reference descriptor.

    `set_path` is intentionally kept outside Blender properties: v0.5 tried to
    recover every item via a named data-block lookup, which misses blank path
    records and can only repair the few hard-coded data types. The runtime map
    lets the UI repair the exact property it discovered.
    """
    raw_path = str(raw_path or "")
    label = label or getattr(owner, "name", kind)
    name_hint = str(name_hint or getattr(owner, "name", "") or "")
    library = getattr(owner, "library", None)
    return {
        "key": _reference_key(kind, owner, slot, ordinal),
        "kind": kind,
        "owner": owner,
        "raw_path": raw_path,
        "set_path": set_path,
        "label": label,
        "name_hint": name_hint,
        "library": library,
    }


def _set_direct_filepath(owner, path):
    owner.filepath = path
    try:
        if hasattr(owner, "reload"):
            owner.reload()
    except Exception:
        # Updating the stored path is still useful; Blender may reload it when
        # the dependency graph next evaluates.
        pass


def _iter_external_references():
    """Yield the common external resources Blender tracks in an open file.

    The previous build skipped every empty filepath. Blender's own report can
    still flag those records, particularly imported image datablocks whose
    display name retains the original texture filename. They are now included
    and use that name for exact/fuzzy matching whenever possible.
    """
    ordinal = 0

    def emit(kind, owner, raw_path, setter, slot, label=None, name_hint="", include_blank=False):
        nonlocal ordinal
        raw_path = str(raw_path or "")
        if not raw_path and not include_blank:
            return
        ordinal += 1
        yield _make_reference(
            kind, owner, raw_path, setter, slot, ordinal,
            label=label, name_hint=name_hint,
        )

    # Images: this deliberately includes imported/generated image data blocks
    # whose names are still texture filenames. Blender's own relinker can emit
    # missing-file warnings for those even when their stored filepath is blank.
    # Pure viewer/render-result placeholders still have neither a path nor a
    # file-looking name, so they remain excluded.
    for image in bpy.data.images:
        if getattr(image, "packed_file", None):
            continue
        source = getattr(image, "source", "FILE")
        raw = getattr(image, "filepath", "")
        include_blank = (
            source in {"FILE", "MOVIE", "SEQUENCE", "TILED"}
            or _looks_like_filename(image.name)
        )
        if not raw and not include_blank:
            continue
        yield from emit(
            "IMAGE", image, raw,
            lambda path, item=image: _set_direct_filepath(item, path),
            "filepath", label=f"Image: {image.name}", name_hint=image.name,
            include_blank=include_blank,
        )

    for sound in bpy.data.sounds:
        if getattr(sound, "packed_file", None):
            continue
        raw = getattr(sound, "filepath", "")
        yield from emit(
            "SOUND", sound, raw,
            lambda path, item=sound: _set_direct_filepath(item, path),
            "filepath", label=f"Sound: {sound.name}", name_hint=sound.name,
        )

    for clip in bpy.data.movieclips:
        raw = getattr(clip, "filepath", "")
        yield from emit(
            "MOVIECLIP", clip, raw,
            lambda path, item=clip: _set_direct_filepath(item, path),
            "filepath", label=f"Movie Clip: {clip.name}", name_hint=clip.name,
        )

    for font in bpy.data.fonts:
        if getattr(font, "packed_file", None):
            continue
        raw = getattr(font, "filepath", "")
        if raw == "<builtin>":
            continue
        yield from emit(
            "FONT", font, raw,
            lambda path, item=font: _set_direct_filepath(item, path),
            "filepath", label=f"Font: {font.name}", name_hint=font.name,
        )

    for volume in bpy.data.volumes:
        raw = getattr(volume, "filepath", "")
        yield from emit(
            "VOLUME", volume, raw,
            lambda path, item=volume: _set_direct_filepath(item, path),
            "filepath", label=f"Volume: {volume.name}", name_hint=volume.name,
        )

    for cache_file in getattr(bpy.data, "cache_files", []):
        raw = getattr(cache_file, "filepath", "")
        yield from emit(
            "CACHEFILE", cache_file, raw,
            lambda path, item=cache_file: _set_direct_filepath(item, path),
            "filepath", label=f"Cache: {cache_file.name}", name_hint=cache_file.name,
        )

    for library in bpy.data.libraries:
        raw = getattr(library, "filepath", "")
        yield from emit(
            "LIBRARY", library, raw,
            lambda path, item=library: _set_direct_filepath(item, path),
            "filepath", label=f"Linked Library: {library.name}", name_hint=library.name,
        )

    # Text blocks can be linked to a file independently of fonts and images.
    for text in bpy.data.texts:
        raw = getattr(text, "filepath", "")
        yield from emit(
            "TEXT", text, raw,
            lambda path, item=text: _set_direct_filepath(item, path),
            "filepath", label=f"Text: {text.name}", name_hint=text.name,
        )

    # IES profiles are an external dependency of lights in Blender versions
    # that expose a file-path property. Guard every access for API changes.
    for light in bpy.data.lights:
        for attr in ("ies_file", "ies_filepath"):
            raw = getattr(light, attr, None)
            if not isinstance(raw, str) or not raw:
                continue
            yield from emit(
                "LIGHT", light, raw,
                lambda path, item=light, prop=attr: setattr(item, prop, path),
                attr, label=f"IES Light: {light.name}", name_hint=os.path.basename(raw),
            )
            break

    # VSE images and movies are sometimes only owned by strips rather than an
    # image/movie datablock. The code is deliberately defensive because the
    # Sequencer RNA changed around Blender 5.
    for scene in bpy.data.scenes:
        editor = getattr(scene, "sequence_editor", None)
        if editor is None:
            continue
        strips = (
            getattr(editor, "sequences_all", None)
            or getattr(editor, "strips_all", None)
            or getattr(editor, "sequences", None)
            or getattr(editor, "strips", None)
            or []
        )
        seen = set()
        for strip in strips:
            try:
                ptr = strip.as_pointer()
            except Exception:
                ptr = id(strip)
            if ptr in seen:
                continue
            seen.add(ptr)

            strip_name = getattr(strip, "name", "Sequencer Strip")
            direct_path = getattr(strip, "filepath", "")
            if isinstance(direct_path, str) and direct_path:
                yield from emit(
                    "SEQUENCE", strip, direct_path,
                    lambda path, item=strip: setattr(item, "filepath", path),
                    "filepath", label=f"Sequencer: {scene.name} / {strip_name}",
                    name_hint=os.path.basename(direct_path),
                )

            directory = getattr(strip, "directory", "")
            elements = getattr(strip, "elements", None) or []
            for element_index, element in enumerate(elements):
                filename = getattr(element, "filename", "")
                if not filename:
                    continue
                raw = os.path.join(directory, filename) if directory else filename

                def _sequence_setter(path, item=strip, seq_element=element):
                    # Keep both strip and element bound to this iteration.
                    item.directory = os.path.dirname(path)
                    seq_element.filename = os.path.basename(path)

                yield from emit(
                    "SEQUENCE", strip, raw, _sequence_setter,
                    f"element:{element_index}",
                    label=f"Sequencer: {scene.name} / {strip_name}",
                    name_hint=filename,
                )


def _reference_is_missing(reference):
    raw = str(reference.get("raw_path", "") or "")
    # Empty references are exactly the class v0.5 hid. They cannot be proven
    # present, so expose them for manual mapping or filename-based recovery.
    if not raw:
        return True
    # UDIM/frame patterns require dedicated pattern handling. Listing them is
    # safer than pretending a single matched tile fully repairs the sequence.
    if "<UDIM>" in raw or "#" in raw:
        return True
    try:
        resolved = _safe_abspath(raw, reference.get("library"))
        return not os.path.exists(resolved)
    except Exception:
        return True


def _reference_match_name(reference):
    raw = str(reference.get("raw_path", "") or "")
    if raw:
        return _match_name(raw)
    hint = str(reference.get("name_hint", "") or "")
    return _match_name(hint)


def _pending_mapping_count(settings):
    return sum(1 for item in settings.missing_files if item.status == "PENDING")


def _visible_missing_count(settings):
    """Count rows currently displayed in the main missing-file list.

    Staged matches may be hidden for a cleaner review pass, but they remain
    available in Preview Changes and are never discarded by this toggle.
    """
    if settings.show_staged_matches:
        return len(settings.missing_files)
    return sum(1 for item in settings.missing_files if item.status != "PENDING")


def _stage_reference_path(scene, item, new_path, note):
    """Stage a path without touching the active Blender data-block.

    This is the important safety boundary in v0.18: matching and previewing can
    happen freely, but no filepath is written to Blender until the user presses
    Save New Mappings in the main window.
    """
    reference = _RUNTIME.get("reference_map", {}).get(item.ref_key)
    if reference is None:
        raise RuntimeError("This reference is no longer available. Run Scan Missing Files again.")
    new_path = _normalise_path(new_path)
    if not os.path.isfile(new_path):
        raise RuntimeError("The selected replacement file no longer exists.")

    if item.status != "PENDING":
        item.pre_pending_status = item.status or "MISSING"
        item.pre_pending_note = item.note

    _set_item_status(item, "PENDING", new_path, 1, note)
    scene.cfr_settings.mappings_changed = True


def _discard_pending_mappings(scene):
    settings = scene.cfr_settings
    discarded = 0
    for item in settings.missing_files:
        if item.status != "PENDING":
            continue
        restore_status = item.pre_pending_status or ("REVIEW" if item.candidates else "MISSING")
        restore_note = item.pre_pending_note or "Staged match discarded."
        _set_item_status(
            item,
            restore_status,
            "",
            len(item.candidates),
            restore_note,
        )
        item.pre_pending_status = ""
        item.pre_pending_note = ""
        discarded += 1
    settings.mappings_changed = False
    if discarded:
        settings.last_action = f"Discarded {discarded} staged match(es). No Blender file paths were changed."
    return discarded


def _discard_pending_mappings_for_item(scene, item):
    if item.status != "PENDING":
        return False
    restore_status = item.pre_pending_status or ("REVIEW" if item.candidates else "MISSING")
    restore_note = item.pre_pending_note or "Staged match removed."
    _set_item_status(item, restore_status, "", len(item.candidates), restore_note)
    item.pre_pending_status = ""
    item.pre_pending_note = ""
    scene.cfr_settings.mappings_changed = _pending_mapping_count(scene.cfr_settings) > 0
    scene.cfr_settings.last_action = f"Removed the staged match for {item.match_name}. No Blender filepath was changed."
    return True


def _commit_pending_mappings(scene):
    """Apply all staged mappings, then save the current blend as one transaction."""
    settings = scene.cfr_settings
    pending = [item for item in settings.missing_files if item.status == "PENDING"]
    if not pending:
        return False, "There are no staged matches to apply."
    if not bpy.data.filepath:
        return False, "This .blend has not been saved yet. Use File > Save As before applying mappings."

    applied = []
    try:
        for item in pending:
            reference = _RUNTIME.get("reference_map", {}).get(item.ref_key)
            if reference is None:
                raise RuntimeError(f"{item.match_name}: reference is no longer available. Run Scan Missing Files again.")
            original_path = str(reference.get("raw_path", "") or "")
            replacement_path = item.resolved_path
            if not replacement_path or not os.path.isfile(replacement_path):
                raise RuntimeError(f"{item.match_name}: staged replacement file no longer exists.")
            reference["set_path"](replacement_path)
            reference["raw_path"] = replacement_path
            applied.append((item, reference, original_path))

        bpy.ops.wm.save_mainfile()
    except Exception as exc:
        # A failed commit must not leave the active Blender scene half-relinked.
        for item, reference, original_path in reversed(applied):
            try:
                reference["set_path"](original_path)
                reference["raw_path"] = original_path
            except Exception:
                pass
        return False, f"Could not apply and save the staged matches: {exc}"

    for item, _reference, _original_path in applied:
        _set_item_status(item, "FIXED", item.resolved_path, 1, "Applied and saved to this .blend file.")
        item.pre_pending_status = ""
        item.pre_pending_note = ""
    settings.mappings_changed = False
    return True, f"Applied and saved {len(applied)} mapping(s) to {os.path.basename(bpy.data.filepath)}."


def scan_missing_references(scene):
    settings = scene.cfr_settings
    settings.missing_files.clear()
    settings.preview_image = None
    settings.preview_status = "Select a possible match, then use Preview / Stage Match."
    _RUNTIME["reference_map"] = {}

    if _selected_filter_count(settings) == 0:
        settings.active_missing_index = -1
        settings.last_action = "No file types are selected. Open File Types and choose at least one."
        return

    all_count = 0
    blank_count = 0
    for reference in _iter_external_references():
        kind = reference["kind"]
        if not _kind_enabled(settings, kind):
            continue
        if not _reference_is_missing(reference):
            continue
        all_count += 1
        raw = reference["raw_path"]
        if not raw:
            blank_count += 1

        item = settings.missing_files.add()
        item.kind = kind
        item.datablock_name = reference["label"]
        item.original_path = raw or "(Blank file path — using the data-block name for matching.)"
        item.match_name = _reference_match_name(reference)
        item.ref_key = reference["key"]
        item.status = "MISSING"
        if not raw:
            item.note = "Blank stored path. CINAEDVS will search using this data-block's filename/name where possible."
        elif "<UDIM>" in raw or "#" in raw:
            item.note = "Pattern path detected. Review manually; do not accept a single-tile automatic mapping."
        else:
            item.note = "Choose a source folder, then scan it for matches."
        _RUNTIME["reference_map"][item.ref_key] = reference

    settings.active_missing_index = 0 if settings.missing_files else -1
    suffix = f" ({blank_count} blank-path record{'s' if blank_count != 1 else ''})" if blank_count else ""
    settings.last_action = f"Found {all_count} missing external reference(s) in the selected file types.{suffix}"


# -----------------------------------------------------------------------------
# Folder browser helpers
# -----------------------------------------------------------------------------

def _refresh_browser_folder_list(settings):
    settings.browser_folders.clear()
    settings.active_browser_index = -1
    root = settings.scan_root.strip()
    if not root or not os.path.isdir(root):
        return

    try:
        folders = sorted(
            (entry.path for entry in os.scandir(root) if entry.is_dir(follow_symlinks=False)),
            key=lambda path: os.path.basename(path).lower(),
        )
        for path in folders:
            row = settings.browser_folders.add()
            row.name = os.path.basename(path)
            row.path = path
        if settings.browser_folders:
            settings.active_browser_index = 0
    except OSError:
        pass


# -----------------------------------------------------------------------------
# Candidate matching and controlled scan worker
# -----------------------------------------------------------------------------

def _candidate_rows_for_target(target_name, by_name, by_extension, token_index):
    target_lower = target_name.lower()
    exact_paths = by_name.get(target_lower, [])
    if exact_paths:
        rows = [
            {"path": path, "score": 100, "match_type": "Exact filename"}
            for path in exact_paths[:MAX_FUZZY_CANDIDATES]
        ]
        return "EXACT", rows

    target_ext = os.path.splitext(target_lower)[1]
    target_tokens = _name_tokens(target_name)
    pool = set()
    for token in target_tokens:
        pool.update(token_index.get((target_ext, token), set()))

    # If the name has no meaningful shared tokens, still allow a bounded fuzzy
    # pass over matching extensions. It stays in the worker thread.
    if not pool:
        pool.update(by_extension.get(target_ext, []))

    # Do not compare an unbounded entire disk for one missing name.
    if len(pool) > 15000:
        prefix = _base_stem(target_name)[:2]
        narrowed = {
            name for name in pool
            if _base_stem(name).startswith(prefix)
        }
        if narrowed:
            pool = narrowed
        else:
            pool = set(sorted(pool)[:15000])

    target_stem = _base_stem(target_name)
    candidates = []
    for candidate_name in pool:
        candidate_stem = _base_stem(candidate_name)
        if not candidate_stem:
            continue
        score = difflib.SequenceMatcher(None, target_stem, candidate_stem).ratio()
        if score >= FUZZY_MIN_SCORE:
            candidates.append((score, candidate_name))

    candidates.sort(key=lambda entry: (-entry[0], entry[1].lower()))
    rows = []
    for score, candidate_name in candidates[:MAX_FUZZY_CANDIDATES]:
        for path in by_name[candidate_name.lower()]:
            rows.append({
                "path": path,
                "score": round(score * 100),
                "match_type": "Fuzzy filename",
            })
            if len(rows) >= MAX_FUZZY_CANDIDATES:
                break
        if len(rows) >= MAX_FUZZY_CANDIDATES:
            break
    return "FUZZY", rows


def _scan_worker(root, targets, cancel_event, message_queue):
    by_name = defaultdict(list)
    by_extension = defaultdict(set)
    token_index = defaultdict(set)
    stack = [(root, 0)]
    folder_count = 0
    file_count = 0
    ignored_deep_folders = 0
    last_report = 0

    try:
        while stack:
            if cancel_event.is_set():
                message_queue.put(("CANCELLED", None))
                return

            current_folder, depth = stack.pop()
            folder_count += 1
            try:
                entries = list(os.scandir(current_folder))
            except (PermissionError, FileNotFoundError, OSError):
                continue

            for entry in entries:
                if cancel_event.is_set():
                    message_queue.put(("CANCELLED", None))
                    return
                try:
                    if entry.is_dir(follow_symlinks=False):
                        child_depth = depth + 1
                        # Scan the selected folder and children through the configured
                        # limit, then deliberately ignore anything deeper.  A deep
                        # library must not discard useful matches already indexed above
                        # the limit.
                        if child_depth > HARD_MAX_DEPTH:
                            ignored_deep_folders += 1
                            continue
                        stack.append((entry.path, child_depth))
                    elif entry.is_file(follow_symlinks=False):
                        file_count += 1
                        if file_count > HARD_MAX_FILES:
                            message_queue.put(("FILE_LIMIT", {
                                "folders": folder_count,
                                "files": file_count,
                            }))
                            return
                        lowered = entry.name.lower()
                        ext = os.path.splitext(lowered)[1]
                        by_name[lowered].append(entry.path)
                        by_extension[ext].add(entry.name)
                        for token in _name_tokens(entry.name):
                            token_index[(ext, token)].add(entry.name)
                except OSError:
                    continue

                if file_count - last_report >= 250:
                    last_report = file_count
                    message_queue.put(("PROGRESS", {
                        "folders": folder_count,
                        "files": file_count,
                        "ignored_deep": ignored_deep_folders,
                        "current": current_folder,
                    }))

        message_queue.put(("MATCHING", {"total": len(targets)}))
        results = {}
        for index, (ref_key, filename) in enumerate(targets, start=1):
            if cancel_event.is_set():
                message_queue.put(("CANCELLED", None))
                return
            match_type, rows = _candidate_rows_for_target(
                filename, by_name, by_extension, token_index,
            )
            results[ref_key] = {"match_type": match_type, "candidates": rows}
            if index == len(targets) or index % 10 == 0:
                message_queue.put(("MATCH_PROGRESS", {"current": index, "total": len(targets)}))

        message_queue.put(("DONE", {
            "folders": folder_count,
            "files": file_count,
            "ignored_deep": ignored_deep_folders,
            "results": results,
        }))
    except Exception as exc:
        message_queue.put(("ERROR", str(exc)))


def _apply_scan_results(scene, results):
    settings = scene.cfr_settings
    fixed = review = not_found = 0

    for item in settings.missing_files:
        result = results.get(item.ref_key)
        if result is None or item.status == "SKIPPED":
            continue

        candidates = result.get("candidates", [])
        match_type = result.get("match_type")

        if match_type == "EXACT" and len(candidates) == 1:
            # Do not auto-map a UDIM/frame pattern to one random individual tile.
            if "<UDIM>" in item.original_path or "#" in item.original_path:
                _add_candidates(item, candidates)
                _set_item_status(item, "REVIEW", candidates=len(candidates), note="Pattern path: review manually before mapping.")
                review += 1
                continue
            try:
                path = candidates[0]["path"]
                _stage_reference_path(
                    scene,
                    item,
                    path,
                    "Unique exact filename match staged. It will only be applied when you click Save New Mappings.",
                )
                fixed += 1
            except Exception as exc:
                _set_item_status(item, "MISSING", note=f"Could not stage this file mapping: {exc}")
                not_found += 1
        elif candidates:
            _add_candidates(item, candidates)
            reason = "Multiple exact filename matches." if match_type == "EXACT" else "Possible fuzzy filename matches."
            _set_item_status(item, "REVIEW", candidates=len(candidates), note=reason)
            review += 1
        else:
            _clear_candidates(item)
            _set_item_status(item, "NOT_FOUND", note="No exact or useful fuzzy filename match in this scan.")
            not_found += 1

    settings.last_action = (
        f"Folder scan complete: {fixed} exact match(es) staged, {review} need review, {not_found} still missing. "
        "Staged mappings are not applied until you click Save New Mappings."
    )


def _drive_match_score(target_name, candidate_name):
    """Return 100 for exact filenames, otherwise a conservative fuzzy score."""
    target_lower = target_name.lower()
    candidate_lower = candidate_name.lower()
    if target_lower == candidate_lower:
        return 100, "Exact filename"
    target_ext = os.path.splitext(target_lower)[1]
    if target_ext and os.path.splitext(candidate_lower)[1] != target_ext:
        return 0, ""
    target_stem = _base_stem(target_name)
    candidate_stem = _base_stem(candidate_name)
    if not target_stem or not candidate_stem:
        return 0, ""
    target_tokens = _name_tokens(target_name)
    candidate_tokens = _name_tokens(candidate_name)
    # Avoid expensive similarity work for completely unrelated files.
    if target_tokens and candidate_tokens and not (target_tokens & candidate_tokens):
        if target_stem[:3] != candidate_stem[:3]:
            return 0, ""
    score = round(difflib.SequenceMatcher(None, target_stem, candidate_stem).ratio() * 100)
    if score < round(FUZZY_MIN_SCORE * 100):
        return 0, ""
    return score, "Fuzzy filename"


def _drive_search_worker(root, target_name, cancel_event, message_queue):
    """Search a whole selected volume for one filename without the 6-level cap.

    This is intentionally a separate rescue action. It follows all readable
    folders on the selected drive, skips inaccessible folders, runs off the
    UI thread and can be cancelled.
    """
    stack = [root]
    folder_count = file_count = denied_count = 0
    last_report = 0
    candidates = []
    target_ext = os.path.splitext(target_name.lower())[1]

    try:
        while stack:
            if cancel_event.is_set():
                message_queue.put(("DRIVE_CANCELLED", None))
                return
            current = stack.pop()
            folder_count += 1
            try:
                entries = list(os.scandir(current))
            except (PermissionError, FileNotFoundError, OSError):
                denied_count += 1
                continue

            for entry in entries:
                if cancel_event.is_set():
                    message_queue.put(("DRIVE_CANCELLED", None))
                    return
                try:
                    if entry.is_dir(follow_symlinks=False):
                        stack.append(entry.path)
                    elif entry.is_file(follow_symlinks=False):
                        file_count += 1
                        if target_ext and os.path.splitext(entry.name.lower())[1] != target_ext:
                            continue
                        score, match_type = _drive_match_score(target_name, entry.name)
                        if score:
                            candidates.append({
                                "path": entry.path,
                                "name": entry.name,
                                "score": score,
                                "match_type": match_type,
                            })
                except OSError:
                    continue

                if file_count - last_report >= 1000:
                    last_report = file_count
                    message_queue.put(("DRIVE_PROGRESS", {
                        "folders": folder_count,
                        "files": file_count,
                        "denied": denied_count,
                        "current": current,
                    }))

        # Exact first, then best fuzzy candidates. Avoid duplicate paths.
        candidates.sort(key=lambda row: (-row["score"], row["path"].lower()))
        unique = []
        seen = set()
        for row in candidates:
            key = row["path"].lower()
            if key not in seen:
                seen.add(key)
                unique.append(row)
            if len(unique) >= 32:
                break

        message_queue.put(("DRIVE_DONE", {
            "folders": folder_count,
            "files": file_count,
            "denied": denied_count,
            "results": unique,
        }))
    except Exception as exc:
        message_queue.put(("DRIVE_ERROR", str(exc)))


def _start_drive_search(scene, root, ref_key):
    if _RUNTIME["running"]:
        scene.cfr_settings.last_action = "A scan is already running. Cancel or wait for it to finish first."
        return
    settings = scene.cfr_settings
    item = next((row for row in settings.missing_files if row.ref_key == ref_key), None)
    if item is None or not item.match_name:
        settings.last_action = "Select a missing file with a usable filename first."
        return
    if not root or not os.path.isdir(root):
        settings.last_action = "Choose a valid drive first."
        return

    settings.drive_results.clear()
    settings.active_drive_result_index = -1
    settings.drive_search_ref_key = ref_key
    settings.drive_search_target = item.match_name
    settings.drive_search_root = _normalise_path(root)
    settings.drive_search_denied = 0
    settings.scanned_folders = 0
    settings.scanned_files = 0
    settings.scan_status = "Starting full-drive rescue search…"
    settings.last_action = f"Searching the full selected drive {settings.drive_search_root} for {item.match_name}."

    cancel_event = threading.Event()
    message_queue = queue.Queue()
    thread = threading.Thread(
        target=_drive_search_worker,
        args=(settings.drive_search_root, item.match_name, cancel_event, message_queue),
        daemon=True,
        name="CinaedvsDriveSearch",
    )
    _RUNTIME.update({
        "thread": thread,
        "cancel": cancel_event,
        "queue": message_queue,
        "running": True,
        "scene_name": scene.name,
        "mode": "drive",
    })
    thread.start()
    if not _RUNTIME["timer_registered"]:
        _RUNTIME["timer_registered"] = True
        bpy.app.timers.register(_poll_scan_timer, first_interval=0.10)


def _poll_scan_timer():
    message_queue = _RUNTIME.get("queue")
    scene = bpy.data.scenes.get(_RUNTIME.get("scene_name", ""))
    if message_queue is None or scene is None or not hasattr(scene, "cfr_settings"):
        _RUNTIME["timer_registered"] = False
        return None

    settings = scene.cfr_settings
    finished = False

    while True:
        try:
            message_kind, payload = message_queue.get_nowait()
        except queue.Empty:
            break

        if message_kind == "DRIVE_PROGRESS":
            settings.scanned_folders = payload["folders"]
            settings.scanned_files = payload["files"]
            settings.drive_search_denied = payload["denied"]
            settings.scan_status = f"Searching drive · {payload['folders']:,} folders · {payload['files']:,} files"
        elif message_kind == "DRIVE_CANCELLED":
            settings.scan_status = "Drive search cancelled"
            settings.last_action = "No file paths were changed by the cancelled drive search."
            finished = True
        elif message_kind == "DRIVE_ERROR":
            settings.scan_status = "Drive search failed"
            settings.last_action = f"Drive search error: {payload}"
            finished = True
        elif message_kind == "DRIVE_DONE":
            settings.scanned_folders = payload["folders"]
            settings.scanned_files = payload["files"]
            settings.drive_search_denied = payload["denied"]
            settings.drive_results.clear()
            for row_data in payload["results"]:
                row = settings.drive_results.add()
                row.path = row_data["path"]
                row.name = row_data["name"]
                row.score = row_data["score"]
                row.match_type = row_data["match_type"]
            settings.active_drive_result_index = 0 if settings.drive_results else -1
            settings.scan_status = f"Drive search complete · {payload['folders']:,} folders · {payload['files']:,} files"
            if settings.drive_results:
                settings.last_action = (
                    f"Found {len(settings.drive_results)} possible match(es) for {settings.drive_search_target}. "
                    "Review them in the Drive Search Results card."
                )
            else:
                settings.last_action = (
                    f"No usable filename match for {settings.drive_search_target} on {settings.drive_search_root}."
                )
            finished = True
        elif message_kind == "PROGRESS":
            settings.scanned_folders = payload["folders"]
            settings.scanned_files = payload["files"]
            ignored = payload.get("ignored_deep", 0)
            suffix = f" · {ignored:,} deeper folder(s) ignored" if ignored else ""
            settings.scan_status = f"Scanning folder · {payload['folders']:,} folders · {payload['files']:,} files{suffix}"
        elif message_kind == "MATCHING":
            settings.scan_status = f"Checking possible matches for {payload['total']} missing file(s)…"
        elif message_kind == "MATCH_PROGRESS":
            settings.scan_status = f"Checking matches · {payload['current']}/{payload['total']}"
        elif message_kind == "SCOPE_TOO_BROAD":
            # Kept only for compatibility with scans started by older in-memory
            # versions of the extension. v0.16 never sends this message: folders
            # below the depth limit are ignored and the scan completes normally.
            settings.scanned_folders = payload["folders"]
            settings.scanned_files = payload["files"]
            settings.scan_status = f"Limited to {HARD_MAX_DEPTH} child levels"
            settings.last_action = (
                f"I have ONLY scanned {HARD_MAX_DEPTH} levels of child folders; "
                "anything deeper was ignored."
            )
            finished = True
        elif message_kind == "FILE_LIMIT":
            settings.scanned_folders = payload["folders"]
            settings.scanned_files = payload["files"]
            settings.scan_status = "File cap reached — scan stopped"
            settings.last_action = f"Stopped after {payload['files']:,} files. Choose a narrower folder."
            finished = True
        elif message_kind == "CANCELLED":
            settings.scan_status = "Folder scan cancelled"
            settings.last_action = "No new file paths were changed by this cancelled scan."
            finished = True
        elif message_kind == "ERROR":
            settings.scan_status = "Folder scan failed"
            settings.last_action = f"Scanner error: {payload}"
            finished = True
        elif message_kind == "DONE":
            settings.scanned_folders = payload["folders"]
            settings.scanned_files = payload["files"]
            ignored = payload.get("ignored_deep", 0)
            _apply_scan_results(scene, payload["results"])
            if ignored:
                settings.scan_status = (
                    f"Complete · {payload['folders']:,} folders · {payload['files']:,} files "
                    f"· {ignored:,} deeper folder(s) ignored"
                )
                settings.last_action = (
                    f"I have ONLY scanned {HARD_MAX_DEPTH} levels of child folders; "
                    f"{ignored:,} deeper folder(s) were ignored. "
                    f"{settings.last_action}"
                )
            else:
                settings.scan_status = f"Complete · {payload['folders']:,} folders · {payload['files']:,} files"
            finished = True

    _tag_all_redraws()
    if finished:
        _RUNTIME.update({
            "running": False,
            "thread": None,
            "cancel": None,
            "queue": None,
            "timer_registered": False,
        })
        return None
    return 0.10


def _start_folder_scan(scene):
    if _RUNTIME["running"]:
        scene.cfr_settings.last_action = "A folder scan is already running."
        return

    settings = scene.cfr_settings
    root = bpy.path.abspath(settings.scan_root.strip())
    if not root or not os.path.isdir(root):
        settings.last_action = "Choose a valid source folder first."
        return

    visible_items = [
        item for item in settings.missing_files
        if item.status not in {"FIXED", "PENDING", "SKIPPED"}
    ]
    if not visible_items:
        settings.last_action = "There are no unresolved files in the current list. Press Scan Missing Files after choosing File Types."
        return

    settings.scan_root = _normalise_path(root)
    settings.scanned_folders = 0
    settings.scanned_files = 0
    settings.scan_status = "Starting controlled folder scan…"
    settings.last_action = (
        f"Scanning {settings.scan_root} for {len(visible_items)} unresolved file(s). "
        f"I will scan only {HARD_MAX_DEPTH} child-folder levels and ignore anything deeper."
    )

    targets = [(item.ref_key, item.match_name) for item in visible_items]
    cancel_event = threading.Event()
    message_queue = queue.Queue()
    thread = threading.Thread(
        target=_scan_worker,
        args=(settings.scan_root, targets, cancel_event, message_queue),
        daemon=True,
        name="CinaedvsFileRescueScan",
    )
    _RUNTIME.update({
        "thread": thread,
        "cancel": cancel_event,
        "queue": message_queue,
        "running": True,
        "scene_name": scene.name,
        "mode": "folder",
    })
    thread.start()

    if not _RUNTIME["timer_registered"]:
        _RUNTIME["timer_registered"] = True
        bpy.app.timers.register(_poll_scan_timer, first_interval=0.10)


# -----------------------------------------------------------------------------
# Linked-object inspection helpers
# -----------------------------------------------------------------------------

def _collection_label(obj):
    names = [collection.name for collection in getattr(obj, "users_collection", [])]
    return ", ".join(names) if names else "No collection"


def _append_linked_object(settings, seen, obj, usage, material_name="", node_name=""):
    """Add one object/use relationship to the linked-object result list."""
    if obj is None:
        return
    key = (obj.name_full, usage, material_name, node_name)
    if key in seen:
        return
    seen.add(key)
    row = settings.linked_objects.add()
    row.object_name = obj.name_full
    row.object_type = obj.type
    row.collection_name = _collection_label(obj)
    row.material_name = material_name
    row.node_name = node_name
    row.usage = usage


def _iter_material_image_uses(obj, image):
    """Yield material/node labels for image texture nodes used by an object."""
    for slot in getattr(obj, "material_slots", []):
        material = getattr(slot, "material", None)
        node_tree = getattr(material, "node_tree", None) if material else None
        if node_tree is None:
            continue
        for node in node_tree.nodes:
            if getattr(node, "type", "") == "TEX_IMAGE" and getattr(node, "image", None) == image:
                yield material.name, node.name

    # Geometry-node modifier groups can contain Image Texture nodes too.
    for modifier in getattr(obj, "modifiers", []):
        node_tree = getattr(modifier, "node_group", None)
        if node_tree is None:
            continue
        for node in node_tree.nodes:
            if getattr(node, "type", "") == "TEX_IMAGE" and getattr(node, "image", None) == image:
                yield f"Geometry Nodes: {modifier.name}", node.name


def _rebuild_linked_objects(scene):
    """Find scene objects using the currently selected missing reference.

    The central missing-file data model stores a direct session-only pointer to
    each external reference. This helper follows that pointer into Blender's
    objects/materials rather than guessing from filenames.
    """
    settings = scene.cfr_settings
    settings.linked_objects.clear()
    settings.active_linked_object_index = -1
    settings.linked_preview_object = None
    settings.linked_ref_key = ""
    settings.linked_file_label = ""

    item = _active_item(settings)
    if item is None:
        settings.last_action = "Select a missing file first."
        return 0

    reference = _RUNTIME.get("reference_map", {}).get(item.ref_key)
    if reference is None:
        settings.last_action = "Run Scan Missing Files again before inspecting linked objects."
        return 0

    owner = reference.get("owner")
    kind = reference.get("kind", "")
    seen = set()
    settings.linked_ref_key = item.ref_key
    settings.linked_file_label = item.match_name or item.datablock_name or "Selected missing file"

    # The current scene is deliberately used, because every row can then be
    # selected and framed in the active Blender viewport immediately.
    for obj in scene.objects:
        if kind == "IMAGE":
            for material_name, node_name in _iter_material_image_uses(obj, owner):
                _append_linked_object(
                    settings, seen, obj,
                    "Image Texture node",
                    material_name=material_name,
                    node_name=node_name,
                )
        elif kind == "SOUND":
            if obj.type == "SPEAKER" and getattr(getattr(obj, "data", None), "sound", None) == owner:
                _append_linked_object(settings, seen, obj, "Speaker sound")
        elif kind == "FONT":
            if obj.type == "FONT" and getattr(getattr(obj, "data", None), "font", None) == owner:
                _append_linked_object(settings, seen, obj, "Text object font")
        elif kind in {"VOLUME", "CACHEFILE"}:
            if getattr(obj, "data", None) == owner:
                _append_linked_object(settings, seen, obj, "Object data")
        elif kind == "LIBRARY":
            if getattr(obj, "library", None) == owner:
                _append_linked_object(settings, seen, obj, "Linked object")
            elif getattr(getattr(obj, "data", None), "library", None) == owner:
                _append_linked_object(settings, seen, obj, "Linked object data")

    if settings.linked_objects:
        settings.active_linked_object_index = 0
        settings.linked_preview_object = bpy.data.objects.get(settings.linked_objects[0].object_name)
        settings.last_action = (
            f"Found {len(settings.linked_objects)} linked object use(s) for {settings.linked_file_label}."
        )
    else:
        settings.last_action = f"No scene objects currently use {settings.linked_file_label}."
    return len(settings.linked_objects)



_PREVIEW_IMAGE_PREFIX = "__CFR_OBJECT_PREVIEW__"


def _clear_object_preview_image(settings):
    """Remove a previous CINAEDVS render without touching user images."""
    image = getattr(settings, "linked_preview_image", None)
    texture = getattr(settings, "linked_preview_texture", None)
    settings.linked_preview_image = None
    settings.linked_preview_texture = None
    try:
        if texture is not None and texture.name.startswith(_PREVIEW_IMAGE_PREFIX) and texture.users == 0:
            bpy.data.textures.remove(texture)
    except Exception:
        pass
    try:
        if image is not None and image.name.startswith(_PREVIEW_IMAGE_PREFIX) and image.users == 0:
            bpy.data.images.remove(image)
    except Exception:
        pass


def _preview_bounds(obj):
    """Return a conservative centre/radius for the object in local preview space."""
    try:
        points = [Vector(corner) for corner in obj.bound_box]
    except Exception:
        points = []
    if not points:
        return Vector((0.0, 0.0, 0.0)), 1.0
    min_v = Vector((min(p.x for p in points), min(p.y for p in points), min(p.z for p in points)))
    max_v = Vector((max(p.x for p in points), max(p.y for p in points), max(p.z for p in points)))
    centre = (min_v + max_v) * 0.5
    radius = max((p - centre).length for p in points)
    return centre, max(radius, 0.35)


def _aim_camera(camera, target, azimuth_degrees, elevation_degrees, distance):
    azimuth = math.radians(azimuth_degrees)
    elevation = math.radians(elevation_degrees)
    direction = Vector((
        math.cos(azimuth) * math.cos(elevation),
        math.sin(azimuth) * math.cos(elevation),
        math.sin(elevation),
    ))
    camera.location = target + direction * distance
    camera.rotation_euler = (target - camera.location).to_track_quat("-Z", "Y").to_euler()


def _add_preview_light(scene, collection, name, location, energy, size, target):
    data = bpy.data.lights.new(name, type="AREA")
    data.energy = energy
    data.shape = "DISK"
    data.size = size
    obj = bpy.data.objects.new(name, data)
    collection.objects.link(obj)
    obj.location = location
    obj.rotation_euler = (target - obj.location).to_track_quat("-Z", "Y").to_euler()
    return obj, data


def _copy_render_result_to_preview(settings, width, height):
    render_result = bpy.data.images.get("Render Result")
    if render_result is None:
        return None, "Blender did not return a render result."
    _clear_object_preview_image(settings)
    image = bpy.data.images.new(
        f"{_PREVIEW_IMAGE_PREFIX}{int(time.time() * 1000)}",
        width=width,
        height=height,
        alpha=False,
        float_buffer=False,
    )
    try:
        image.pixels.foreach_set(render_result.pixels[:])
        image.colorspace_settings.name = "sRGB"
        image.update()
        try:
            image.preview_ensure()
        except Exception:
            pass
        settings.linked_preview_image = image
        try:
            texture = bpy.data.textures.new(f"{_PREVIEW_IMAGE_PREFIX}TEXTURE_{int(time.time() * 1000)}", type="IMAGE")
            texture.image = image
            settings.linked_preview_texture = texture
        except Exception:
            settings.linked_preview_texture = None
        return image, ""
    except Exception as exc:
        try:
            bpy.data.images.remove(image)
        except Exception:
            pass
        return None, f"Could not prepare the preview image: {exc}"


def _render_isolated_object_preview(context, settings):
    """Render an isolated low-res object thumbnail in a temporary scene.

    The active Blender scene, current selection, camera, viewport shading and
    workspace are never touched. The temporary scene and all helper data are
    destroyed immediately after the image is copied into CINAEDVS.
    """
    obj = settings.linked_preview_object
    if obj is None:
        return False, "Select a linked object first."

    temporary_scene = None
    temporary_world = None
    created_objects = []
    created_data = []
    try:
        temporary_scene = bpy.data.scenes.new("__CFR_PREVIEW_SCENE__")
        temporary_scene.render.resolution_x = 440
        temporary_scene.render.resolution_y = 440
        temporary_scene.render.resolution_percentage = 100
        temporary_scene.render.image_settings.file_format = "PNG"
        temporary_scene.render.film_transparent = False

        temporary_world = bpy.data.worlds.new("__CFR_PREVIEW_WORLD__")
        temporary_world.use_nodes = True
        background = temporary_world.node_tree.nodes.get("Background")
        if background:
            background.inputs["Color"].default_value = (0.055, 0.055, 0.065, 1.0)
            background.inputs["Strength"].default_value = 0.22
        temporary_scene.world = temporary_world

        collection = temporary_scene.collection
        preview_object = obj.copy()
        created_objects.append(preview_object)
        if getattr(obj, "data", None) is not None and hasattr(obj.data, "copy"):
            try:
                preview_object.data = obj.data.copy()
                created_data.append(preview_object.data)
            except Exception:
                # Some Blender object data cannot be safely copied. Sharing the
                # read-only source data still makes a non-destructive preview.
                preview_object.data = obj.data
        preview_object.animation_data_clear()
        preview_object.matrix_world = Matrix.Identity(4)
        collection.objects.link(preview_object)

        centre, radius = _preview_bounds(preview_object)
        camera_data = bpy.data.cameras.new("__CFR_PREVIEW_CAMERA__")
        camera = bpy.data.objects.new("__CFR_PREVIEW_CAMERA__", camera_data)
        created_objects.append(camera)
        created_data.append(camera_data)
        collection.objects.link(camera)
        temporary_scene.camera = camera
        camera.data.lens = 52
        distance = radius * max(settings.linked_preview_zoom, 1.1) * 2.8
        _aim_camera(
            camera,
            centre,
            settings.linked_preview_azimuth,
            settings.linked_preview_elevation,
            distance,
        )

        if settings.linked_preview_mode == "MATERIAL":
            # EEVEE allows the preview to use actual nodes/textures when the
            # currently installed Blender build exposes EEVEE Next.
            try:
                temporary_scene.render.engine = "BLENDER_EEVEE_NEXT"
            except Exception:
                temporary_scene.render.engine = "BLENDER_WORKBENCH"
            light_specs = (
                (centre + Vector((radius * 3.4, -radius * 3.2, radius * 4.0)), 1100.0, radius * 3.0),
                (centre + Vector((-radius * 3.0, -radius * 1.8, radius * 1.6)), 700.0, radius * 2.4),
                (centre + Vector((radius * 0.6, radius * 3.3, radius * 2.4)), 850.0, radius * 2.1),
            )
            for index, (location, energy, size) in enumerate(light_specs, 1):
                light, light_data = _add_preview_light(
                    temporary_scene, collection, f"__CFR_PREVIEW_LIGHT_{index}__",
                    location, energy, size, centre,
                )
                created_objects.append(light)
                created_data.append(light_data)
        else:
            temporary_scene.render.engine = "BLENDER_WORKBENCH"
            shading = temporary_scene.display.shading
            shading.light = "STUDIO"
            shading.color_type = "MATERIAL"
            shading.show_shadows = True
            shading.show_cavity = True
            shading.cavity_type = "WORLD"
            shading.background_type = "WORLD"
            shading.background_color = (0.055, 0.055, 0.065)

        view_layer = temporary_scene.view_layers[0]
        # Context override keeps the user's active scene/workspace intact.
        with context.temp_override(scene=temporary_scene, view_layer=view_layer):
            bpy.ops.render.render(write_still=False)

        image, problem = _copy_render_result_to_preview(settings, 440, 440)
        if image is None:
            return False, problem
        mode_label = "Material Preview" if settings.linked_preview_mode == "MATERIAL" else "Solid"
        return True, f"{mode_label} preview ready. It is isolated from the main Blender window."

    except Exception as exc:
        return False, f"Could not render an isolated object preview: {exc}"
    finally:
        for temp_obj in reversed(created_objects):
            try:
                bpy.data.objects.remove(temp_obj, do_unlink=True)
            except Exception:
                pass
        for data in reversed(created_data):
            try:
                if data.users == 0:
                    if isinstance(data, bpy.types.Mesh):
                        bpy.data.meshes.remove(data)
                    elif isinstance(data, bpy.types.Camera):
                        bpy.data.cameras.remove(data)
                    elif isinstance(data, bpy.types.Light):
                        bpy.data.lights.remove(data)
            except Exception:
                pass
        if temporary_scene is not None:
            try:
                bpy.data.scenes.remove(temporary_scene, do_unlink=True)
            except Exception:
                pass
        if temporary_world is not None:
            try:
                if temporary_world.users == 0:
                    bpy.data.worlds.remove(temporary_world)
            except Exception:
                pass


def _update_linked_object_active(settings, context):
    index = settings.active_linked_object_index
    if 0 <= index < len(settings.linked_objects):
        settings.linked_preview_object = bpy.data.objects.get(settings.linked_objects[index].object_name)
    else:
        settings.linked_preview_object = None


# -----------------------------------------------------------------------------
# Scene properties and list widgets
# -----------------------------------------------------------------------------

class CFR_CandidateItem(PropertyGroup):
    path: StringProperty()
    name: StringProperty()
    score: IntProperty(default=0)
    match_type: StringProperty()


class CFR_MissingFileItem(PropertyGroup):
    kind: StringProperty()
    datablock_name: StringProperty()
    original_path: StringProperty()
    match_name: StringProperty()
    ref_key: StringProperty()
    source_label: StringProperty()
    status: StringProperty(default="MISSING")
    resolved_path: StringProperty()
    candidate_count: IntProperty(default=0)
    note: StringProperty()
    pre_pending_status: StringProperty()
    pre_pending_note: StringProperty()
    candidates: CollectionProperty(type=CFR_CandidateItem)
    active_candidate_index: IntProperty(default=-1)


class CFR_BrowserFolderItem(PropertyGroup):
    name: StringProperty()
    path: StringProperty()


class CFR_DriveResultItem(PropertyGroup):
    path: StringProperty()
    name: StringProperty()
    score: IntProperty(default=0)
    match_type: StringProperty()


class CFR_StagedPreviewItem(PropertyGroup):
    ref_key: StringProperty()
    name: StringProperty()
    kind: StringProperty()
    path: StringProperty()


class CFR_LinkedObjectItem(PropertyGroup):
    object_name: StringProperty()
    object_type: StringProperty()
    collection_name: StringProperty()
    material_name: StringProperty()
    node_name: StringProperty()
    usage: StringProperty()


class CFR_Settings(PropertyGroup):
    scan_root: StringProperty(name="Source folder", subtype="DIR_PATH")
    missing_files: CollectionProperty(type=CFR_MissingFileItem)
    active_missing_index: IntProperty(default=-1)
    browser_folders: CollectionProperty(type=CFR_BrowserFolderItem)
    active_browser_index: IntProperty(default=-1)
    drive_results: CollectionProperty(type=CFR_DriveResultItem)
    active_drive_result_index: IntProperty(default=-1)
    linked_objects: CollectionProperty(type=CFR_LinkedObjectItem)
    active_linked_object_index: IntProperty(default=-1, update=_update_linked_object_active)
    linked_preview_object: PointerProperty(type=bpy.types.Object)
    linked_ref_key: StringProperty()
    linked_file_label: StringProperty()
    linked_preview_image: PointerProperty(type=bpy.types.Image)
    linked_preview_texture: PointerProperty(type=bpy.types.Texture)
    linked_preview_mode: EnumProperty(
        items=(("SOLID", "Solid", "Low-quality solid viewport-style render"),
               ("MATERIAL", "Material Preview", "Low-quality rendered material preview")),
        default="SOLID",
    )
    linked_preview_azimuth: FloatProperty(default=38.0)
    linked_preview_elevation: FloatProperty(default=21.0)
    linked_preview_zoom: FloatProperty(default=1.0, min=0.55, max=3.2)
    linked_preview_status: StringProperty(default="Choose Preview Object to open an isolated preview window.")
    drive_search_ref_key: StringProperty()
    drive_search_target: StringProperty()
    drive_search_root: StringProperty()
    drive_search_denied: IntProperty(default=0)
    preview_image: PointerProperty(type=bpy.types.Image)
    preview_status: StringProperty(default="Select a possible match, then use Preview / Stage Match.")
    staged_preview_items: CollectionProperty(type=CFR_StagedPreviewItem)
    active_staged_preview_index: IntProperty(default=-1, update=_update_staged_preview_active)
    staged_preview_image: PointerProperty(type=bpy.types.Image)
    staged_preview_status: StringProperty(default="Select a staged match to preview it.")
    scan_status: StringProperty(default="Ready")
    last_action: StringProperty(default="Press Scan Missing Files to build the list.")
    scanned_folders: IntProperty(default=0)
    scanned_files: IntProperty(default=0)
    stage_threshold: IntProperty(
        name="Minimum match %",
        default=90,
        min=1,
        max=100,
        description="Stage every review row whose top candidate meets or exceeds this filename similarity score",
    )
    show_staged_matches: BoolProperty(
        name="Show Staged Matches",
        default=True,
        description="Show or hide Match Found rows in the main missing-file list without discarding them",
    )
    filter_materials: BoolProperty(name="Textures / Materials", default=True)
    filter_models: BoolProperty(name="Models / Libraries", default=True)
    filter_video: BoolProperty(name="Video", default=True)
    filter_audio: BoolProperty(name="Audio", default=True)
    filter_fonts: BoolProperty(name="Fonts", default=True)
    filter_caches: BoolProperty(name="Volumes / Caches", default=True)
    filter_other: BoolProperty(name="Text / Sequencer / IES", default=True)
    hide_intro: BoolProperty(
        name="Don't show this again",
        default=False,
        description="Skip the CINAEDVS File Rescue introduction when launching this tool",
    )
    mappings_changed: BoolProperty(
        default=False,
        description="True when CINAEDVS has staged mappings that have not yet been applied to Blender",
    )


class CFR_UL_missing_files(UIList):
    bl_idname = "CFR_UL_missing_files"

    def filter_items(self, context, data, propname):
        """Hide only staged rows when requested.

        In Blender UILists, bitflag_filter_item marks a row as visible.
        v0.9 inverted this flag, which hid every valid row. This explicit
        implementation keeps all normal rows visible and only removes staged
        rows when the user chooses Hide Staged.
        """
        items = getattr(data, propname)
        settings = context.scene.cfr_settings
        visible_flag = self.bitflag_filter_item
        flags = [
            visible_flag
            if settings.show_staged_matches or item.status != "PENDING"
            else 0
            for item in items
        ]
        return flags, []

    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        if self.layout_type in {"DEFAULT", "COMPACT"}:
            row = layout.row(align=True)
            row.label(text=_status_text(item), icon=_status_icon(item))
            row.label(text=item.match_name or "Blank / unnamed reference")
            kind = row.row(align=True)
            kind.alignment = "RIGHT"
            kind.label(text=KIND_LABELS.get(item.kind, item.kind))
        else:
            layout.label(text=item.match_name or "Blank / unnamed reference", icon=_status_icon(item))


class CFR_UL_candidates(UIList):
    bl_idname = "CFR_UL_candidates"

    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        if self.layout_type in {"DEFAULT", "COMPACT"}:
            row = layout.row(align=True)
            row.label(text=f"[{item.score}%]", icon="FILE")
            row.label(text=item.name or _display_path(item.path, 66))
            state = row.row(align=True)
            state.alignment = "RIGHT"
            state.label(text=item.match_type)
        else:
            layout.label(text=item.name or _display_path(item.path, 66), icon="FILE")


class CFR_UL_staged_preview(UIList):
    bl_idname = "CFR_UL_staged_preview"

    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        row = layout.row(align=True)
        row.label(text="[~] Match Found", icon=ICON_MATCH_FOUND)
        row.label(text=_display_path(item.name or _match_name(item.path), 34), icon="FILE")
        tail = row.row(align=True)
        tail.alignment = "RIGHT"
        tail.label(text=_display_path(item.kind, 24))


class CFR_UL_browser_folders(UIList):
    bl_idname = "CFR_UL_browser_folders"

    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        layout.label(text=item.name or item.path, icon="FILE_FOLDER")


class CFR_UL_drive_results(UIList):
    bl_idname = "CFR_UL_drive_results"

    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        row = layout.row(align=True)
        row.label(text=f"[{item.score}%]", icon="FILE")
        row.label(text=item.name or _display_path(item.path, 52))
        label = row.row(align=True)
        label.alignment = "RIGHT"
        label.label(text=item.match_type)


class CFR_UL_linked_objects(UIList):
    bl_idname = "CFR_UL_linked_objects"

    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        if self.layout_type in {"DEFAULT", "COMPACT"}:
            row = layout.row(align=True)
            row.label(text=item.object_name, icon="OBJECT_DATA")
            row.label(text=item.object_type)
            detail = item.material_name or item.usage or "Direct object use"
            row.label(text=_display_path(detail, 38))
            tail = row.row(align=True)
            tail.alignment = "RIGHT"
            tail.label(text=_display_path(item.collection_name, 28))
        else:
            layout.label(text=item.object_name, icon="OBJECT_DATA")


# -----------------------------------------------------------------------------
# Operators
# -----------------------------------------------------------------------------

class CFR_OT_scan_missing_files(Operator):
    bl_idname = "cfr.scan_missing_files"
    bl_label = "Rescan Missing Files"
    bl_description = "Rebuild the missing-file list using the current File Types selection"

    def execute(self, context):
        settings = context.scene.cfr_settings
        pending = _pending_mapping_count(settings)
        if pending:
            settings.last_action = (
                f"You have {pending} staged match(es). Save or discard them before rebuilding the missing-file list."
            )
            self.report({"WARNING"}, "Save or discard staged matches first")
            return {"CANCELLED"}
        scan_missing_references(context.scene)
        _tag_all_redraws()
        return {"FINISHED"}


class CFR_OT_set_all_filters(Operator):
    bl_idname = "cfr.set_all_filters"
    bl_label = "All"
    bl_description = "Tick every file type"

    def execute(self, context):
        _set_all_filters(context.scene.cfr_settings, True)
        return {"FINISHED"}


class CFR_OT_clear_all_filters(Operator):
    bl_idname = "cfr.clear_all_filters"
    bl_label = "Clear All"
    bl_description = "Untick every file type"

    def execute(self, context):
        _set_all_filters(context.scene.cfr_settings, False)
        return {"FINISHED"}


class CFR_OT_toggle_staged_visibility(Operator):
    bl_idname = "cfr.toggle_staged_visibility"
    bl_label = "Hide Staged Matches"
    bl_description = "Hide or show staged Match Found rows without discarding them"

    def execute(self, context):
        settings = context.scene.cfr_settings
        settings.show_staged_matches = not settings.show_staged_matches

        # Do not leave the Details card pointed at a row that has just been
        # hidden. Move selection to the first visible row where possible.
        if not settings.show_staged_matches:
            active = _active_item(settings)
            if active is not None and active.status == "PENDING":
                for index, item in enumerate(settings.missing_files):
                    if item.status != "PENDING":
                        settings.active_missing_index = index
                        break

        settings.last_action = (
            "Staged matches are visible in the main list."
            if settings.show_staged_matches
            else "Staged matches are hidden from the main list. They remain in Preview Changes and will still save."
        )
        _tag_all_redraws()
        return {"FINISHED"}


class CFR_OT_stage_matches_above_threshold(Operator):
    bl_idname = "cfr.stage_matches_above_threshold"
    bl_label = "Stage Matches Above Threshold"
    bl_description = "Stage the highest-ranked candidate for every review row meeting the selected minimum percentage"

    def execute(self, context):
        scene = context.scene
        settings = scene.cfr_settings
        threshold = int(settings.stage_threshold)
        staged = 0
        below_threshold = 0
        skipped_patterns = 0
        unavailable = 0

        for item in settings.missing_files:
            if item.status != "REVIEW" or not item.candidates:
                continue

            # Pattern paths deliberately require individual review; one tile or
            # frame must not silently replace a sequence/UDIM pattern.
            if "<UDIM>" in item.original_path or "#" in item.original_path:
                skipped_patterns += 1
                continue

            # Candidate rows are ordered best-first by the scanner. On equal
            # scores (for example duplicate exact filenames), this stages the
            # first result shown in Details; Preview Changes remains available
            # to remove or replace any staged result before final save.
            candidate = item.candidates[0]
            if candidate.score < threshold:
                below_threshold += 1
                continue
            if not candidate.path or not os.path.isfile(candidate.path):
                unavailable += 1
                continue

            try:
                _stage_reference_path(
                    scene,
                    item,
                    candidate.path,
                    (
                        f"Top candidate staged automatically at {candidate.score}% "
                        f"(threshold {threshold}%). Not applied to Blender yet."
                    ),
                )
                staged += 1
            except Exception:
                unavailable += 1

        parts = [f"Staged {staged} match(es) at or above {threshold}%."]
        if below_threshold:
            parts.append(f"{below_threshold} below threshold.")
        if skipped_patterns:
            parts.append(f"{skipped_patterns} pattern path(s) left for manual review.")
        if unavailable:
            parts.append(f"{unavailable} unavailable candidate(s) skipped.")
        parts.append("No Blender file paths were changed; use Save New Mappings to apply staged results.")
        settings.last_action = " ".join(parts)
        settings.mappings_changed = _pending_mapping_count(settings) > 0
        _tag_all_redraws()
        return {"FINISHED"}


class CFR_OT_choose_scan_folder(Operator):
    bl_idname = "cfr.choose_scan_folder"
    bl_label = "Choose Source Folder"
    bl_description = "Choose the top folder for the controlled recursive scan"

    directory: StringProperty(subtype="DIR_PATH")
    filter_folder: BoolProperty(default=True, options={"HIDDEN"})

    def invoke(self, context, event):
        settings = context.scene.cfr_settings
        if settings.scan_root:
            self.directory = bpy.path.abspath(settings.scan_root)
        context.window_manager.fileselect_add(self)
        return {"RUNNING_MODAL"}

    def execute(self, context):
        if not self.directory or not os.path.isdir(self.directory):
            self.report({"WARNING"}, "Choose a valid folder")
            return {"CANCELLED"}
        settings = context.scene.cfr_settings
        settings.scan_root = _normalise_path(self.directory)
        _refresh_browser_folder_list(settings)
        # Choosing a folder is the user’s clear instruction to search it.
        # The worker runs in the background, so the native dialog remains responsive.
        _start_folder_scan(context.scene)
        _tag_all_redraws()
        return {"FINISHED"}


class CFR_OT_refresh_folders(Operator):
    bl_idname = "cfr.refresh_folders"
    bl_label = "Refresh Folder List"

    def execute(self, context):
        settings = context.scene.cfr_settings
        _refresh_browser_folder_list(settings)
        return {"FINISHED"}


class CFR_OT_up_folder(Operator):
    bl_idname = "cfr.up_folder"
    bl_label = "Up Folder"

    def execute(self, context):
        settings = context.scene.cfr_settings
        if not settings.scan_root:
            return {"CANCELLED"}
        parent = os.path.dirname(os.path.normpath(settings.scan_root))
        if parent and os.path.isdir(parent):
            settings.scan_root = parent
            _refresh_browser_folder_list(settings)
        return {"FINISHED"}


class CFR_OT_open_selected_folder(Operator):
    bl_idname = "cfr.open_selected_folder"
    bl_label = "Open Selected Folder"

    def execute(self, context):
        settings = context.scene.cfr_settings
        index = settings.active_browser_index
        if 0 <= index < len(settings.browser_folders):
            path = settings.browser_folders[index].path
            if os.path.isdir(path):
                settings.scan_root = path
                _refresh_browser_folder_list(settings)
        return {"FINISHED"}


class CFR_OT_search_drive_for_file(Operator):
    bl_idname = "cfr.search_drive_for_file"
    bl_label = "Search HDD for This File"
    bl_description = "Search one selected drive, without the six-level limit, for this missing filename"

    drive: EnumProperty(name="Drive to search", items=_available_drive_items)

    def invoke(self, context, event):
        item = _active_item(context.scene.cfr_settings)
        if item is None or not item.match_name:
            self.report({"WARNING"}, "Select a missing file with a filename first")
            return {"CANCELLED"}
        choices = _available_drive_items()
        if choices:
            self.drive = choices[0][0]
        return context.window_manager.invoke_props_dialog(
            self,
            width=620,
            title="CINAEDVS — Search Full Drive",
            confirm_text="Search This Drive",
            cancel_default=True,
        )

    def draw(self, context):
        item = _active_item(context.scene.cfr_settings)
        layout = self.layout
        layout.label(text="Search Full Drive for Missing File", icon="VIEWZOOM")
        layout.label(text=item.match_name if item else "No selected file", icon="FILE")
        layout.separator()
        layout.prop(self, "drive")
        warning = layout.box()
        warning.label(text="This searches every readable folder on the selected drive.", icon="ERROR")
        warning.label(text="It has no five-level limit, may take a while, and can be cancelled.")
        warning.label(text="Windows/system folders that deny access are skipped and counted.")

    def execute(self, context):
        item = _active_item(context.scene.cfr_settings)
        if item is None:
            return {"CANCELLED"}
        _start_drive_search(context.scene, self.drive, item.ref_key)
        _tag_all_redraws()
        return {"FINISHED"}


class CFR_OT_review_drive_result(Operator):
    bl_idname = "cfr.review_drive_result"
    bl_label = "Preview / Map Selected Result"
    bl_description = "Send the selected drive-search result to the normal preview and mapping workflow"

    def execute(self, context):
        settings = context.scene.cfr_settings
        item = _active_item(settings)
        result = _active_drive_result(settings)
        if item is None or result is None:
            self.report({"WARNING"}, "Select a drive-search result first")
            return {"CANCELLED"}
        _clear_candidates(item)
        for row in settings.drive_results:
            candidate = item.candidates.add()
            candidate.path = row.path
            candidate.name = row.name
            candidate.score = row.score
            candidate.match_type = row.match_type
        item.active_candidate_index = settings.active_drive_result_index
        _set_item_status(item, "REVIEW", candidates=len(item.candidates), note="Possible matches found by full-drive search.")
        settings.last_action = "Drive-search candidates are now ready for preview and mapping in Details."
        _tag_all_redraws()
        return {"FINISHED"}


class CFR_OT_start_folder_scan(Operator):
    bl_idname = "cfr.start_folder_scan"
    bl_label = "Rescan Source Folder"
    bl_description = "Search the current source folder and its children again for the visible unresolved files"

    def execute(self, context):
        _start_folder_scan(context.scene)
        _tag_all_redraws()
        return {"FINISHED"}


class CFR_OT_cancel_scan(Operator):
    bl_idname = "cfr.cancel_scan"
    bl_label = "Cancel"

    def execute(self, context):
        cancel = _RUNTIME.get("cancel")
        if cancel is None:
            context.scene.cfr_settings.last_action = "There is no folder scan running."
            return {"CANCELLED"}
        cancel.set()
        context.scene.cfr_settings.scan_status = "Cancelling…"
        _tag_all_redraws()
        return {"FINISHED"}


class CFR_OT_preview_candidate(Operator):
    bl_idname = "cfr.preview_candidate"
    bl_label = "Preview / Stage Match"
    bl_description = "Preview the selected possible match and stage it for the final save"

    def _load_preview(self, context):
        settings = context.scene.cfr_settings
        item = _active_item(settings)
        candidate = _active_candidate(item)
        settings.preview_image = None
        if candidate is None:
            settings.preview_status = "Select a possible match first."
            return False
        path = candidate.path
        if not os.path.isfile(path):
            settings.preview_status = "This candidate file no longer exists."
            return False
        extension = os.path.splitext(path)[1].lower()
        if extension not in IMAGE_EXTENSIONS:
            settings.preview_status = "No visual preview for this file type. You can still map it."
            return True
        try:
            image = bpy.data.images.load(path, check_existing=True)
            settings.preview_image = image
            settings.preview_status = "Image preview loaded. Stage this match only if it is the correct file."
            return True
        except Exception as exc:
            settings.preview_status = f"Blender could not preview this image: {exc}"
            return True

    def invoke(self, context, event):
        settings = context.scene.cfr_settings
        item = _active_item(settings)
        candidate = _active_candidate(item)
        if item is None or candidate is None:
            self.report({"WARNING"}, "Select a review row and one possible match first")
            return {"CANCELLED"}
        self._load_preview(context)
        return context.window_manager.invoke_props_dialog(
            self,
            width=680,
            title="CINAEDVS — Possible Match",
            confirm_text="Close Preview",
            cancel_default=True,
        )

    def execute(self, context):
        return {"FINISHED"}

    def draw(self, context):
        settings = context.scene.cfr_settings
        item = _active_item(settings)
        candidate = _active_candidate(item)
        layout = self.layout
        layout.use_property_split = False
        layout.use_property_decorate = False

        title = layout.box()
        title.label(text="Possible Match Preview", icon="HIDE_OFF")
        if candidate is not None:
            position = (item.active_candidate_index + 1) if item is not None else 1
            total = len(item.candidates) if item is not None else 1
            title.label(text=f"Candidate {position} of {total}: {candidate.name or _display_path(candidate.path, 82)}", icon="FILE")
            title.label(text=f"{candidate.match_type} · {candidate.score}% filename similarity")
            title.label(text=_display_path(candidate.path, 102))
        if settings.preview_image:
            preview = layout.box()
            try:
                preview.template_ID_preview(settings, "preview_image", rows=7, cols=7, hide_buttons=True)
            except Exception:
                preview.label(text="Preview loaded. Open it from Blender's Image Editor if needed.", icon="IMAGE")
        else:
            no_preview = layout.box()
            no_preview.label(text=settings.preview_status, icon="INFO")

        if item is not None and candidate is not None:
            actions = layout.row(align=True)
            actions.scale_y = 1.35
            actions.operator("cfr.map_selected_candidate", text="Stage Match", icon=ICON_MATCH_FOUND)
            actions.operator("cfr.next_preview_candidate", text="Next Candidate", icon="TRIA_RIGHT")


class CFR_OT_close_preview(Operator):
    bl_idname = "cfr.close_preview"
    bl_label = "Back"

    def execute(self, context):
        return {"FINISHED"}


class CFR_OT_next_preview_candidate(Operator):
    bl_idname = "cfr.next_preview_candidate"
    bl_label = "Next Candidate"
    bl_description = "Show the next possible match for this missing file"

    def execute(self, context):
        settings = context.scene.cfr_settings
        item = _active_item(settings)
        if item is None or not item.candidates:
            settings.preview_status = "There are no more possible matches for this file."
            return {"CANCELLED"}

        current = item.active_candidate_index
        if current < 0:
            current = 0
        else:
            current = (current + 1) % len(item.candidates)
        item.active_candidate_index = current

        candidate = _active_candidate(item)
        settings.preview_image = None
        if candidate is None:
            settings.preview_status = "There are no more possible matches for this file."
        elif not os.path.isfile(candidate.path):
            settings.preview_status = "This candidate file no longer exists."
        elif os.path.splitext(candidate.path)[1].lower() not in IMAGE_EXTENSIONS:
            settings.preview_status = "No visual preview for this file type. You can still map it."
        else:
            try:
                settings.preview_image = bpy.data.images.load(candidate.path, check_existing=True)
                settings.preview_status = "Image preview loaded. Stage this match only if it is the correct file."
            except Exception as exc:
                settings.preview_status = f"Blender could not preview this image: {exc}"

        _tag_all_redraws()
        return {"FINISHED"}


class CFR_OT_copy_path(Operator):
    bl_idname = "cfr.copy_path"
    bl_label = "Copy Path"
    bl_description = "Copy the full path to the clipboard"

    full_path: StringProperty(options={"HIDDEN"})

    @classmethod
    def description(cls, context, properties):
        path = str(properties.full_path or "")
        return path if path else "No stored path is available."

    def execute(self, context):
        if not self.full_path:
            self.report({"WARNING"}, "No stored path is available")
            return {"CANCELLED"}
        context.window_manager.clipboard = self.full_path
        context.scene.cfr_settings.last_action = "Copied the full original path to the clipboard."
        _tag_all_redraws()
        return {"FINISHED"}


class CFR_OT_map_selected_candidate(Operator):
    bl_idname = "cfr.map_selected_candidate"
    bl_label = "Stage Match"
    bl_description = "Stage the selected possible match; nothing changes until Save New Mappings"

    def execute(self, context):
        settings = context.scene.cfr_settings
        item = _active_item(settings)
        candidate = _active_candidate(item)
        if item is None or candidate is None:
            settings.last_action = "Select a missing file and one possible match first."
            return {"CANCELLED"}
        if not os.path.isfile(candidate.path):
            settings.last_action = "That candidate file no longer exists."
            return {"CANCELLED"}
        try:
            _stage_reference_path(
                context.scene,
                item,
                candidate.path,
                "Match found after candidate review. Not applied to Blender yet.",
            )
            settings.preview_status = "✓ Match found — not applied yet. Use Save New Mappings in the main window to apply it."
            settings.last_action = (
                f"Staged match: {item.match_name} → {candidate.name}. "
                "No Blender filepath has changed yet."
            )
            _tag_all_redraws()
            return {"FINISHED"}
        except Exception as exc:
            settings.last_action = f"Could not stage this mapping: {exc}"
            return {"CANCELLED"}


class CFR_OT_choose_any_replacement(Operator):
    bl_idname = "cfr.choose_any_replacement"
    bl_label = "Choose Another File"
    bl_description = "Browse to a file manually when no suggested match is correct"

    filepath: StringProperty(subtype="FILE_PATH")
    filter_glob: StringProperty(default="*", options={"HIDDEN"})

    def invoke(self, context, event):
        if _active_item(context.scene.cfr_settings) is None:
            self.report({"WARNING"}, "Select a missing file first")
            return {"CANCELLED"}
        context.window_manager.fileselect_add(self)
        return {"RUNNING_MODAL"}

    def execute(self, context):
        settings = context.scene.cfr_settings
        item = _active_item(settings)
        if item is None or not self.filepath or not os.path.isfile(self.filepath):
            settings.last_action = "Choose an existing file."
            return {"CANCELLED"}
        try:
            path = _normalise_path(self.filepath)
            _stage_reference_path(
                context.scene,
                item,
                path,
                "Chosen manually. Match found — not applied to Blender yet.",
            )
            settings.last_action = (
                f"Staged match for {item.match_name}. "
                "No Blender filepath has changed yet."
            )
            _tag_all_redraws()
            return {"FINISHED"}
        except Exception as exc:
            settings.last_action = f"Could not stage this mapping: {exc}"
            return {"CANCELLED"}


class CFR_OT_remove_pending_mapping(Operator):
    bl_idname = "cfr.remove_pending_mapping"
    bl_label = "Remove Staged Match"
    bl_description = "Remove the staged match for the selected file without changing Blender"

    def execute(self, context):
        settings = context.scene.cfr_settings
        item = _active_item(settings)
        if item is None or item.status != "PENDING":
            settings.last_action = "Select a staged match first."
            return {"CANCELLED"}
        _discard_pending_mappings_for_item(context.scene, item)
        _tag_all_redraws()
        return {"FINISHED"}


class CFR_OT_discard_pending_mappings(Operator):
    bl_idname = "cfr.discard_pending_mappings"
    bl_label = "Discard Staged Matches"
    bl_description = "Discard all staged mappings; no Blender file paths will be changed"
    bl_options = {"REGISTER"}

    def invoke(self, context, event):
        if _pending_mapping_count(context.scene.cfr_settings) == 0:
            self.report({"INFO"}, "There are no staged matches")
            return {"CANCELLED"}
        return context.window_manager.invoke_confirm(
            self,
            event,
            title="Discard Staged Matches?",
            confirm_text="Discard Staged Matches",
        )

    def execute(self, context):
        _discard_pending_mappings(context.scene)
        _tag_all_redraws()
        return {"FINISHED"}


class CFR_OT_preview_staged_mappings(Operator):
    bl_idname = "cfr.preview_staged_mappings"
    bl_label = "Preview Changes"
    bl_description = "Review every staged match before applying it to Blender"
    bl_options = {"REGISTER"}

    def invoke(self, context, event):
        settings = context.scene.cfr_settings
        if _pending_mapping_count(settings) == 0:
            self.report({"INFO"}, "There are no staged matches to preview")
            return {"CANCELLED"}
        _populate_staged_preview_items(settings)
        return context.window_manager.invoke_props_dialog(
            self,
            width=1120,
            title="CINAEDVS — Preview Changes",
            confirm_text="Close Preview",
            cancel_default=True,
        )

    def execute(self, context):
        _clear_staged_preview_image(context.scene.cfr_settings)
        return {"FINISHED"}

    def cancel(self, context):
        _clear_staged_preview_image(context.scene.cfr_settings)

    def draw(self, context):
        settings = context.scene.cfr_settings
        layout = self.layout
        layout.use_property_split = False
        layout.use_property_decorate = False

        summary = layout.box()
        total = len(settings.staged_preview_items)
        summary.label(text=f"{total} Match Found — review before Save New Mappings", icon=ICON_MATCH_FOUND)
        summary.label(text="These changes are staged only. Nothing in Blender has been changed yet.", icon="INFO")

        columns = layout.row(align=True)
        left = columns.column()
        right = columns.column()

        left_box = left.box()
        left_box.label(text="STAGED MAPPINGS", icon="FILE")
        if settings.staged_preview_items:
            left_box.template_list(
                "CFR_UL_staged_preview", "", settings, "staged_preview_items", settings,
                "active_staged_preview_index", rows=12,
            )
        else:
            left_box.label(text="No staged mappings remain.", icon="INFO")

        right_box = right.box()
        right_box.label(text="PREVIEW", icon="HIDE_OFF")
        idx = settings.active_staged_preview_index
        selected = None
        if 0 <= idx < len(settings.staged_preview_items):
            selected = settings.staged_preview_items[idx]
            right_box.label(text=_display_path(selected.name, 64), icon="FILE")
            right_box.label(text=_display_path(selected.path, 88), icon="FILE_FOLDER")
        else:
            right_box.label(text="Select a staged mapping from the list.", icon="INFO")

        if settings.staged_preview_image is not None:
            try:
                right_box.template_ID_preview(
                    settings, "staged_preview_image", rows=10, cols=10, hide_buttons=True
                )
            except Exception:
                right_box.label(text="Preview image loaded, but this Blender UI could not draw it here.", icon="IMAGE")
        else:
            placeholder = right_box.box()
            placeholder.label(text=settings.staged_preview_status, icon="INFO")
            placeholder.label(text="Non-image files can still be removed from the staged changes.")

        action_row = layout.row(align=True)
        action_row.scale_y = 1.25
        remove_row = action_row.row(align=True)
        remove_row.enabled = selected is not None
        remove_row.operator(
            "cfr.remove_previewed_staged_mapping", text="Remove Mapping", icon="X"
        )
        copy_row = action_row.row(align=True)
        copy_row.enabled = selected is not None
        copy_row.operator("cfr.copy_staged_preview_path", text="Copy File Path", icon="COPYDOWN")


class CFR_OT_remove_previewed_staged_mapping(Operator):
    bl_idname = "cfr.remove_previewed_staged_mapping"
    bl_label = "Remove Mapping"
    bl_description = "Discard this staged match without changing Blender"

    def execute(self, context):
        settings = context.scene.cfr_settings
        idx = settings.active_staged_preview_index
        if not (0 <= idx < len(settings.staged_preview_items)):
            self.report({"WARNING"}, "Select a staged mapping first")
            return {"CANCELLED"}
        ref_key = settings.staged_preview_items[idx].ref_key
        item = _find_item_by_ref_key(settings, ref_key)
        if item is None or item.status != "PENDING":
            _populate_staged_preview_items(settings)
            self.report({"WARNING"}, "That staged mapping is no longer available")
            return {"CANCELLED"}
        filename = item.match_name
        _discard_pending_mappings_for_item(context.scene, item)
        _populate_staged_preview_items(settings)
        settings.last_action = f"Removed staged mapping for {filename}. No Blender filepath was changed."
        _tag_all_redraws()
        return {"FINISHED"}


class CFR_OT_copy_staged_preview_path(Operator):
    bl_idname = "cfr.copy_staged_preview_path"
    bl_label = "Copy File Path"
    bl_description = "Copy the full staged replacement path to the clipboard"

    def execute(self, context):
        settings = context.scene.cfr_settings
        idx = settings.active_staged_preview_index
        if not (0 <= idx < len(settings.staged_preview_items)):
            return {"CANCELLED"}
        path = settings.staged_preview_items[idx].path
        if not path:
            return {"CANCELLED"}
        context.window_manager.clipboard = path
        self.report({"INFO"}, "Copied staged file path")
        return {"FINISHED"}


class CFR_OT_discard_from_close_warning(Operator):
    bl_idname = "cfr.discard_from_close_warning"
    bl_label = "Discard Matches Found"
    bl_description = "Discard all found matches and return to File Rescue without changing Blender"
    bl_options = {"REGISTER"}

    def execute(self, context):
        settings = context.scene.cfr_settings
        discarded = _discard_pending_mappings(context.scene)
        if discarded:
            settings.last_action = (
                f"Discarded {discarded} match(es). No Blender filepath was changed. "
                "Click Cancel to return to File Rescue."
            )
            self.report({"INFO"}, f"Discarded {discarded} match(es)")
        else:
            settings.last_action = "There were no found matches left to discard."
        _tag_all_redraws()
        return {"FINISHED"}


class CFR_OT_pending_close_warning(Operator):
    bl_idname = "cfr.pending_close_warning"
    bl_label = "Matches Found Have Not Been Applied"
    bl_options = {"REGISTER"}

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(
            self,
            width=700,
            title="CINAEDVS — Matches Found Have Not Been Applied",
            confirm_text="Save New Mappings",
            cancel_default=True,
        )

    def execute(self, context):
        ok, message = _commit_pending_mappings(context.scene)
        context.scene.cfr_settings.last_action = message
        if not ok:
            self.report({"WARNING"}, message)
            return {"CANCELLED"}
        self.report({"INFO"}, message)
        _tag_all_redraws()
        return {"FINISHED"}

    def cancel(self, context):
        # Native props dialogs have no third button. Cancel means keep every
        # pending mapping and return to the main editor; explicit discard stays
        # available there as its own guarded button.
        bpy.ops.cfr.launch("INVOKE_DEFAULT", skip_intro=True)

    def draw(self, context):
        settings = context.scene.cfr_settings
        pending = _pending_mapping_count(settings)
        layout = self.layout
        warning = layout.box()

        if pending:
            warning.label(text="Your matched file paths have not been applied yet.", icon="ERROR")
            warning.label(
                text=f"You have {pending} match(es) found. They only exist inside CINAEDVS right now.",
                icon="TIME",
            )
            warning.separator()
            warning.label(text="Save New Mappings applies them to Blender and saves this .blend file.", icon="CHECKMARK")
            warning.label(text="Discard Matches Found removes every staged match without changing Blender.", icon="TRASH")

            discard_row = warning.row(align=True)
            discard_row.scale_y = 1.15
            discard_row.operator(
                "cfr.discard_from_close_warning",
                text="Discard Matches Found",
                icon="TRASH",
            )
        else:
            warning.label(text="All found matches have been discarded.", icon="CHECKMARK")
            warning.label(text="No Blender file paths were changed.", icon="INFO")
            warning.label(text="Click Cancel to return to File Rescue.", icon="BACK")


class CFR_OT_ignore_selected(Operator):
    bl_idname = "cfr.ignore_selected"
    bl_label = "Ignore"
    bl_description = "Ignore the selected missing reference for this session"

    def execute(self, context):
        settings = context.scene.cfr_settings
        item = _active_item(settings)
        if item is None:
            settings.last_action = "Select a missing file first."
            return {"CANCELLED"}
        _clear_candidates(item)
        _set_item_status(item, "SKIPPED", note="Ignored by user for this session.")
        settings.last_action = f"Ignored {item.match_name}."
        _tag_all_redraws()
        return {"FINISHED"}


class CFR_OT_show_linked_objects(Operator):
    bl_idname = "cfr.show_linked_objects"
    bl_label = "Linked Objects"
    bl_description = "Show the scene objects that use the selected missing file"
    bl_options = {"REGISTER"}

    def invoke(self, context, event):
        settings = context.scene.cfr_settings
        item = _active_item(settings)
        if item is None:
            self.report({"WARNING"}, "Select a missing file first")
            return {"CANCELLED"}
        _rebuild_linked_objects(context.scene)
        return context.window_manager.invoke_props_dialog(
            self,
            width=900,
            title="CINAEDVS — Linked Objects",
            confirm_text="Close",
            cancel_default=True,
        )

    def execute(self, context):
        return {"FINISHED"}

    def draw(self, context):
        settings = context.scene.cfr_settings
        layout = self.layout
        layout.use_property_split = False
        layout.use_property_decorate = False

        header = layout.box()
        header.label(text="LINKED OBJECTS", icon="OUTLINER_OB_GROUP_INSTANCE")
        header.label(
            text=f"Selected missing file: {_display_path(settings.linked_file_label or 'No file selected', 84)}",
            icon="FILE",
        )
        if settings.linked_objects:
            header.label(text=f"{len(settings.linked_objects)} object use(s) in this scene", icon="INFO")
        else:
            header.label(text="No scene objects currently use this file.", icon="INFO")

        if not settings.linked_objects:
            return

        layout.template_list(
            "CFR_UL_linked_objects", "", settings, "linked_objects", settings,
            "active_linked_object_index", rows=10,
        )
        selected = None
        if 0 <= settings.active_linked_object_index < len(settings.linked_objects):
            selected = settings.linked_objects[settings.active_linked_object_index]

        details = layout.box()
        details.label(text="SELECTED OBJECT", icon="OBJECT_DATA")
        if selected is not None:
            details.label(text=f"{selected.object_name} · {selected.object_type} · {selected.usage}")
            if selected.material_name:
                details.label(text=f"Material: {selected.material_name}")
            if selected.node_name:
                details.label(text=f"Node: {selected.node_name}")
            details.label(text=f"Collection: {_display_path(selected.collection_name, 82)}")
            details.separator()
            actions = details.row(align=True)
            actions.scale_y = 1.2
            actions.operator("cfr.open_object_preview", text="Preview Object", icon="HIDE_OFF")
            details.label(
                text="Preview opens in its own window and does not change the Blender scene, selection or viewport behind it.",
                icon="LOCKED",
            )


class CFR_OT_open_object_preview(Operator):
    bl_idname = "cfr.open_object_preview"
    bl_label = "Object Preview"
    bl_description = "Open an isolated low-quality preview that does not touch the main Blender window"
    bl_options = {"REGISTER"}

    def invoke(self, context, event):
        settings = context.scene.cfr_settings
        if settings.linked_preview_object is None:
            self.report({"WARNING"}, "Select a linked object first")
            return {"CANCELLED"}
        settings.linked_preview_mode = "SOLID"
        settings.linked_preview_azimuth = 38.0
        settings.linked_preview_elevation = 21.0
        settings.linked_preview_zoom = 1.0
        ok, message = _render_isolated_object_preview(context, settings)
        settings.linked_preview_status = message
        if not ok:
            self.report({"WARNING"}, message)
        _tag_all_redraws()
        return context.window_manager.invoke_props_dialog(
            self,
            width=680,
            title="CINAEDVS — Object Preview",
            confirm_text="Close Preview",
            cancel_default=True,
        )

    def execute(self, context):
        return {"FINISHED"}

    def draw(self, context):
        settings = context.scene.cfr_settings
        layout = self.layout
        layout.use_property_split = False
        layout.use_property_decorate = False

        header = layout.box()
        header.label(text="OBJECT PREVIEW", icon="HIDE_OFF")
        obj = settings.linked_preview_object
        header.label(text=f"{obj.name_full if obj else 'No selected object'}", icon="OBJECT_DATA")
        header.label(text="This preview is rendered in a temporary scene. The Blender window behind it is never modified.", icon="LOCKED")

        controls = layout.row(align=True)
        solid = controls.operator("cfr.set_object_preview_mode", text="Solid", icon="SHADING_SOLID")
        solid.mode = "SOLID"
        material = controls.operator("cfr.set_object_preview_mode", text="Material Preview", icon="SHADING_TEXTURE")
        material.mode = "MATERIAL"

        view = layout.row(align=True)
        left = view.operator("cfr.adjust_object_preview", text="Rotate Left", icon="TRIA_LEFT")
        left.action = "LEFT"
        right = view.operator("cfr.adjust_object_preview", text="Rotate Right", icon="TRIA_RIGHT")
        right.action = "RIGHT"
        zoom_in = view.operator("cfr.adjust_object_preview", text="Zoom In", icon="ZOOM_IN")
        zoom_in.action = "ZOOM_IN"
        zoom_out = view.operator("cfr.adjust_object_preview", text="Zoom Out", icon="ZOOM_OUT")
        zoom_out.action = "ZOOM_OUT"
        reset = view.operator("cfr.adjust_object_preview", text="Reset View", icon="FILE_REFRESH")
        reset.action = "RESET"

        preview = layout.box()
        if settings.linked_preview_texture is not None:
            try:
                preview.template_preview(settings.linked_preview_texture)
            except Exception:
                try:
                    preview.template_ID_preview(settings, "linked_preview_texture", rows=10, cols=10, hide_buttons=True)
                except Exception:
                    preview.label(text="The preview image was created, but this Blender UI could not draw it here.", icon="ERROR")
        elif settings.linked_preview_image is not None:
            try:
                preview.template_ID_preview(settings, "linked_preview_image", rows=10, cols=10, hide_buttons=True)
            except Exception:
                preview.label(text="The preview image was created, but this Blender UI could not draw it here.", icon="ERROR")
        else:
            preview.label(text="No preview image was created.", icon="ERROR")
        preview.label(text=settings.linked_preview_status, icon="INFO")
        layout.label(text="Rotation and zoom controls affect only this temporary preview render.", icon="INFO")


class CFR_OT_set_object_preview_mode(Operator):
    bl_idname = "cfr.set_object_preview_mode"
    bl_label = "Set Preview Mode"
    mode: EnumProperty(
        items=(("SOLID", "Solid", "Solid low-quality preview"),
               ("MATERIAL", "Material Preview", "Rendered material preview")),
        options={"HIDDEN"},
        default="SOLID",
    )

    def execute(self, context):
        settings = context.scene.cfr_settings
        settings.linked_preview_mode = self.mode
        ok, message = _render_isolated_object_preview(context, settings)
        settings.linked_preview_status = message
        if not ok:
            self.report({"WARNING"}, message)
            return {"CANCELLED"}
        _tag_all_redraws()
        return {"FINISHED"}


class CFR_OT_adjust_object_preview(Operator):
    bl_idname = "cfr.adjust_object_preview"
    bl_label = "Adjust Preview"
    action: EnumProperty(
        items=(("LEFT", "Rotate Left", "Rotate left"),
               ("RIGHT", "Rotate Right", "Rotate right"),
               ("ZOOM_IN", "Zoom In", "Zoom in"),
               ("ZOOM_OUT", "Zoom Out", "Zoom out"),
               ("RESET", "Reset View", "Reset preview view")),
        options={"HIDDEN"},
    )

    def execute(self, context):
        settings = context.scene.cfr_settings
        if self.action == "LEFT":
            settings.linked_preview_azimuth -= 20.0
        elif self.action == "RIGHT":
            settings.linked_preview_azimuth += 20.0
        elif self.action == "ZOOM_IN":
            settings.linked_preview_zoom = max(0.55, settings.linked_preview_zoom * 0.82)
        elif self.action == "ZOOM_OUT":
            settings.linked_preview_zoom = min(3.2, settings.linked_preview_zoom * 1.22)
        elif self.action == "RESET":
            settings.linked_preview_azimuth = 38.0
            settings.linked_preview_elevation = 21.0
            settings.linked_preview_zoom = 1.0
        ok, message = _render_isolated_object_preview(context, settings)
        settings.linked_preview_status = message
        if not ok:
            self.report({"WARNING"}, message)
            return {"CANCELLED"}
        _tag_all_redraws()
        return {"FINISHED"}


# -----------------------------------------------------------------------------
# File-type menu and launch popup
# -----------------------------------------------------------------------------

class CFR_MT_file_type_filters(Menu):
    bl_idname = "CFR_MT_file_type_filters"
    bl_label = "File Types"

    def draw(self, context):
        settings = context.scene.cfr_settings
        layout = self.layout
        row = layout.row(align=True)
        row.operator("cfr.set_all_filters", text="All", icon="CHECKMARK")
        row.operator("cfr.clear_all_filters", text="Clear All", icon="X")
        layout.separator()
        layout.prop(settings, "filter_materials")
        layout.prop(settings, "filter_models")
        layout.prop(settings, "filter_video")
        layout.prop(settings, "filter_audio")
        layout.prop(settings, "filter_fonts")
        layout.prop(settings, "filter_caches")
        layout.prop(settings, "filter_other")



def _filter_button_text(settings):
    """Return compact text for the File Types menu button."""
    filter_names = (
        ("Textures", settings.filter_materials),
        ("Models", settings.filter_models),
        ("Video", settings.filter_video),
        ("Audio", settings.filter_audio),
        ("Fonts", settings.filter_fonts),
        ("Caches", settings.filter_caches),
        ("Other", settings.filter_other),
    )
    selected = [name for name, enabled in filter_names if enabled]
    if len(selected) == len(filter_names):
        return "All File Types"
    if not selected:
        return "No File Types"
    if len(selected) == 1:
        return selected[0]
    return f"{len(selected)} Types Selected"


def _status_counts(settings):
    """Count the stored rows without changing the displayed list."""
    counts = {"FIXED": 0, "PENDING": 0, "REVIEW": 0, "MISSING": 0, "SKIPPED": 0}
    for item in settings.missing_files:
        counts[item.status] = counts.get(item.status, 0) + 1
    return counts


def _draw_rescue_ui(layout, context, in_popup=True):
    """A mirrored two-column workspace for missing and source files.

    Both top cards have the same sequence: header, two concise information rows,
    a toolbar, then a ten-row file list. The two lower cards are both Details
    cards and retain a consistent minimum visual height.
    """
    settings = context.scene.cfr_settings
    layout.use_property_split = False
    layout.use_property_decorate = False

    split = layout.split(factor=0.50)
    left = split.column(align=False)
    right = split.column(align=False)
    counts = _status_counts(settings)

    # ------------------------------------------------------------------
    # TOP LEFT — MISSING FILES
    # ------------------------------------------------------------------
    missing_card = left.box()
    missing_header = missing_card.row(align=True)
    missing_header.scale_y = 1.35
    missing_header.label(text="MISSING FILES", icon=ICON_MISSING)
    missing_total = missing_header.row(align=True)
    missing_total.alignment = "RIGHT"
    visible_count = _visible_missing_count(settings)
    if settings.show_staged_matches:
        missing_total.label(text=f"{visible_count} listed")
    else:
        hidden = _pending_mapping_count(settings)
        missing_total.label(text=f"{visible_count} visible · {hidden} staged hidden")

    # Exactly two metadata rows, mirrored by the source card on the right.
    missing_summary = missing_card.row(align=True)
    missing_summary.label(
        text=(
            f"{counts.get('FIXED', 0)} saved · "
            f"{counts.get('PENDING', 0)} matches found · "
            f"{counts.get('REVIEW', 0)} need review · "
            f"{counts.get('MISSING', 0)} unresolved"
        ),
        icon="INFO",
    )
    linked_button = missing_summary.row(align=True)
    linked_button.alignment = "RIGHT"
    linked_button.enabled = _active_item(settings) is not None
    linked_button.operator("cfr.show_linked_objects", text="Linked Objects", icon="OUTLINER_OB_GROUP_INSTANCE")
    missing_card.label(
        text="Exact names are staged · nothing changes until Save New Mappings",
        icon=ICON_MATCH_FOUND,
    )

    # The control strip belongs above the list, matching the right-side strip.
    missing_toolbar = missing_card.row(align=True)
    missing_toolbar.scale_y = 1.14
    missing_toolbar.menu(
        "CFR_MT_file_type_filters",
        text=_filter_button_text(settings),
        icon="DOWNARROW_HLT",
    )
    visibility = missing_toolbar.operator(
        "cfr.toggle_staged_visibility",
        text="Hide Staged" if settings.show_staged_matches else "Show Staged",
        icon="HIDE_ON" if settings.show_staged_matches else "HIDE_OFF",
    )
    missing_toolbar.operator(
        "cfr.scan_missing_files",
        text="Rescan Missing Files",
        icon="VIEWZOOM",
        depress=True,
    )

    missing_card.template_list(
        "CFR_UL_missing_files", "", settings, "missing_files", settings,
        "active_missing_index", rows=10,
    )

    # ------------------------------------------------------------------
    # TOP RIGHT — SOURCE FILES
    # ------------------------------------------------------------------
    source_card = right.box()
    source_header = source_card.row(align=True)
    source_header.scale_y = 1.35
    source_header.label(text="SOURCE FILES", icon="FILE_FOLDER")
    source_index = source_header.row(align=True)
    source_index.alignment = "RIGHT"
    source_index.label(
        text=(
            f"{settings.scanned_folders:,} folders · {settings.scanned_files:,} files"
            if settings.scanned_folders or settings.scanned_files
            else "Not indexed"
        ),
        icon="INFO",
    )

    # Current source path and its picker now share one compact row.
    source_path_row = source_card.row(align=True)
    source_path_row.label(
        text=_display_path(settings.scan_root or "No source folder selected", 38),
        icon="FILE_FOLDER",
    )
    source_path_row.operator(
        "cfr.choose_scan_folder",
        text="Choose Source Folder",
        icon="FILEBROWSER",
        depress=True,
    )
    source_card.label(
        text="Controlled recursive scan: selected folder plus 6 child levels.",
        icon="LOCKED",
    )

    # Matching control-strip position above the source list. The picker has
    # moved to the path row above, so only browsing controls remain here.
    source_toolbar = source_card.row(align=True)
    source_toolbar.scale_y = 1.14
    source_toolbar.operator("cfr.up_folder", text="Up", icon="TRIA_UP")
    source_toolbar.operator("cfr.refresh_folders", text="Refresh", icon="FILE_REFRESH")
    source_toolbar.operator("cfr.open_selected_folder", text="Open", icon="TRIA_RIGHT")

    source_card.template_list(
        "CFR_UL_browser_folders", "", settings, "browser_folders", settings,
        "active_browser_index", rows=10,
    )

    # ------------------------------------------------------------------
    # LOWER LEFT — DETAILS
    # ------------------------------------------------------------------
    missing_details = left.box()
    missing_details_header = missing_details.row(align=True)
    missing_details_header.scale_y = 1.18
    missing_details_header.label(text="DETAILS", icon="INFO")

    item = _active_item(settings)
    if item is None:
        missing_details.label(text="Select a missing file to inspect it.", icon="INFO")
        missing_details.label(text="Exact filename matches are mapped automatically.")
        missing_details.label(text="Possible fuzzy matches stay here for review.")
        missing_details.label(text="")
        missing_details.label(text="")
        missing_details.label(text="")
    else:
        # Keep the original filename/category information concise. For review
        # rows, the candidate heading below supplies the one definitive
        # "Possible Matches" label, avoiding duplicate messages.
        if item.status != "REVIEW":
            missing_details.label(
                text=f"{_status_text(item)}  {_display_path(item.match_name or 'Blank / unnamed reference', 54)}",
                icon=_status_icon(item),
            )
        else:
            missing_details.label(
                text=_display_path(item.match_name or "Blank / unnamed reference", 62),
                icon=ICON_POSSIBLE_MATCH,
            )
        missing_details.label(text=_display_path(KIND_LABELS.get(item.kind, item.kind), 54))

        # The shortened path is a button solely so Blender can expose the full
        # stored path in a hover tooltip. The dedicated Copy button beside it
        # copies that exact full path to the clipboard.
        original_row = missing_details.row(align=True)
        original_row.label(text="Original:")
        hover_path = original_row.operator(
            "cfr.copy_path",
            text=_display_path(item.original_path or "No stored path", 42),
            icon="FILE",
        )
        hover_path.full_path = item.original_path
        copy_path = original_row.operator("cfr.copy_path", text="Copy", icon="COPYDOWN")
        copy_path.full_path = item.original_path

        if item.status == "PENDING":
            staged = missing_details.box()
            staged.label(text="MATCH FOUND — NOT APPLIED YET", icon=ICON_MATCH_FOUND)
            staged.label(text=_display_path(item.resolved_path, 68), icon="FILE")
            staged.label(text="Save New Mappings applies this path to Blender and saves the .blend file.", icon="INFO")
            staged_actions = staged.row(align=True)
            staged_actions.operator("cfr.choose_any_replacement", text="Change File", icon="FILEBROWSER")
            staged_actions.operator("cfr.remove_pending_mapping", text="Remove Match", icon="X")
        elif item.status == "REVIEW" and item.candidates:
            candidate_header = missing_details.row(align=True)
            candidate_header.label(
                text=(
                    f"Possible Matches — {len(item.candidates)} for "
                    f"{_display_path(item.match_name, 44)}"
                ),
                icon=ICON_POSSIBLE_MATCH,
            )
            missing_details.template_list(
                "CFR_UL_candidates", "", item, "candidates", item,
                "active_candidate_index", rows=2,
            )
            candidate_actions = missing_details.row(align=True)
            candidate_actions.operator("cfr.preview_candidate", text="Preview / Stage Match", icon="HIDE_OFF")
            threshold = candidate_actions.row(align=True)
            threshold.scale_x = 0.42
            threshold.prop(settings, "stage_threshold", text="")
            candidate_actions.operator(
                "cfr.stage_matches_above_threshold",
                text=f"Stage ≥ {settings.stage_threshold}%",
                icon=ICON_MATCH_FOUND,
                depress=True,
            )
            candidate_actions.operator("cfr.choose_any_replacement", text="Choose File", icon="FILEBROWSER")
        else:
            missing_details.label(text=item.note or "No candidate needs review.")
            missing_details.label(text="")
            missing_details.label(text="")
            manual = missing_details.row(align=True)
            manual.operator("cfr.choose_any_replacement", text="Choose Replacement", icon="FILEBROWSER")
            manual.operator("cfr.search_drive_for_file", text="Search HDD for This File", icon="DISK_DRIVE")
            manual.operator("cfr.ignore_selected", text="Ignore", icon="REMOVE")

    # ------------------------------------------------------------------
    # LOWER RIGHT — SOURCE DETAILS / FULL-DRIVE RESULTS
    # ------------------------------------------------------------------
    drive_for_active = bool(item and settings.drive_search_ref_key == item.ref_key)
    source_details = right.box()
    source_details_header = source_details.row(align=True)
    source_details_header.scale_y = 1.18
    source_details_header.label(
        text="DRIVE SEARCH RESULTS" if drive_for_active else "DETAILS",
        icon="VIEWZOOM" if drive_for_active else "INFO",
    )

    if drive_for_active:
        source_details.label(text=f"Target: {settings.drive_search_target}", icon="FILE")
        source_details.label(
            text=_display_path(settings.drive_search_root or "No drive selected", 70),
            icon="DISK_DRIVE",
        )
        if _RUNTIME["running"] and _RUNTIME.get("mode") == "drive":
            source_details.label(
                text=f"Searching {settings.scanned_folders:,} folders · {settings.scanned_files:,} files",
                icon="TIME",
            )
        elif settings.drive_results:
            source_details.label(
                text=f"{len(settings.drive_results)} result(s) · {settings.drive_search_denied:,} inaccessible folder(s) skipped",
                icon="INFO",
            )
            source_details.template_list(
                "CFR_UL_drive_results", "", settings, "drive_results", settings,
                "active_drive_result_index", rows=4,
            )
            drive_actions = source_details.row(align=True)
            drive_actions.operator(
                "cfr.review_drive_result",
                text="Preview / Stage Match Result",
                icon="HIDE_OFF",
            )
        else:
            source_details.label(text="No usable filename match found on this drive.", icon="ERROR")
            source_details.label(text=f"{settings.drive_search_denied:,} inaccessible folder(s) were skipped.")
            source_details.label(text="Choose Replacement still lets you select a file manually.")

        drive_scan = source_details.row(align=True)
        drive_scan.scale_y = 1.14
        if _RUNTIME["running"] and _RUNTIME.get("mode") == "drive":
            drive_scan.enabled = True
            drive_scan.operator("cfr.cancel_scan", text="Cancel Drive Search", icon="CANCEL")
        else:
            drive_scan.operator("cfr.search_drive_for_file", text="Search Another Drive", icon="DISK_DRIVE")
    else:
        source_details.label(text="Selected source folder", icon="FILE_FOLDER")
        source_details.label(text=_display_path(settings.scan_root or "No source folder selected", 70))
        source_details.label(text="Scope: selected folder plus up to six child levels.", icon="LOCKED")
        source_details.label(text="Exact filenames map automatically; fuzzy names remain for review.")
        source_details.label(text="")
        source_details.label(text="")

        source_scan = source_details.row(align=True)
        source_scan.scale_y = 1.14
        source_scan.operator(
            "cfr.start_folder_scan",
            text="Rescan Folder + Children",
            icon="VIEWZOOM",
            depress=True,
        )
        cancel = source_scan.row(align=True)
        cancel.enabled = _RUNTIME["running"]
        cancel.operator("cfr.cancel_scan", text="Cancel", icon="CANCEL")

    # One compact full-width status strip at the very bottom.
    footer = layout.box()
    status_text = _display_path(settings.scan_status, 82)
    action_text = _display_path(settings.last_action, 120)
    footer_row = footer.row(align=True)
    footer_row.label(text=status_text, icon="TIME" if _RUNTIME["running"] else "INFO")
    if action_text:
        footer_row.separator(factor=0.75)
        footer_row.label(text=action_text)

    # Pending mappings are deliberately explicit: they can be discarded only
    # from a guarded action and are otherwise applied only by the native Save
    # New Mappings footer.
    pending = _pending_mapping_count(settings)
    if pending:
        pending_row = layout.row(align=True)
        pending_row.alignment = "CENTER"
        pending_row.label(text=f"{pending} match(es) found — not applied to Blender yet", icon=ICON_MATCH_FOUND)
        pending_row.operator("cfr.discard_pending_mappings", text="Discard Staged Matches", icon="TRASH")
        pending_row.operator("cfr.preview_staged_mappings", text="Preview Changes", icon="HIDE_OFF")

    # Native Blender dialogs own their Save/Cancel footer and cannot host a
    # third control inside that exact row. Keep the guide available as a compact
    # control in the action strip immediately above the native footer.
    footer_actions = layout.row(align=True)
    footer_actions.alignment = "CENTER"
    show_info = footer_actions.operator("cfr.show_intro", text="Info", icon="INFO")
    show_info.open_main_after = False


class CFR_OT_close_launch_popup(Operator):
    bl_idname = "cfr.close_launch_popup"
    bl_label = "Close CINAEDVS File Rescue"
    bl_description = "Close the CINAEDVS popup"

    def execute(self, context):
        # Blender closes an invoke_popup when its invoking UI action resolves on
        # supported builds. Escape and click-outside remain native fallbacks.
        return {"FINISHED"}


class CFR_OT_open_website(Operator):
    bl_idname = "cfr.open_website"
    bl_label = "Open CINAEDVS Studios Website"
    bl_description = "Open the CINAEDVS Studios website"

    url: StringProperty(options={"HIDDEN"}, default="https://cinaedvsstudios.github.io/cinaedvs")

    def execute(self, context):
        try:
            bpy.ops.wm.url_open(url=self.url)
            return {"FINISHED"}
        except Exception as exc:
            self.report({"WARNING"}, f"Could not open website: {exc}")
            return {"CANCELLED"}


def _update_intro_visibility(self, context):
    """Persist the guide choice immediately, including when the guide is cancelled."""
    try:
        context.scene.cfr_settings.hide_intro = bool(self.dont_show_again)
    except Exception:
        pass


class CFR_OT_show_intro(Operator):
    bl_idname = "cfr.show_intro"
    bl_label = "How CINAEDVS File Rescue Works"
    bl_description = "Show the CINAEDVS File Rescue workflow guide"
    bl_options = {"REGISTER"}

    open_main_after: BoolProperty(options={"HIDDEN"}, default=True)
    dont_show_again: BoolProperty(
        name="Don't show this again",
        default=False,
        update=_update_intro_visibility,
        description="Skip this guide next time CINAEDVS File Rescue is launched",
    )

    def invoke(self, context, event):
        self.dont_show_again = context.scene.cfr_settings.hide_intro
        return context.window_manager.invoke_props_dialog(
            self,
            width=820,
            title="CINAEDVS File Rescue — Quick Guide",
            confirm_text="Continue",
            cancel_default=True,
        )

    def execute(self, context):
        settings = context.scene.cfr_settings
        settings.hide_intro = self.dont_show_again
        if self.open_main_after:
            bpy.ops.cfr.launch("INVOKE_DEFAULT", skip_intro=True)
        return {"FINISHED"}

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = False
        layout.use_property_decorate = False

        intro = layout.box()
        intro.label(text="HOW FILE RESCUE WORKS", icon="INFO")
        intro.label(text="Made by CINAEDVS Studios", icon="COMMUNITY")
        website = intro.operator("cfr.open_website", text="cinaedvsstudios.github.io/cinaedvs", icon="URL")
        website.url = "https://cinaedvsstudios.github.io/cinaedvs"

        intro.separator()
        intro.label(text="1. Scan the missing-file list", icon=ICON_MISSING)
        intro.label(text="Launching File Rescue automatically scans the active Blender file. Change File Types, then use Rescan Missing Files when needed.")
        intro.label(text="[X] Missing means no useful match has been found. [!] Review means there are candidates to inspect.")

        intro.separator()
        intro.label(text="2. Choose the source folder", icon="FILE_FOLDER")
        intro.label(text="On the right, click Choose Source Folder and select the asset library or folder you want to search.")

        intro.separator()
        intro.label(text="3. Search the source folder", icon="VIEWZOOM")
        intro.label(text="Choosing a source folder automatically starts the scan. Use Rescan Folder + Children only when you want to repeat it. It searches up to 6 child-folder levels.")
        intro.label(text="Folders deeper than level 6 are ignored, but matches within the first 6 levels are still used.")

        intro.separator()
        intro.label(text="4. Understand the results", icon=ICON_POSSIBLE_MATCH)
        intro.label(text="[~] Match Found means an exact filename match was found and staged. It is NOT applied to Blender yet.")
        intro.label(text="[!] Review means CINAEDVS found duplicate exact names or fuzzy filename matches; choose the correct candidate below.")
        intro.label(text="Use Choose File for a manual path, or Search HDD for This File when the normal folder scan finds nothing useful.")

        intro.separator()
        intro.label(text="5. Stage and bulk-stage matches", icon=ICON_MATCH_FOUND)
        intro.label(text="Preview / Stage Match stages the selected candidate only. Staging never changes the open Blender scene.")
        intro.label(text="Stage ≥ 90% stages the first listed candidate for every review row at or above the percentage you enter.")
        intro.label(text="Use Preview Changes to inspect all staged mappings and remove any you do not want. Hide Staged only hides rows; it does not discard them.")

        intro.separator()
        intro.label(text="6. Apply and save", icon="FILE_TICK")
        intro.label(text="Save New Mappings is the ONLY action that applies staged paths to Blender and saves this entire .blend file.")
        intro.label(text="Closing with staged matches shows a warning. Save to apply them, discard them, or return to editing.")

        layout.separator()
        layout.label(text="This guide opens only when you press Info in File Rescue.", icon="INFO")


class CFR_OT_launch(Operator):
    bl_idname = "cfr.launch"
    bl_label = "CINAEDVS File Rescue"
    bl_description = "Open CINAEDVS File Rescue"
    bl_options = {"REGISTER"}

    skip_intro: BoolProperty(options={"HIDDEN"}, default=False)

    def invoke(self, context, event):
        settings = context.scene.cfr_settings
        # The guide is deliberately manual only. It is available via Info in
        # the main File Rescue dialog and never interrupts opening a new file.
        #
        # Launch should immediately audit the active .blend so the left pane is
        # useful without an extra click. Existing staged matches are preserved
        # rather than silently discarded by a rebuild.
        pending = _pending_mapping_count(settings)
        if pending:
            settings.last_action = (
                f"{pending} staged match(es) are still waiting to be saved or discarded. "
                "The missing-file list was not rebuilt."
            )
        else:
            scan_missing_references(context.scene)

        if settings.scan_root and os.path.isdir(bpy.path.abspath(settings.scan_root)):
            _refresh_browser_folder_list(settings)

        # This native dialog path was tested on Chris's Blender build: it
        # displays UIList rows correctly and supplies reliable save/cancel actions.
        return context.window_manager.invoke_props_dialog(
            self,
            width=1180,
            title="CINAEDVS File Rescue",
            confirm_text="Save New Mappings",
            cancel_default=True,
        )

    def execute(self, context):
        settings = context.scene.cfr_settings
        ok, message = _commit_pending_mappings(context.scene)
        settings.last_action = message
        if not ok:
            self.report({"WARNING"}, message)
            return {"CANCELLED"}
        self.report({"INFO"}, message)
        _tag_all_redraws()
        return {"FINISHED"}

    def cancel(self, context):
        pending = _pending_mapping_count(context.scene.cfr_settings)
        if pending:
            # The main dialog is now closing, so open a clear native warning.
            # Cancel in that warning reopens this editor; confirmation applies
            # and saves the staged paths.
            bpy.ops.cfr.pending_close_warning("INVOKE_DEFAULT")
        return None

    def draw(self, context):
        _draw_rescue_ui(self.layout, context, in_popup=False)


class CFR_PT_launcher(Panel):
    bl_label = "CINAEDVS File Rescue"
    bl_idname = "CFR_PT_launcher"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "CINAEDVS"

    def draw(self, context):
        layout = self.layout
        layout.scale_y = 1.65
        layout.operator("cfr.launch", text="Launch", icon="PLAY")





_CLASSES = (
    CFR_CandidateItem,
    CFR_MissingFileItem,
    CFR_BrowserFolderItem,
    CFR_DriveResultItem,
    CFR_StagedPreviewItem,
    CFR_LinkedObjectItem,
    CFR_Settings,
    CFR_UL_missing_files,
    CFR_UL_candidates,
    CFR_UL_browser_folders,
    CFR_UL_drive_results,
    CFR_UL_staged_preview,
    CFR_UL_linked_objects,
    CFR_OT_scan_missing_files,
    CFR_OT_set_all_filters,
    CFR_OT_clear_all_filters,
    CFR_OT_toggle_staged_visibility,
    CFR_OT_stage_matches_above_threshold,
    CFR_OT_choose_scan_folder,
    CFR_OT_refresh_folders,
    CFR_OT_up_folder,
    CFR_OT_open_selected_folder,
    CFR_OT_search_drive_for_file,
    CFR_OT_review_drive_result,
    CFR_OT_start_folder_scan,
    CFR_OT_cancel_scan,
    CFR_OT_preview_candidate,
    CFR_OT_next_preview_candidate,
    CFR_OT_copy_path,
    CFR_OT_map_selected_candidate,
    CFR_OT_choose_any_replacement,
    CFR_OT_remove_pending_mapping,
    CFR_OT_discard_pending_mappings,
    CFR_OT_preview_staged_mappings,
    CFR_OT_remove_previewed_staged_mapping,
    CFR_OT_copy_staged_preview_path,
    CFR_OT_discard_from_close_warning,
    CFR_OT_pending_close_warning,
    CFR_OT_ignore_selected,
    CFR_OT_show_linked_objects,
    CFR_OT_open_object_preview,
    CFR_OT_set_object_preview_mode,
    CFR_OT_adjust_object_preview,
    CFR_MT_file_type_filters,
    CFR_OT_open_website,
    CFR_OT_show_intro,
    CFR_OT_launch,
    CFR_PT_launcher,
)


def register():
    for cls in _CLASSES:
        bpy.utils.register_class(cls)
    bpy.types.Scene.cfr_settings = PointerProperty(type=CFR_Settings)


def unregister():
    cancel = _RUNTIME.get("cancel")
    if cancel:
        cancel.set()
    try:
        for scene in bpy.data.scenes:
            _clear_object_preview_image(scene.cfr_settings)
            _clear_staged_preview_image(scene.cfr_settings)
    except Exception:
        pass
    if hasattr(bpy.types.Scene, "cfr_settings"):
        del bpy.types.Scene.cfr_settings
    for cls in reversed(_CLASSES):
        try:
            bpy.utils.unregister_class(cls)
        except RuntimeError:
            pass


if __name__ == "__main__":
    register()
