# CINAEDVS File Rescue v0.20.2

Blender 5.0+ extension for finding, reviewing, staging, and safely applying replacements for missing external files.

## Current review-compliance build

- Replaced the extension support/report URL with the public CINAEDVS Blender bug-report form.
- Added a packaged CHANGELOG.md so the contents of this build are recorded inside the ZIP.

## Existing v0.20 features

- Automatically scans the open Blender file for missing references when launched.
- Automatically scans a chosen source folder and up to six child-folder levels.
- Stages exact matches without changing Blender until Save New Mappings is confirmed.
- Supports possible-match review, previews, bulk staging, linked-object inspection, and whole-drive search.

See CHANGELOG.md for the cumulative build history included in this package.
