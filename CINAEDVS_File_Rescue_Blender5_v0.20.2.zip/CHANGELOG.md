# CINAEDVS File Rescue — Change Log

## v0.20.2

- Replaced the extension support/report URL with the public CINAEDVS Blender bug-report form.
- Added a packaged CHANGELOG.md so the contents of this build are recorded inside the ZIP.

## v0.20.1

- Launch automatically scans the active Blender file for missing external references.
- Choosing a source folder automatically begins the controlled six-level source scan.
- Manual scan actions are labelled as rescans.

## v0.20.0

- Added consistent native Blender status and action icons.
