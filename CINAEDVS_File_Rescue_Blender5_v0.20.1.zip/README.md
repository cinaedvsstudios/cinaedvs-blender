# CINAEDVS File Rescue v0.20.0

## Icon update

- Match Found uses Blender's linked icon
- Possible Matches / Review uses Blender's node-tree candidate icon
- Missing uses Blender's X icon
- Saved uses a file-tick icon
- Action buttons use native Blender icons matched to their action, including scan, folder selection, drive search, staging, preview, copy, remove, refresh, and discard

The extension remains Blender 5.0+ only.


## v0.20.1
- Launch now automatically audits the open Blender file for missing external references.
- Selecting a source folder automatically begins the controlled six-level folder scan.
- The manual scan actions are explicitly labelled as rescans.
